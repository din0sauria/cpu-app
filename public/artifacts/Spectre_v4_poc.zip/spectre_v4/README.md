# TransientFail Spectre Subset (Unified Platform)

This folder is a Spectre-only subset of transientfail for unified_platform integration.

## Included

- Spectre V1: `pocs/spectre/PHT/sa_ip`
- Spectre V2: `pocs/spectre/BTB/sa_ip`
- Spectre V4: `pocs/spectre/STL`
- Spectre V5 (RSB): `pocs/spectre/RSB/sa_ip`
- Shared cache utility: `pocs/libcache`
- Unified backend: `api_server/main.py`

## Excluded

Non-Spectre components are removed from this integrated copy.

## Build (manual)

```bash
cd pocs
make
```

## Run backend

```bash
cd api_server
python3 -m uvicorn main:app --host 0.0.0.0 --port 4041
```
