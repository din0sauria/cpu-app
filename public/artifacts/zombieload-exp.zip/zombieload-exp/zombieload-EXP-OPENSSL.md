# Zombieload-EXP

### 1. 本项目具体说明

ZombieLoad（CVE-2018-12130）展示了处理器 fill-buffer 逻辑在多线程共享场景下的严重安全风险。本项目详细描述并复现了一种端到端的利用（End-to-End Exploit），通过 ZombieLoad 数据采样技术，在 Windows 原生环境下实现**跨逻辑核**（同一物理核的 sibling 超线程）窃取 OpenSSL AES-NI 密钥加载过程，最终从受害者进程内存中恢复大部分 128-bit AES 密钥。该项目针对 Intel CPU（Hyper-Threading 开启）进行了验证，使用官方 PoC 的 Variant 3（Windows-only），无需虚拟机、无需 VT-x、无需管理员权限。

### 2. 涉及资源

- **Fill-Buffer (Line-Fill Buffer)**
  - **位置**: CPU 内部
  - **功能**: 负责从内存向 L1 填充缓存行的临时缓冲区，同一物理核的两个逻辑核竞争共享。
  - **利用**: 受害者加载 AES 密钥时占用 fill-buffer 条目；攻击者通过 zombie load 瞬态读取陈旧条目。
- **Cache (L1/L3 Cache)**
  - **位置**: CPU 缓存
  - **功能**: 通过 Flush+Reload 实现瞬态→架构态编码。
  - **利用**: 将泄露字节编码到 Reload Buffer，攻击者通过计时恢复数据。
- **OpenSSL EVP 接口**
  - **位置**: libcrypto
  - **功能**: 提供 AES-NI 硬件加速接口（EVP_EncryptInit_ex 调用 aesni_set_encrypt_key）。
  - **利用**: 强制密钥从内存加载到 XMM 寄存器，成为 ZombieLoad 的采样目标。
- **Reload Buffer**
  - **位置**: 攻击者控制的 256 页对齐内存
  - **功能**: 瞬态编码通道。

### 3. 攻击原理

**针对 OpenSSL AES-NI 的泄露攻击原理**（重点解释）：

1. **密钥加载触发点**：
   受害者调用 EVP_EncryptInit_ex（OpenSSL 标准接口）时，内部会执行 aesni_set_encrypt_key，**把 128-bit AES 密钥从内存加载到 XMM 寄存器**（AES-NI 硬件指令必须步骤）。这一加载操作会短暂占用 fill-buffer。
2. **Zombie Load 瞬态采样**：
   攻击者（同一物理核的 sibling 逻辑核）构造 zombie load（微码辅助故障加载），**瞬态读取 fill-buffer 中的陈旧数据**。此时 fill-buffer 中保存的正是受害者刚刚加载的密钥字节（map2[0]）。
3. **瞬态编码 + 架构态恢复**：
   攻击者在瞬态域内使用泄露字节作为索引访问 Reload Buffer（maccess(mem + 4096 * map2[0])），将对应页面加载进缓存。
   虽然瞬态指令最终被回滚，但缓存状态已改变。攻击者随后通过 Flush+Reload 遍历 256 个页面并计时：
   - **快（Cache Hit）**：对应密钥字节的页面访问时间极短。
   - **慢（Cache Miss）**：其他页面从内存读取。
   - 从而恢复出密钥字节。
4. **针对 OpenSSL 的特殊性**：
   AES-NI 是硬件抗侧信道实现，但**密钥必须从内存加载**这一步无法避免。ZombieLoad 正是抓住这个“必须加载”的瞬间，实现无地址选择器的数据采样，突破了传统侧信道的限制。

### 4. 项目核心代码文件

- **victim_aes.c**: AES-NI 受害者，循环调用 EVP_EncryptInit_ex 触发密钥加载。
- **attacker_aes.exe**: Variant 3 攻击者，实现 zombie load + Flush+Reload 采样。
- **cacheutils_win.h**: 官方微架构原语（speculation_start、flush_reload 等）。

### 5. 运行环境

- **操作系统**: Windows  11 原生
- **编译环境**: MSYS2 MinGW 64-bit + mingw-w64-x86_64-openssl
- **CPU**: Intel（Hyper-Threading 开启，核 0+1 为 sibling）

### 6. 执行步骤

#### 配环境步骤

1. 安装 MSYS2 并打开 **MSYS2 MinGW 64-bit**。
2. 安装依赖并编译官方 PoC。
3. 编译 AES 受害者和攻击者。

#### 运行步骤

1. 先运行受害者：start /affinity 2 .\victim_aes.exe
2. 等 2–3 秒后运行攻击者：start /affinity 1 .\attacker_aes.exe
3. 运行 40–60 秒后 Ctrl+C 停止。

### 7. 预期效果

**实际运行结果**

```
0x00 : 0
0x01 : 193357
0x02 : 185416
0x05 : 193791
0x06 : 193438
0x08 : 193748
0x09 : 193879
0x0A : 193806
0x0B : 193884
0x0C : 193817
0x0D : 193861
0x0E : 193811
0x0F : 0
```

- 成功采样到密钥的多个正确字节（0x01、0x02、0x0A、0x0B、0x0C ）。
- 同时出现了不在密钥中的噪声字节（0x05、0x06、0x08、0x09、0x0D、0x0E），这是现代 Intel CPU 微码补丁后的现象（信噪比下降，系统其他进程噪声污染）。
- 单字节命中次数高达 19 万+，证明 fill-buffer 数据采样通道真实存在。
