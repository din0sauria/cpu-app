# ZombieLoad Backend Quick Start

本文件给出最小部署命令和 unified_platform 接入方式。

## 1) 本地启动（Windows）

在 `zombieload-exp` 目录执行：

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:PORT="4047"
python -m uvicorn api_server.main:app --host 0.0.0.0 --port 4047
```

## 2) 本地启动（Linux/macOS）

```bash
cd zombieload-exp
bash scripts/one_click_start.sh
```

## 3) 接口联调

- HTTP base: `http://127.0.0.1:4047`
- WS: `ws://127.0.0.1:4047/attack`
- 接口细节见 `API.md`

## 4) 接入 unified_platform（不改框架代码）

把目录 `zombieload-exp` 拷贝到：

- `Poc_Exp_Backend-main/unified_platform/program/zombieload/`

然后在 `module_registry.json` 添加条目（示例）：

```json
"zombieload_openssl": {
  "source_dir": "zombieload",
  "runtime_subdir": "zombieload",
  "start_command": ["python3", "-m", "uvicorn", "api_server.main:app", "--host", "0.0.0.0", "--port", "4047"],
  "workdir": "zombieload/api_server",
  "env": {"PORT": "4047"},
  "local_api_base": "http://127.0.0.1:4047",
  "event_stream": {"type": "websocket_json", "url": "ws://127.0.0.1:4047/attack"},
  "control": {
    "start": {
      "type": "http",
      "method": "POST",
      "path": "/attack/start",
      "payload_mode": "json",
      "default_payload": {
        "config": {
          "attack_binary": "attacker/variant3_windows/attacker_aes.exe",
          "victim_binary": "victim_aes.exe",
          "auto_start_victim": true,
          "warmup_seconds": 2,
          "runtime_seconds": 60
        }
      }
    },
    "stop": {"type": "http", "method": "POST", "path": "/attack/stop", "payload_mode": "none"},
    "reset": {"type": "http", "method": "POST", "path": "/attack/reset", "payload_mode": "none"},
    "status": {"type": "http", "method": "GET", "path": "/attack/status", "payload_mode": "none"}
  }
}
```

说明：

- 该接入方式不要求修改平台框架代码，仅需新增 registry 条目。
- 后端控制面固定走 HTTP，阶段事件固定走 WS `/attack`。
