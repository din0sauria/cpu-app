import asyncio
import datetime as dt
import json
import os
import platform
import re
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI(title="ZombieLoad OpenSSL API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class StartRequest(BaseModel):
    config: Dict[str, Any] = Field(default_factory=dict)


runtime_lock = asyncio.Lock()
active_websockets: List[WebSocket] = []
runner_task: Optional[asyncio.Task] = None
stop_requested = False

attack_process: Optional[asyncio.subprocess.Process] = None
victim_process: Optional[asyncio.subprocess.Process] = None

status_state: Dict[str, Any] = {
    "status": "idle",
    "current_phase": None,
    "started_at": None,
    "updated_at": None,
    "message": "ZombieLoad backend ready",
}

last_report: Dict[str, Any] = {}
last_summary: Dict[str, Any] = {}


def ts() -> str:
    return dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def module_root() -> Path:
    return Path(__file__).resolve().parents[1]


def update_status(status: str, phase: Optional[str]) -> None:
    status_state["status"] = status
    status_state["current_phase"] = phase
    status_state["updated_at"] = ts()


async def broadcast(payload: Dict[str, Any]) -> None:
    payload.setdefault("timestamp", ts())
    dead: List[WebSocket] = []
    for ws in active_websockets:
        try:
            await ws.send_json(payload)
        except Exception:
            dead.append(ws)
    for ws in dead:
        try:
            active_websockets.remove(ws)
        except ValueError:
            pass


async def emit_phase_start(phase_index: int, phase_name: str, display: str) -> None:
    await broadcast(
        {
            "type": "phase_start",
            "phase": phase_name,
            "phase_id": phase_index - 1,
            "phase_index": phase_index,
            "phase_name": phase_name,
            "display": display,
            "render": "plain_text",
        }
    )


async def emit_phase_progress(phase_index: int, phase_name: str, percent: int, display: str) -> None:
    await broadcast(
        {
            "type": "phase_progress",
            "phase": phase_name,
            "phase_id": phase_index - 1,
            "phase_index": phase_index,
            "phase_name": phase_name,
            "progress": {"percent": max(0, min(100, int(percent)))},
            "display": display,
            "render": "progress_bar",
        }
    )


async def emit_phase_complete(phase_index: int, phase_name: str, result: Dict[str, Any], display: str) -> None:
    await broadcast(
        {
            "type": "phase_complete",
            "phase": phase_name,
            "phase_id": phase_index - 1,
            "phase_index": phase_index,
            "phase_name": phase_name,
            "result": result,
            "display": display,
            "render": "plain_text",
        }
    )


def _resolve_binary(path_value: str) -> Path:
    p = Path(path_value)
    if p.is_absolute():
        return p
    return module_root() / p


async def _terminate_process(proc: Optional[asyncio.subprocess.Process]) -> None:
    if proc is None or proc.returncode is not None:
        return
    try:
        proc.terminate()
        await asyncio.wait_for(proc.wait(), timeout=3)
    except Exception:
        proc.kill()
        await proc.wait()


def _parse_hist_line(line: str) -> Optional[Dict[str, Any]]:
    # Supports both formats:
    #   A: (1303) ####
    #   0x0A : 193806 #####
    m = re.match(r"^\s*(0x[0-9a-fA-F]{2}|[A-Z])\s*:\s*\(?\s*(\d+)\s*\)?\s*(#*)\s*$", line)
    if not m:
        return None

    token = m.group(1)
    hits = int(m.group(2))
    bar = m.group(3) or ""
    if token.startswith("0x"):
        byte_value = int(token, 16)
        label = token.upper()
    else:
        byte_value = ord(token)
        label = f"0x{byte_value:02X}"

    return {
        "byte": byte_value,
        "label": label,
        "hits": hits,
        "bar_len": len(bar),
    }


def _top_candidates(hist: Dict[int, int], k: int = 8) -> List[Dict[str, Any]]:
    ranked = sorted(hist.items(), key=lambda x: x[1], reverse=True)
    result: List[Dict[str, Any]] = []
    for byte_value, hits in ranked[:k]:
        result.append({"byte": byte_value, "label": f"0x{byte_value:02X}", "hits": int(hits)})
    return result


async def _read_attack_stdout(proc: asyncio.subprocess.Process, phase_name: str, hist: Dict[int, int], metrics: Dict[str, Any]) -> None:
    if proc.stdout is None:
        return

    line_counter = 0
    while True:
        raw = await proc.stdout.readline()
        if not raw:
            break

        line = raw.decode(errors="ignore").rstrip()
        if not line:
            continue

        line_counter += 1
        await broadcast({"type": "log", "source": "attacker", "line": line})

        m = re.search(r"Threshold\s*[:=]\s*(\d+)", line, flags=re.IGNORECASE)
        if m:
            threshold = int(m.group(1))
            metrics["threshold"] = threshold
            await broadcast(
                {
                    "type": "discovery",
                    "discovery_type": "cache_miss_threshold",
                    "data": {"threshold": threshold},
                }
            )

        hist_item = _parse_hist_line(line)
        if hist_item is not None:
            hist[hist_item["byte"]] = hist_item["hits"]
            top8 = _top_candidates(hist, k=8)
            await broadcast(
                {
                    "type": "key_byte_candidate",
                    "phase": phase_name,
                    "phase_name": phase_name,
                    "phase_id": 2,
                    "phase_index": 3,
                    "data": hist_item,
                    "top_candidates": top8,
                    "display": "AES key histogram updated",
                    "render": "chart",
                }
            )

            if line_counter % 12 == 0:
                await broadcast(
                    {
                        "type": "phase_progress",
                        "phase": phase_name,
                        "phase_id": 2,
                        "phase_index": 3,
                        "phase_name": phase_name,
                        "progress": {
                            "samples": sum(hist.values()),
                            "top_candidates": top8,
                        },
                        "display": "ZombieLoad sampling in progress",
                        "render": "chart",
                    }
                )


async def _run_attack(config: Dict[str, Any]) -> None:
    global attack_process, victim_process, runner_task, stop_requested, last_report, last_summary

    attack_rel = str(config.get("attack_binary", "attacker/variant3_windows/attacker_aes.exe"))
    victim_rel = str(config.get("victim_binary", "victim_aes.exe"))
    attack_args = [str(x) for x in config.get("attack_args", [])] if isinstance(config.get("attack_args", []), list) else []
    victim_args = [str(x) for x in config.get("victim_args", [])] if isinstance(config.get("victim_args", []), list) else []
    auto_start_victim = bool(config.get("auto_start_victim", True))
    warmup_seconds = max(1, int(config.get("warmup_seconds", 2)))
    runtime_seconds = int(config.get("runtime_seconds", 60))

    attack_bin = _resolve_binary(attack_rel)
    victim_bin = _resolve_binary(victim_rel)

    started_at = ts()
    status_state["started_at"] = started_at
    update_status("running", "environment_build")

    hist: Dict[int, int] = {}
    metrics: Dict[str, Any] = {}

    try:
        await emit_phase_start(1, "environment_build", "Checking ZombieLoad binaries")
        await emit_phase_progress(1, "environment_build", 20, "Resolving attacker/victim paths")

        if not attack_bin.exists():
            raise FileNotFoundError(f"attacker binary not found: {attack_bin}")
        if auto_start_victim and not victim_bin.exists():
            raise FileNotFoundError(f"victim binary not found: {victim_bin}")

        await emit_phase_progress(1, "environment_build", 100, "Environment ready")
        await emit_phase_complete(
            1,
            "environment_build",
            {
                "attack_binary": str(attack_bin),
                "victim_binary": str(victim_bin),
                "auto_start_victim": auto_start_victim,
            },
            "Environment check completed",
        )

        update_status("running", "victim_warmup")
        await emit_phase_start(2, "victim_warmup", "Preparing victim process")

        if auto_start_victim:
            victim_process = await asyncio.create_subprocess_exec(
                str(victim_bin),
                *victim_args,
                cwd=str(module_root()),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
            await broadcast(
                {
                    "type": "discovery",
                    "discovery_type": "victim_started",
                    "data": {
                        "pid": victim_process.pid,
                        "path": str(victim_bin),
                    },
                }
            )

        for step in range(1, warmup_seconds + 1):
            if stop_requested:
                break
            pct = int(step * 100 / warmup_seconds)
            await emit_phase_progress(2, "victim_warmup", pct, f"Victim warmup {step}/{warmup_seconds}s")
            await asyncio.sleep(1)

        await emit_phase_complete(
            2,
            "victim_warmup",
            {"auto_start_victim": auto_start_victim, "warmup_seconds": warmup_seconds},
            "Victim warmup completed",
        )

        if stop_requested:
            raise RuntimeError("stopped by user")

        update_status("running", "zombieload_sampling")
        await emit_phase_start(3, "zombieload_sampling", "Starting attacker and streaming output")

        attack_process = await asyncio.create_subprocess_exec(
            str(attack_bin),
            *attack_args,
            cwd=str(module_root()),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )

        read_task = asyncio.create_task(_read_attack_stdout(attack_process, "zombieload_sampling", hist, metrics))

        elapsed = 0
        while True:
            if stop_requested:
                break
            if attack_process.returncode is not None:
                break
            if runtime_seconds > 0 and elapsed >= runtime_seconds:
                await broadcast(
                    {
                        "type": "phase_progress",
                        "phase": "zombieload_sampling",
                        "phase_id": 2,
                        "phase_index": 3,
                        "phase_name": "zombieload_sampling",
                        "progress": {"elapsed_seconds": elapsed, "timeout_seconds": runtime_seconds},
                        "display": "Runtime limit reached, stopping attacker",
                        "render": "plain_text",
                    }
                )
                break

            await asyncio.sleep(1)
            elapsed += 1

        await _terminate_process(attack_process)
        await read_task

        samples = sum(hist.values())
        top8 = _top_candidates(hist, k=8)
        secret_preview = " ".join(item["label"] for item in _top_candidates(hist, k=16))

        if secret_preview:
            await broadcast(
                {
                    "type": "secret_leaked",
                    "secret_data": secret_preview,
                    "display": "Top leaked byte candidates generated",
                    "render": "plain_text",
                }
            )

        await emit_phase_complete(
            3,
            "zombieload_sampling",
            {
                "sample_count": samples,
                "top_candidates": top8,
                "threshold": metrics.get("threshold"),
                "runtime_seconds": elapsed,
            },
            "ZombieLoad sampling finished",
        )

        update_status("running", "report_generation")
        await emit_phase_start(4, "report_generation", "Generating markdown report")

        finished_at = ts()
        report_md_lines = [
            "# ZombieLoad OpenSSL AES Report",
            "",
            f"- started_at: {started_at}",
            f"- finished_at: {finished_at}",
            f"- auto_start_victim: {auto_start_victim}",
            f"- threshold: {metrics.get('threshold')}",
            f"- sample_count: {samples}",
            "",
            "## Top byte candidates",
        ]

        if top8:
            for i, item in enumerate(top8, start=1):
                report_md_lines.append(f"{i}. {item['label']} => {item['hits']}")
        else:
            report_md_lines.append("- No histogram data collected")

        report_md = "\n".join(report_md_lines) + "\n"

        success = bool((not stop_requested) and samples > 0)
        report_obj = {
            "report_id": uuid.uuid4().hex,
            "module": "zombieload",
            "success": success,
            "started_at": started_at,
            "finished_at": finished_at,
            "summary": "ZombieLoad OpenSSL AES sampling finished",
            "findings": [
                {
                    "threshold": metrics.get("threshold"),
                    "sample_count": samples,
                    "top_candidates": top8,
                }
            ],
            "artifacts": [
                {
                    "name": "zombieload_report.md",
                    "format": "markdown",
                }
            ],
        }

        last_report = report_obj
        last_summary = {
            "sample_count": samples,
            "top_candidates": top8,
            "threshold": metrics.get("threshold"),
        }

        await broadcast(
            {
                "type": "report_file",
                "phase": "report_generation",
                "phase_id": 3,
                "phase_index": 4,
                "phase_name": "report_generation",
                "report_file": {
                    "name": "zombieload_report.md",
                    "format": "markdown",
                    "content": report_md,
                },
                "display": "Report generated",
                "render": "markdown",
            }
        )

        await emit_phase_complete(
            4,
            "report_generation",
            {"report_id": report_obj["report_id"], "report_name": "zombieload_report.md"},
            "Report generation completed",
        )

        await broadcast(
            {
                "type": "attack_complete",
                "success": success,
                "report": report_obj,
            }
        )

        update_status("stopped", "report_generation")
    except Exception as exc:
        update_status("error", status_state.get("current_phase"))
        await broadcast({"type": "error", "message": str(exc)})
        await broadcast({"type": "attack_complete", "success": False})
    finally:
        await _terminate_process(attack_process)
        await _terminate_process(victim_process)
        attack_process = None
        victim_process = None
        runner_task = None
        stop_requested = False


@app.get("/status")
async def service_status() -> Dict[str, Any]:
    alive = bool(runner_task and not runner_task.done())
    return {
        "status": "active" if alive else "idle",
        "timestamp": ts(),
        "message": "ZombieLoad attack service ready",
        "version": "1.0.0",
    }


@app.get("/metadata")
async def metadata() -> Dict[str, Any]:
    return {
        "os": f"{platform.system()} {platform.release()}",
        "kernel": platform.release(),
        "arch": platform.machine(),
        "cpu": platform.processor(),
        "hostname": platform.node(),
        "timestamp": ts(),
    }


@app.get("/attack/status")
async def attack_status() -> Dict[str, Any]:
    return {
        "status": status_state.get("status", "idle"),
        "current_phase": status_state.get("current_phase"),
        "started_at": status_state.get("started_at"),
        "updated_at": status_state.get("updated_at"),
        "message": status_state.get("message"),
        "report": last_report,
        "last_summary": last_summary,
        "timestamp": ts(),
    }


@app.post("/attack/start")
async def attack_start(req: StartRequest) -> Dict[str, Any]:
    global runner_task, stop_requested

    async with runtime_lock:
        if runner_task and not runner_task.done():
            return {"status": "running", "message": "attack already running", "timestamp": ts()}

        stop_requested = False
        update_status("running", "environment_build")
        runner_task = asyncio.create_task(_run_attack(req.config))
        return {"status": "running", "message": "attack started", "timestamp": ts()}


@app.post("/attack/stop")
async def attack_stop() -> Dict[str, Any]:
    global stop_requested

    stop_requested = True
    await _terminate_process(attack_process)
    await _terminate_process(victim_process)
    update_status("stopped", status_state.get("current_phase"))
    await broadcast({"type": "log", "source": "control", "line": "Stop requested"})
    return {"status": "stopped", "message": "stop signal accepted", "timestamp": ts()}


@app.post("/attack/reset")
async def attack_reset() -> Dict[str, Any]:
    global last_report, last_summary, stop_requested

    await attack_stop()
    stop_requested = False
    last_report = {}
    last_summary = {}
    status_state["status"] = "idle"
    status_state["current_phase"] = None
    status_state["started_at"] = None
    status_state["updated_at"] = ts()
    return {"status": "reset", "message": "state reset", "timestamp": ts()}


@app.websocket("/attack")
async def ws_attack(websocket: WebSocket) -> None:
    await websocket.accept()
    active_websockets.append(websocket)
    await websocket.send_json(
        {
            "type": "hello",
            "module": "zombieload",
            "timestamp": ts(),
        }
    )
    try:
        while True:
            raw = await websocket.receive_text()
            try:
                message = json.loads(raw)
            except Exception:
                await websocket.send_json({"type": "error", "message": "invalid json", "timestamp": ts()})
                continue

            action = str(message.get("action", "")).strip().lower()
            if action == "start":
                cfg = message.get("config", {}) if isinstance(message.get("config", {}), dict) else {}
                await attack_start(StartRequest(config=cfg))
            elif action == "stop":
                await attack_stop()
            elif action == "reset":
                await attack_reset()
            else:
                await websocket.send_json({"type": "error", "message": f"unknown action: {action}", "timestamp": ts()})
    except WebSocketDisconnect:
        pass
    finally:
        try:
            active_websockets.remove(websocket)
        except ValueError:
            pass


if __name__ == "__main__":
    import uvicorn

    port = int(os.environ.get("PORT", "4047"))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=False)
