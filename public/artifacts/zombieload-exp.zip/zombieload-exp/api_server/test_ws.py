import asyncio
import json

import websockets


async def main() -> None:
    uri = "ws://127.0.0.1:4047/attack"
    async with websockets.connect(uri) as ws:
        await ws.send(json.dumps({"action": "start", "config": {"runtime_seconds": 15}}))
        while True:
            msg = await ws.recv()
            print(msg)


if __name__ == "__main__":
    asyncio.run(main())
