#include <openssl/evp.h>
#include <stdio.h>
#include <windows.h>
int main() {
    unsigned char key[16] = {0x01,0x01,0x02,0x02,0x03,0x02,0x0a,0x04,0x03,0x03,0x0a,0x05,0x0c,0x0c,0x0b,0x0b};
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    printf("[Victim AES] Key 正在循环加载中... (固定在 CPU 1)\n");
    while(1) {
        EVP_EncryptInit_ex(ctx, EVP_aes_128_ecb(), NULL, key, NULL);
        Sleep(300);
    }
    return 0;
}
