$ErrorActionPreference = "Stop"

Set-Location (Join-Path $PSScriptRoot "..")

python -m venv .venv
. .\.venv\Scripts\Activate.ps1
pip install -r requirements.txt

if (-not $env:PORT) { $env:PORT = "4047" }
python -m uvicorn api_server.main:app --host 0.0.0.0 --port $env:PORT
