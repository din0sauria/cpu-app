#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
PORT="${PORT:-4047}" python3 -m uvicorn api_server.main:app --host 0.0.0.0 --port "$PORT"
