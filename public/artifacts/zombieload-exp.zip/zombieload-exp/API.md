# ZombieLoad Attack Service API

本文档描述 zombieload 模块后端接口，满足 unified_platform 的模块接入规范。

## Base

- Default port: `4047`
- Base URL: `http://127.0.0.1:4047`
- WS URL: `ws://127.0.0.1:4047/attack`

## Required Control APIs

### POST /attack/start

Request:

```json
{
  "config": {
    "attack_binary": "attacker/variant3_windows/attacker_aes.exe",
    "victim_binary": "victim_aes.exe",
    "auto_start_victim": true,
    "warmup_seconds": 2,
    "runtime_seconds": 60,
    "attack_args": [],
    "victim_args": []
  }
}
```

Response:

```json
{
  "status": "running",
  "message": "attack started",
  "timestamp": "2026-04-07T10:00:00Z"
}
```

### POST /attack/stop

Response:

```json
{
  "status": "stopped",
  "message": "stop signal accepted",
  "timestamp": "2026-04-07T10:00:00Z"
}
```

### POST /attack/reset

Response:

```json
{
  "status": "reset",
  "message": "state reset",
  "timestamp": "2026-04-07T10:00:00Z"
}
```

### GET /attack/status

Response:

```json
{
  "status": "idle",
  "current_phase": null,
  "started_at": null,
  "updated_at": "2026-04-07T10:00:00Z",
  "message": "ZombieLoad backend ready",
  "report": {},
  "last_summary": {},
  "timestamp": "2026-04-07T10:00:00Z"
}
```

## Optional Compatibility APIs

### GET /status

### GET /metadata

两者用于与既有演示前端保持兼容，不影响 unified_platform 标准接入。

## WebSocket

### WS /attack

客户端可发送：

```json
{"action": "start", "config": {}}
```

```json
{"action": "stop"}
```

```json
{"action": "reset"}
```

服务端事件包含 `timestamp`，核心类型：

- `phase_start`
- `phase_progress`
- `phase_complete`
- `log`
- `discovery`
- `key_byte_candidate`
- `secret_leaked`
- `report_file` (markdown，且先于 `attack_complete`)
- `attack_complete`
- `error`

## Fixed Phases

1. `environment_build`
2. `victim_warmup`
3. `zombieload_sampling`
4. `report_generation`
