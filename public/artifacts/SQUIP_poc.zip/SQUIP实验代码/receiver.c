// receiver.c - 探测端
// 基于 SQUIP 论文 Listing 1 复现
// 编译: gcc -O2 receiver.c -o receiver

#include <inttypes.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <x86intrin.h>

// 使用 rdtsc 读取时间戳 (论文在跨 VM 实验中使用了此方法 [cite: 448])
static inline uint64_t get_time() {
    unsigned int dummy;
    _mm_lfence();
    uint64_t t = __rdtscp(&dummy);
    _mm_lfence();
    return t;
}

// 核心函数：测量插入 n 个乘法指令所需的时间
static uint64_t measure(int n_muls) {
    uint64_t start, end;
    
    // 初始化
    asm volatile("movq $1, %%r15\n\t" "cvtsi2sd %%r15, %%xmm0" ::: "r15", "xmm0");
    
    // 预热/重置寄存器
    asm volatile(
        "movq $1, %%r15\n\t"
        "cvtsi2sd %%r15, %%xmm0\n\t" 
        ::: "r15", "xmm0"
    );

    // --- 开始测量 ---
    start = get_time();

    // 1. 制造“路障” (Delay Block) [cite: 187-199]
    // 使用 sqrtsd 制造长延迟，堵住流水线前端，让后面的乘法指令堆积在调度器中
    // 增加指令数，扩大观测窗口，提升在嘈杂环境中的可观测性。
    asm volatile(
        "sqrtsd %%xmm0, %%xmm0\n\t"
        "sqrtsd %%xmm0, %%xmm0\n\t"
        "sqrtsd %%xmm0, %%xmm0\n\t"
        "sqrtsd %%xmm0, %%xmm0\n\t"
        "sqrtsd %%xmm0, %%xmm0\n\t"
        "sqrtsd %%xmm0, %%xmm0\n\t"
        "sqrtsd %%xmm0, %%xmm0\n\t"
        "sqrtsd %%xmm0, %%xmm0\n\t"
        "sqrtsd %%xmm0, %%xmm0\n\t"
        "sqrtsd %%xmm0, %%xmm0\n\t"
        ::: "xmm0"
    );

    // 【关键修复】 2. 建立依赖桥梁
    // 这条指令强制要求：必须等上面的 sqrtsd 全算完，才能更新 r15
    // 从而迫使下面的 imul 必须在队列里死等
    asm volatile(
        "cvtsd2si %%xmm0, %%r15\n\t"
        ::: "xmm0", "r15"
    );

    // 3. 填充乘法队列
    for (int i = 0; i < n_muls; i++) {
        asm volatile(
            "imulq $3, %%r15\n\t" 
            ::: "r15", "cc"
        );
    }

    end = get_time();
    return (end - start);
}

static int cmp_u64(const void *a, const void *b) {
    uint64_t ua = *(const uint64_t *)a;
    uint64_t ub = *(const uint64_t *)b;
    return (ua > ub) - (ua < ub);
}

int main(int argc, char **argv) {
    int samples = 50000;
    int rounds = 7;
    int n_start = 10;
    int n_end = 40;

    if (argc > 1) samples = atoi(argv[1]);
    if (argc > 2) rounds = atoi(argv[2]);
    if (argc > 3) n_start = atoi(argv[3]);
    if (argc > 4) n_end = atoi(argv[4]);

    if (samples <= 0 || rounds <= 0 || n_start <= 0 || n_end < n_start) {
        fprintf(stderr, "Usage: %s [samples] [rounds] [n_start] [n_end]\n", argv[0]);
        fprintf(stderr, "Example: %s 50000 7 10 40\n", argv[0]);
        return 1;
    }

    uint64_t *round_vals = malloc((size_t)rounds * sizeof(uint64_t));
    if (round_vals == NULL) {
        perror("malloc");
        return 1;
    }

    printf("=== SQUIP Receiver (Probe) ===\n");
    printf("Scanning scheduler queue size...\n");
    printf("Config: samples=%d rounds=%d range=[%d,%d]\n", samples, rounds, n_start, n_end);
    printf("N_MULS\t| MEDIAN_CYCLES\n");
    printf("------\t| -------------\n");

    // 预热，先让指令路径稳定下来，减少首轮抖动
    for (int w = 0; w < 2000; w++) {
        (void)measure(25);
    }

    for (int n = n_start; n <= n_end; n++) {
        for (int r = 0; r < rounds; r++) {
            uint64_t total = 0;
            for (int i = 0; i < samples; i++) {
                total += measure(n);
            }
            round_vals[r] = total / (uint64_t)samples;
        }
        qsort(round_vals, (size_t)rounds, sizeof(uint64_t), cmp_u64);
        printf("%d\t| %" PRIu64 "\n", n, round_vals[rounds / 2]);
    }

    free(round_vals);
    return 0;
}
