// sender.c - 受害端 (制造竞争)
// 编译: gcc -O2 sender.c -o sender

#include <stdio.h>

int main() {
    printf("=== SQUIP Sender (Victim) ===\n");
    printf("Running infinite multiplication loop...\n");
    printf("Press Ctrl+C to stop.\n");

    // 使用单个内联汇编死循环，尽量减少 C 循环开销，持续占用乘法相关调度资源。
    asm volatile(
        "movq $1, %%r15\n\t"
        "1:\n\t"
        "imulq $3, %%r15\n\t"
        "imulq $3, %%r15\n\t"
        "imulq $3, %%r15\n\t"
        "imulq $3, %%r15\n\t"
        "imulq $3, %%r15\n\t"
        "imulq $3, %%r15\n\t"
        "imulq $3, %%r15\n\t"
        "imulq $3, %%r15\n\t"
        "imulq $3, %%r15\n\t"
        "imulq $3, %%r15\n\t"
        "imulq $3, %%r15\n\t"
        "imulq $3, %%r15\n\t"
        "imulq $3, %%r15\n\t"
        "imulq $3, %%r15\n\t"
        "imulq $3, %%r15\n\t"
        "imulq $3, %%r15\n\t"
        "jmp 1b\n\t"
        ::: "r15", "cc"
    );

    return 0;
}
