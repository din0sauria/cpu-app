# Meltdown-CPL-REG & CounterLeak

## 本项目具体说明

Reviving Meltdown 3a 项目完整复现了 2023 年 ESORICS 论文《Reviving Meltdown 3a》的所有核心 PoC，重点验证了 Meltdown-CPL-REG（也称 Meltdown 3a）在现代 CPU 上的残留攻击面，以及基于该漏洞提出的 **CounterLeak** 攻击原语。

本项目通过自动化工具 RegCheck 系统性扫描系统寄存器泄露情况，并分别复现了 pocs/ 目录下的基础寄存器泄露 PoC，以及论文中的两个高级案例研究：

- Spectre with CounterLeak
- Zigzagger Bypass

实验在 **12th Gen Intel Core i5-1235U (Alder Lake)** + VMware Workstation 虚拟机环境下完成。最终所有 PoC 均未观察到有效泄露，与论文中“the newest Intel CPUs do not seem affected by Meltdown-CPL-REG”“We observe that the tested Intel CPUs

from Alder Lake onward do not show leakage”的结论完全一致，验证了 Alder Lake 架构对该漏洞的硬件级缓解效果，同时也体现了虚拟化环境对微架构侧信道攻击的显著限制。

## 涉及资源

- **Meltdown-CPL-REG (Meltdown 3a)**
  
  - **位置**：CPU 微架构（特权级别检查前瞬态执行）
  - **功能**：允许非特权代码瞬态读取仅限特权访问的系统寄存器（MSR、性能计数器等）
  - **利用**：通过 rdpmc、rdfsbase、rdtsc 等指令在故障回滚前将寄存器值编码到微架构状态（缓存）

- **CounterLeak 攻击原语**
  
  - **位置**：性能监控单元 (PMU)
  - **功能**：瞬态读取性能计数器（INSTR_RETIRED、CYCLES_DIV_BUSY、DTLB misses 等）
  - **利用**：将泄露的计数器值编码到缓存中，通过 Flush+Reload 作为隐蔽信道，实现 Spectre、KASLR Bypass、Zigzagger 绕过等高级攻击

- **Flush+Reload 侧信道**
  
  - **位置**：CPU L1/L2 缓存
  - **功能**：通过缓存命中/未命中时序差异传输微架构状态
  - **利用**：将瞬态读取的寄存器值编码到大数组的不同页面，攻击者通过计时恢复数据

- **性能计数器 (Performance Counters)**
  
  - **位置**：CPU PMU
  - **功能**：记录微架构事件（分支、除法、页面遍历等）
  - **利用**：在 CounterLeak 中作为信息源，重新启用原本被权限限制的性能计数器侧信道攻击

## 攻击原理

Meltdown-CPL-REG（也称 Meltdown 3a）是一种瞬态执行（Transient Execution）漏洞，核心在于 CPU 在执行**特权指令**（如 rdpmc、rdfsbase、rdtsc 等）时，会在**当前特权级别检查（CPL 检查）完成之前**，就先推测执行（speculatively execute）这条指令。

即使后续检查发现当前是用户态（非特权），CPU 也会把这条指令的**结果**短暂地留在微架构状态中（例如加载到寄存器或缓存），然后才回滚（rollback）。攻击者利用这个短暂的“瞬态窗口”（transient window），通过侧信道把结果泄露出来。

#### 核心攻击链（CounterLeak 原语）

1. **触发瞬态执行** 攻击者（用户态程序）执行一条特权指令，例如：
   
   - rdpmc（读取性能计数器）
   - rdfsbase（读取 FS base 寄存器）
   - rdtsc（读取时间戳计数器）
   
   CPU 在检查当前是否特权之前，就已经把寄存器的值**瞬态加载**到内部缓冲区或寄存器中。

2. **编码瞬态值到微架构状态** 在 CPU 发现权限错误并回滚之前，攻击者立即用这个瞬态值做一些操作，例如：
   
   ```
   uint64_t value = rdpmc(...);           // 瞬态读取性能计数器值
   char *buffer = attacker_controlled_array;
   buffer[value & 0xFF * PAGE_SIZE] = 1;  // 用低 8 位作为索引访问数组
   ```
   
   - 这会把瞬态值（例如一个字节）**编码**到缓存中：对应索引的页面被加载到缓存（cache line）。

3. **使用 Flush+Reload 侧信道恢复值** 攻击者接下来遍历一个很大的数组（通常 256 个页面，每个页面对应一个可能字节值 0~255）：
   
   ```
   for (int i = 0; i < 256; i++) {
      time = measure_time(buffer + i * PAGE_SIZE);
      if (time < THRESHOLD) {  // Cache Hit → 说明刚才被瞬态访问过
          leaked_byte = i;
      }
   }
   ```
   
   - **快**（Cache Hit）：说明这个页面刚才被瞬态执行访问过 → 这个索引就是泄露的字节。
   - **慢**（Cache Miss）：说明没被访问。
   - 通过多次重复，攻击者可以恢复出性能计数器或寄存器的低位内容 → 这就是 **CounterLeak 原语**。

4. **利用 CounterLeak 实现高级攻击** 一旦 CounterLeak 能可靠泄露性能计数器值，就可以把这些计数器当作**隐蔽信道**，用于各种高级利用（论文 Section 6）：
   
   - **Spectre V1 变种**（论文 6.1）
     利用分支预测器误训练，让受害者代码执行一个除法指令（division），然后用 CounterLeak 泄露 division 事件计数（CYCLES_DIV_BUSY），判断分支是否被推测执行，从而泄露秘密位。论文中速率 66.7 bit/s，准确率 99.6%。
   - **KASLR Bypass**（论文 6.2）
     遍历潜在内核地址，访问页面时会触发页面表遍历（page walk）。用 CounterLeak 泄露 DTLB_LOAD_MISSES.WALK_COMPLETED 计数，判断页面是否现存（present），从而找到内核基址（如 __start_rodata）。
   - **Zigzagger Bypass**（论文 6.4）
     Zigzagger 用间接跳转 + conditional move 隐藏分支方向。CounterLeak 泄露 INSTR_RETIRED（已退役指令数），不同分支路径的退役指令数不同，攻击者通过计数差异推断秘密分支方向。
   - **RSA 密钥提取**（论文 6.3）
     针对 MbedTLS 的平方-乘实现（window size=1），每次处理秘密位时会执行不同数量的分支。CounterLeak 泄露 BR_INST_RETIRED.NEAR_TAKEN（被采纳的近分支指令数），多次测量后平均掉噪声，恢复 RSA 私钥（2048-bit 密钥约 15 分钟）。

**核心原理**：

1. Meltdown-CPL-REG 允许非特权代码在权限检查前瞬态读取特权系统寄存器。
2. 将读取到的值编码到缓存（通过数组访问）。
3. 使用 Flush+Reload 侧信道恢复编码值，形成 CounterLeak 原语。
4. CounterLeak 可作为通用隐蔽信道，实现 Spectre、KASLR 绕过、Zigzagger 破坏及加密密钥提取。

## 项目核心代码文件

代码路径：[GitHub - cispa/regcheck: Proof-of-concept implementation for the paper "Reviving Meltdown 3a" (ESORICS 2023)](https://github.com/cispa/regcheck/tree/main)

- **`regcheck`**：RegCheck 主分析工具，用于扫描所有系统寄存器泄露情况（对应论文 Section 3）。
- **`pocs/rdpmc.c`**：CounterLeak 核心基础 PoC，用于验证性能计数器泄露。
- **`pocs/rdfsbase.c`、`rdgsbase.c`、`rdtsc.c`**：基础寄存器泄露 PoC（论文 Table 2）。
- **`zigzagger-bypass/main.c`**：Zigzagger Bypass 案例，使用 INSTR_RETIRED 计数绕过分支阴影缓解。
- **`spectre-counterleak/spectre.c`**：Spectre with CounterLeak 案例，使用性能计数器作为隐蔽信道实现 Spectre V1。
- **`spectre-counterleak/run.sh`**：Spectre 实验统一运行脚本。

重要限制：VMware Workstation 不支持在此主机上使用虚拟化性能计数器。尝试启用该选项时，报错：“VMware Workstation does not support virtualized performance counters on this host. ... Module 'VPMC' power on failed. Failed to start the virtual machine.”（详见 VMware KB 81623: https://kb.vmware.com/s/article/81623）。
由于论文中的 CounterLeak 攻击原语高度依赖 rdpmc 指令读取性能计数器（PMU），虚拟化性能计数器的缺失导致 guest 中无法获取真实的硬件 PMU 数据，rdpmc 瞬态泄露和侧信道精度严重受限。这是本实验无法复现论文中泄露结果的原因之一。

## 运行环境

- **软件环境**：
  
  - **Host 系统**：Windows 11 + VMware Workstation
  - **Guest 系统**：Ubuntu 20.04 LTS（Focal）
  - **内核版本**：Linux 5.15
  - **语言**：C, Python3, Bash
  - **编译工具**：gcc, make

- **硬件版本**：
  
  - **CPU**：12th Gen Intel Core i5-1235U (Alder Lake)
  - **架构**：x86_64
  - **虚拟化**：VMware Workstation

## 执行步骤

### 配环境步骤

1. **配置 GRUB 参数**（隔离核心 + 允许 rdpmc）：
   
   ```bash
   sudo nano /etc/default/grub
   ```
   
   修改为：
   
   ```
   GRUB_CMDLINE_LINUX_DEFAULT="quiet splash isolcpus=1 nofsgsbase rdpmc=2"
   ```
   
   ```bash
   sudo update-grub && sudo reboot
   ```

2. **启用非特权 rdpmc**：
   
   ```bash
   echo 2 | sudo tee /sys/devices/cpu/rdpmc
   ```

3. **安装必要工具**：
   
   ```bash
   sudo apt update
   sudo apt install build-essential msr-tools -y
   ```

### 运行步骤

1. **RegCheck 系统扫描**：
   
   ```bash
   cd regcheck
   make
   sudo ./run.sh
   ```

2. **pocs 基础泄露测试**：
   
   ```bash
   cd ../pocs
   make
   sudo taskset -c 0 ./rdpmc
   sudo taskset -c 0 ./rdfsbase
   sudo taskset -c 0 ./rdgsbase
   sudo taskset -c 0 ./rdtsc
   sudo taskset -c 0 ./sldt-zf
   sudo taskset -c 0 ./str-zf
   ```

3. **Zigzagger Bypass**：
   
   ```bash
   cd ../zigzagger-bypass
   sudo ./start_counter.sh
   make
   sudo ./main
   ```

4. **Spectre with CounterLeak**：
   
   ```bash
   cd ../spectre-counterleak
   sudo ./start_counter.sh
   make
   sudo ./run.sh
   ```

### 预期效果

**运行日志示例**：

1. RegCheck 系统扫描

![](C:\Users\hanyu.LAPTOP-2MUU7OUI\AppData\Roaming\marktext\images\2026-02-26-17-17-03-屏幕截图%202026-02-26%20161336.png)

检测到 12th Gen Intel Core i5-1235U（Alder Lake 架构），微码版本 0xffffffff，识别为 VMware 环境。Flush+Reload 检测到 Cache miss（@275），但无任何系统寄存器泄露标记。所有测试结果为无泄露或因 MSR 写失败而跳过。

2. pocs 基础泄露测试

![](C:\Users\hanyu.LAPTOP-2MUU7OUI\AppData\Roaming\marktext\images\2026-02-26-17-18-04-屏幕截图%202026-02-26%20165006.png)

- wrmsr 失败 → 无法配置性能计数器（虚拟机常见）。
- 输出了多组值，但最后两位是 XX（掩码隐藏），值变化很大（f902023a → 6902023a → f9020245 → b5b5b5f8 等），**没有稳定模式**。
- 这些值 **不是泄露的寄存器内容**，而是工具在尝试读取时捕获的噪声或随机值。
- 论文中如果有泄露，会看到**重复的、稳定的模式**（如连续相同的高位 + 变化的低位），这里没有。
- **结论**：**无泄露**。rdpmc 没有成功瞬态泄露性能计数器值。

![](C:\Users\hanyu.LAPTOP-2MUU7OUI\AppData\Roaming\marktext\images\2026-02-26-17-18-11-屏幕截图%202026-02-26%20165232.png)

- 工具尝试把 rdfsbase 的值（64 位）逐位（或逐 nibble）瞬态编码到缓存数组中。
- 输出的是 “hit @ 0xXX” → 表示在哪个缓存索引命中（Flush+Reload 检测到瞬态访问）。
- **正常泄露**：应该看到连续的 hit 索引对应一个固定或有规律的值（比如连续 hit 0x0f → 0x00 → 0xf1 等，形成字节）。
- 这里 hit 值非常随机（f1 → e6 → 8d → db → 29 → ... → b0），**没有形成任何可解读的字节序列**。
- **结论**：**无泄露**。rdfsbase 没有被成功瞬态读取。

![](C:\Users\hanyu.LAPTOP-2MUU7OUI\AppData\Roaming\marktext\images\2026-02-26-17-18-24-屏幕截图%202026-02-26%20165322.png)

输出：没有内容

- 工具运行后直接退出，没有打印任何 hit 或值。
- 很可能因为 CPU / 虚拟机环境**直接拒绝或过滤了 rdgsbase**，导致瞬态执行失败或无侧信道信号。
- **结论**：**无泄露**。

![](C:\Users\hanyu.LAPTOP-2MUU7OUI\AppData\Roaming\marktext\images\2026-02-26-17-18-34-屏幕截图%202026-02-26%20165332.png)

- Ground Truth 显示了 rdtsc 的真实值（高位 0x24，低位被掩码）。
- 但工具试图瞬态读取并通过侧信道恢复，却只花了大量周期（1.6 亿周期），没有进一步打印泄露值。
- 没有看到恢复出的值，说明侧信道没有捕获到瞬态 rdtsc 内容。
- **结论**：**无泄露**。

![](C:\Users\hanyu.LAPTOP-2MUU7OUI\AppData\Roaming\marktext\images\2026-02-26-17-18-43-屏幕截图%202026-02-26%20165337.png)

![](C:\Users\hanyu.LAPTOP-2MUU7OUI\AppData\Roaming\marktext\images\2026-02-26-17-19-26-image.png)

- 工具明确报错 “PoC does not work on this system!”。
- **结论**：**无泄露**，zero-forwarding 路径也不存在。
3. Zigzagger Bypass

![](C:\Users\hanyu.LAPTOP-2MUU7OUI\AppData\Roaming\marktext\images\2026-02-26-17-20-00-image.png)

- 脚本尝试配置 IA32_PERFEVTSEL0 MSR（地址 0x186）来启用 INSTR_RETIRED（已退役指令计数器）。
- 第一个 wrmsr 成功（写了 0x4100C0）。
- 第二个 wrmsr 失败（试图写 MSR 0x38f，可能是另一个控制寄存器）。
- **结论**：性能计数器部分配置成功（INSTR_RETIRED 很可能已启用），但虚拟机环境导致部分 MSR 写失败。

![](C:\Users\hanyu.LAPTOP-2MUU7OUI\AppData\Roaming\marktext\images\2026-02-26-17-20-41-image.png)

- - 大多数 arg 是 0（无差异）。
  - 非零值分布随机，没有模式可用于区分秘密参数。
- 结论：攻击失败，无法有效绕过 Zigzagger。
4. Spectre with CounterLeak

![](C:\Users\hanyu.LAPTOP-2MUU7OUI\AppData\Roaming\marktext\images\2026-02-26-17-21-24-image.png)

- 成功写入了主事件选择寄存器（IA32_PERFEVTSEL0），配置了 division-related 事件
- 第二个 wrmsr 失败（MSR 0x38f）

![](C:\Users\hanyu.LAPTOP-2MUU7OUI\AppData\Roaming\marktext\images\2026-02-26-17-21-41-image.png)

- **Cache miss @ 300** Flush+Reload 侧信道初始化成功，检测到缓存 miss（噪声基线正常）。
- **targeting offset 8176 ('A') / 8177 ('B')**
  - PoC 在攻击一个 Spectre gadget，目标是泄露内存中的秘密字符（'A' 和 'B'）。
  - offset 8176/8177 是数组索引，用于编码秘密值。
- **每 run 的输出格式**：
  - 第一行：原始测量值（逗号分隔），例如 11,0,11,11,0,11
  - elapsed_items：本次测量的次数（5~7 次）。
  - run X -> Y.YYYYYY (min: Z - avg: W) --> setting V
    - Y：平均值或泄露分数。
    - min/avg：最小值和平均值。
    - setting V：工具根据阈值（HIT_THRESHOLD）判断是否为 '1' 或 '0'。
- **实际泄露分数**：
  - 大多数 run 的平均值在 0~11 之间波动。
  - 最高 avg 22（run 9），但整体 **没有稳定高于阈值的模式**。
  - 工具多次设置 setting 0（判断为 0），说明泄露信号太弱，无法可靠区分 '1' 和 '0'。
- **curr_leak**：
  - 没有打印最终泄露的秘密字符或 bit 序列。
  - 说明攻击未成功恢复出 'A' 或 'B'（或任何秘密）。

**实际实验效果**：

- 所有 PoC 均未观察到有效泄露，与论文中 Alder Lake 架构已缓解的结论完全一致。
- 虚拟机环境进一步导致 PMU 不完整、噪声极大，侧信道精度严重不足。
- 本实验成功验证了论文的核心发现：Meltdown-CPL-REG 在现代 Intel CPU 上已被有效缓解，CounterLeak 攻击原语在 Alder Lake + 虚拟化环境下无法实用。

---




