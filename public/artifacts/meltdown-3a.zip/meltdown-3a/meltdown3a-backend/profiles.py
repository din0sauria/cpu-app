from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Dict, List


@dataclass(frozen=True)
class PhaseStep:
    phase: str
    phase_id: int
    display_name: str
    cwd: str
    command: str


@dataclass(frozen=True)
class AttackProfile:
    name: str
    description: str
    steps: List[PhaseStep]


def _profile_steps() -> Dict[str, AttackProfile]:
    return {
        "regcheck_scan": AttackProfile(
            name="regcheck_scan",
            description="Compile and run RegCheck scanner.",
            steps=[
                PhaseStep("initialize", 0, "初始化", "regcheck", "make"),
                PhaseStep("scan_registers", 1, "寄存器扫描", "regcheck", "sudo -n ./run.sh"),
            ],
        ),
        "poc_rdpmc": AttackProfile(
            name="poc_rdpmc",
            description="Run rdpmc leakage PoC.",
            steps=[
                PhaseStep("initialize", 0, "初始化", "pocs", "make"),
                PhaseStep("leak_raw_data", 1, "泄露原始数据", "pocs", "sudo -n taskset -c 0 ./rdpmc"),
            ],
        ),
        "poc_rdfsbase": AttackProfile(
            name="poc_rdfsbase",
            description="Run rdfsbase leakage PoC.",
            steps=[
                PhaseStep("initialize", 0, "初始化", "pocs", "make"),
                PhaseStep("leak_raw_data", 1, "泄露原始数据", "pocs", "sudo -n taskset -c 0 ./rdfsbase"),
            ],
        ),
        "poc_rdgsbase": AttackProfile(
            name="poc_rdgsbase",
            description="Run rdgsbase leakage PoC.",
            steps=[
                PhaseStep("initialize", 0, "初始化", "pocs", "make"),
                PhaseStep("leak_raw_data", 1, "泄露原始数据", "pocs", "sudo -n taskset -c 0 ./rdgsbase"),
            ],
        ),
        "poc_rdtsc": AttackProfile(
            name="poc_rdtsc",
            description="Run rdtsc leakage PoC.",
            steps=[
                PhaseStep("initialize", 0, "初始化", "pocs", "make"),
                PhaseStep("leak_raw_data", 1, "泄露原始数据", "pocs", "sudo -n taskset -c 0 ./rdtsc"),
            ],
        ),
        "kaslr_break": AttackProfile(
            name="kaslr_break",
            description="Run KASLR break case study with CounterLeak.",
            steps=[
                PhaseStep("initialize", 0, "初始化", "kaslr-break", "make"),
                PhaseStep("break_code_aslr", 1, "破解代码ASLR", "kaslr-break", "sudo -n ./run.sh"),
            ],
        ),
        "spectre_counterleak": AttackProfile(
            name="spectre_counterleak",
            description="Run Spectre with CounterLeak case study.",
            steps=[
                PhaseStep("initialize", 0, "初始化", "spectre-counterleak", "make"),
                PhaseStep("leak_raw_data", 1, "泄露原始数据", "spectre-counterleak", "sudo -n ./run.sh"),
            ],
        ),
        "zigzagger_bypass": AttackProfile(
            name="zigzagger_bypass",
            description="Run Zigzagger bypass case study.",
            steps=[
                PhaseStep("initialize", 0, "初始化", "zigzagger-bypass", "make"),
                PhaseStep("analyze_retired_instructions", 1, "指令计数分析", "zigzagger-bypass", "sudo -n ./main"),
            ],
        ),
    }


PROFILES = _profile_steps()


def get_profiles_summary() -> Dict[str, dict]:
    summary: Dict[str, dict] = {}
    for key, profile in PROFILES.items():
        summary[key] = {
            "name": profile.name,
            "description": profile.description,
            "steps": [
                {
                    "phase": s.phase,
                    "phase_id": s.phase_id,
                    "display_name": s.display_name,
                    "cwd": s.cwd,
                    "command": s.command,
                }
                for s in profile.steps
            ],
        }
    return summary


def resolve_cwd(project_root: str, relative_cwd: str) -> str:
    cwd = os.path.abspath(os.path.join(project_root, relative_cwd))
    root = os.path.abspath(project_root)
    if not cwd.startswith(root):
        raise ValueError(f"Invalid cwd: {relative_cwd}")
    return cwd
