from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import dataclass
from typing import Dict, List, Tuple
from urllib.parse import urlparse

import asyncio
import websockets


@dataclass
class DemoCase:
    name: str
    profile: str
    timeout_sec: int
    must_log_keywords: List[str]


CASES: List[DemoCase] = [
    DemoCase(
        name="RegCheck system scan",
        profile="regcheck_scan",
        timeout_sec=240,
        must_log_keywords=["Cache miss", "No leakage", "Finished"],
    ),
    DemoCase(
        name="PoC rdpmc",
        profile="poc_rdpmc",
        timeout_sec=180,
        must_log_keywords=["Cache miss", "PoC", "hit"],
    ),
    DemoCase(
        name="PoC rdfsbase",
        profile="poc_rdfsbase",
        timeout_sec=180,
        must_log_keywords=["hit", "PoC", "work"],
    ),
    DemoCase(
        name="PoC rdgsbase",
        profile="poc_rdgsbase",
        timeout_sec=180,
        must_log_keywords=["PoC", "work", "Cache miss"],
    ),
    DemoCase(
        name="PoC rdtsc",
        profile="poc_rdtsc",
        timeout_sec=180,
        must_log_keywords=["Ground Truth", "Cache miss", "cycles"],
    ),
    DemoCase(
        name="Zigzagger bypass",
        profile="zigzagger_bypass",
        timeout_sec=240,
        must_log_keywords=["Retired", "Arg1", "Error", "wrmsr"],
    ),
    DemoCase(
        name="Spectre with CounterLeak",
        profile="spectre_counterleak",
        timeout_sec=300,
        must_log_keywords=["Cache miss", "targeting offset", "success rate"],
    ),
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Verify Meltdown 3a backend demo flows via WebSocket events")
    parser.add_argument(
        "--ws-url",
        default="ws://127.0.0.1:38030/attack",
        help="WebSocket URL of backend, e.g. ws://127.0.0.1:38030/attack",
    )
    return parser.parse_args()


async def run_case(ws, case: DemoCase) -> Tuple[bool, Dict[str, str]]:
    start_msg = {
        "action": "start",
        "config": {
            "profile": case.profile,
        },
    }
    await ws.send(json.dumps(start_msg))

    t0 = time.time()
    phase_start_seen = False
    phase_complete_seen = False
    attack_complete = None
    logs: List[str] = []
    events_seen = 0
    last_log_line = ""
    heartbeat_interval = 5
    next_heartbeat_at = t0 + heartbeat_interval

    while True:
        now = time.time()
        elapsed = now - t0
        if elapsed > case.timeout_sec:
            return False, {
                "reason": f"timeout after {case.timeout_sec}s",
                "events": "incomplete",
            }

        if now >= next_heartbeat_at:
            tail = last_log_line[:120] if last_log_line else "(no log yet)"
            print(
                f"  ... {case.profile} running {int(elapsed)}s | "
                f"events={events_seen} | logs={len(logs)} | last_log={tail}"
            )
            next_heartbeat_at = now + heartbeat_interval

        try:
            raw = await asyncio.wait_for(ws.recv(), timeout=1)
        except asyncio.TimeoutError:
            continue

        msg = json.loads(raw)
        t = msg.get("type", "")
        events_seen += 1

        if t == "phase_start":
            phase_start_seen = True

        if t == "phase_complete":
            phase_complete_seen = True

        if t == "log":
            line = str(msg.get("line", ""))
            logs.append(line)
            last_log_line = line

        if t == "attack_complete":
            attack_complete = msg
            break

    if attack_complete is None:
        return False, {
            "reason": "missing attack_complete",
            "events": "incomplete",
        }

    success_flag = bool(attack_complete.get("success", False))
    lines = "\n".join(logs[-400:]).lower()

    keyword_hits = 0
    for kw in case.must_log_keywords:
        if kw.lower() in lines:
            keyword_hits += 1

    plumbing_ok = phase_start_seen and phase_complete_seen
    content_ok = keyword_hits >= 1

    passed = plumbing_ok and content_ok
    details = {
        "backend_flow": "ok" if plumbing_ok else "bad",
        "attack_complete_success": str(success_flag),
        "keyword_hits": f"{keyword_hits}/{len(case.must_log_keywords)}",
        "log_lines": str(len(logs)),
    }
    if not passed:
        details["reason"] = "missing expected phases or logs"
    return passed, details


async def main() -> int:
    args = parse_args()
    parsed = urlparse(args.ws_url)
    if parsed.scheme not in ("ws", "wss"):
        print("FAIL: ws-url must start with ws:// or wss://")
        return 2

    print(f"Connecting: {args.ws_url}")
    try:
        async with websockets.connect(args.ws_url, max_size=8 * 1024 * 1024) as ws:
            # consume initial info message if present
            try:
                raw = await asyncio.wait_for(ws.recv(), timeout=5)
                msg = json.loads(raw)
                if msg.get("type") != "info":
                    # keep behavior simple; if not info we continue
                    pass
            except Exception:
                pass

            summary: List[Tuple[DemoCase, bool, Dict[str, str]]] = []
            for case in CASES:
                print(f"\n=== Running: {case.name} ({case.profile}) ===")
                passed, details = await run_case(ws, case)
                summary.append((case, passed, details))
                print("PASS" if passed else "FAIL", details)

            all_ok = all(s[1] for s in summary)
            print("\n========== SUMMARY ==========")
            for case, passed, details in summary:
                status = "PASS" if passed else "FAIL"
                print(f"{status} | {case.name} | {case.profile} | {details}")

            return 0 if all_ok else 1
    except Exception as e:
        print(f"FAIL: cannot connect or run tests: {e}")
        return 2


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
