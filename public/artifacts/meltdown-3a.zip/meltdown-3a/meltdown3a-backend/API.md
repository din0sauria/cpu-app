# Meltdown 3a Attack Service API 文档

本文档描述 `regcheck-main/meltdown3a-backend` 的接口。

## 基本信息

- 默认端口: `3030`
- 基础 URL: `http://localhost:3030`
- WebSocket URL: `ws://localhost:3030/attack`

---

## HTTP 接口

### 1. 服务状态检查

- Endpoint: `/status`
- Method: `GET`

响应示例:

```json
{
  "status": "active",
  "timestamp": "2026-03-30T10:00:00.000Z",
  "message": "Meltdown 3a backend ready",
  "version": "1.0.0",
  "active_run": {
    "run_id": "...",
    "profile": "spectre_counterleak",
    "started_at": "2026-03-30T10:00:00.000Z",
    "stop_requested": false
  }
}
```

### 2. 获取可用攻击配置

- Endpoint: `/profiles`
- Method: `GET`

响应里会包含每个 profile 的阶段、工作目录和命令。

### 3. 启动攻击（HTTP）

- Endpoint: `/attack/start`
- Method: `POST`

请求示例:

```json
{
  "profile": "kaslr_break",
  "config": {
    "extra_args": []
  }
}
```

### 4. 停止攻击（HTTP）

- Endpoint: `/attack/stop`
- Method: `POST`

### 5. 重置状态

- Endpoint: `/attack/reset`
- Method: `POST`

### 6. 获取系统元数据

- Endpoint: `/metadata`
- Method: `GET`

---

## WebSocket 接口

- URL: `ws://localhost:3030/attack`

### 客户端发送消息

#### 1) 开始攻击

```json
{
  "action": "start",
  "config": {
    "profile": "regcheck_scan",
    "extra_args": []
  }
}
```

#### 2) 停止攻击

```json
{
  "action": "stop"
}
```

#### 3) 心跳

```json
{
  "action": "ping"
}
```

### 服务端推送消息

所有消息包含 `type` 和 `timestamp`。

#### 1) 错误

```json
{
  "type": "error",
  "message": "错误描述",
  "timestamp": "..."
}
```

#### 2) 原始日志

```json
{
  "type": "log",
  "phase": "break_code_aslr",
  "phase_id": 1,
  "line": "search at 0x...: ......",
  "timestamp": "..."
}
```

#### 3) 阶段开始

```json
{
  "type": "phase_start",
  "phase": "break_code_aslr",
  "phase_id": 1,
  "display_name": "破解代码ASLR",
  "timestamp": "..."
}
```

#### 4) 阶段进度

```json
{
  "type": "phase_progress",
  "phase": "break_code_aslr",
  "phase_id": 1,
  "progress": {
    "current": "0x555540000000",
    "dots": 28
  },
  "message": "search at 0x555540000000: ......",
  "timestamp": "..."
}
```

#### 5) 发现信息

```json
{
  "type": "discovery",
  "discovery_type": "victim_address",
  "data": {
    "address": "0x...",
    "verified": true
  },
  "timestamp": "..."
}
```

#### 6) 驱逐集进度

```json
{
  "type": "eviction_set_progress",
  "phase": "l3_eviction_sets",
  "phase_id": 3,
  "progress": {
    "stage": "build",
    "dots": 5,
    "message": "build: ....."
  },
  "timestamp": "..."
}
```

#### 7) Secret 泄露

```json
{
  "type": "secret_leaked",
  "secret_data": "ABC...",
  "timestamp": "..."
}
```

#### 8) 阶段完成

```json
{
  "type": "phase_complete",
  "phase": "leak_raw_data",
  "phase_id": 1,
  "result": {
    "time_seconds": 3.141593,
    "return_code": 0
  },
  "timestamp": "..."
}
```

#### 9) 攻击结束

```json
{
  "type": "attack_complete",
  "success": true,
  "stopped": false,
  "total_time_seconds": 12.34,
  "phase_times": {
    "initialize": 0.12,
    "leak_raw_data": 12.22
  },
  "total_lines": 500,
  "timestamp": "..."
}
```
