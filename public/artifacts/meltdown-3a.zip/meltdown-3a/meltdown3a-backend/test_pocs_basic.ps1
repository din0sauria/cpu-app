param(
    [string]$BaseUrl = "http://127.0.0.1:38030",
    [int]$PollSec = 3,
    [int]$TimeoutPerCaseSec = 300
)

$ErrorActionPreference = "Stop"

$profilesToRun = @(
    "poc_rdpmc",
    "poc_rdfsbase",
    "poc_rdgsbase",
    "poc_rdtsc"
)

function Get-Status {
    Invoke-RestMethod -Uri "$BaseUrl/status" -Method Get
}

function Stop-Attack {
    Invoke-RestMethod -Uri "$BaseUrl/attack/stop" -Method Post | Out-Null
}

function Start-Profile([string]$profileName) {
    $body = @{ profile = $profileName; config = @{} } | ConvertTo-Json -Depth 5
    Invoke-RestMethod -Uri "$BaseUrl/attack/start" -Method Post -ContentType "application/json" -Body $body
}

Write-Host "[pocs-test] Base URL: $BaseUrl"

# 1) Backend and profile checks
$status = Get-Status
Write-Host "[pocs-test] Backend status: $($status.status)"

$profilesResp = Invoke-RestMethod -Uri "$BaseUrl/profiles" -Method Get
$profileNames = @($profilesResp.profiles.PSObject.Properties.Name)
foreach ($p in $profilesToRun) {
    if (-not ($profileNames -contains $p)) {
        Write-Host "[pocs-test] ERROR: profile missing -> $p"
        Write-Host "[pocs-test] Available profiles: $($profileNames -join ', ')"
        exit 2
    }
}

$results = @()

foreach ($profile in $profilesToRun) {
    Write-Host ""
    Write-Host "[pocs-test] ===== Running $profile ====="

    $curr = Get-Status
    if ($curr.status -eq "active") {
        Write-Host "[pocs-test] Existing run detected. Stopping it first..."
        Stop-Attack
        Start-Sleep -Seconds 2
    }

    try {
        $startResp = Start-Profile -profileName $profile
        $runId = $startResp.run.run_id
        Write-Host "[pocs-test] Start response: $($startResp.status), run_id=$runId"
    } catch {
        Write-Host "[pocs-test] FAIL start profile=$profile error=$($_.Exception.Message)"
        $results += [PSCustomObject]@{ profile = $profile; status = "start-failed"; elapsed = 0 }
        continue
    }

    $startTime = Get-Date
    $finalStatus = "unknown"

    while ($true) {
        $s = Get-Status
        $elapsed = [int]((Get-Date) - $startTime).TotalSeconds
        $runInfo = "none"
        if ($s.active_run) {
            $runInfo = "profile=$($s.active_run.profile), run_id=$($s.active_run.run_id), stop_requested=$($s.active_run.stop_requested)"
        }

        Write-Host "[pocs-test] $profile t=${elapsed}s status=$($s.status) active_run=[$runInfo]"

        if ($s.status -eq "idle") {
            $finalStatus = "completed"
            break
        }

        if ($elapsed -ge $TimeoutPerCaseSec) {
            Write-Host "[pocs-test] TIMEOUT for $profile after ${TimeoutPerCaseSec}s. Sending stop..."
            Stop-Attack
            $finalStatus = "timeout"
            break
        }

        Start-Sleep -Seconds $PollSec
    }

    $elapsedFinal = [int]((Get-Date) - $startTime).TotalSeconds
    $results += [PSCustomObject]@{
        profile = $profile
        status  = $finalStatus
        elapsed = $elapsedFinal
    }
}

Write-Host ""
Write-Host "[pocs-test] ===== SUMMARY ====="
$results | Format-Table -AutoSize

$hasFailure = $results | Where-Object { $_.status -ne "completed" }
if ($hasFailure) {
    exit 1
}
exit 0
