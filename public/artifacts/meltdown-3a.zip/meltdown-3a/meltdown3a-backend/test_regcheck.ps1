param(
    [string]$BaseUrl = "http://127.0.0.1:38030",
    [int]$PollSec = 3,
    [int]$TimeoutSec = 900
)

$ErrorActionPreference = "Stop"

function Get-Status {
    Invoke-RestMethod -Uri "$BaseUrl/status" -Method Get
}

function Stop-Attack {
    Invoke-RestMethod -Uri "$BaseUrl/attack/stop" -Method Post | Out-Null
}

Write-Host "[regcheck-test] Base URL: $BaseUrl"

# 1) Check backend reachable
$status = Get-Status
Write-Host "[regcheck-test] Backend status: $($status.status)"

# 2) Check profile exists
$profilesResp = Invoke-RestMethod -Uri "$BaseUrl/profiles" -Method Get
$profileNames = @($profilesResp.profiles.PSObject.Properties.Name)
if (-not ($profileNames -contains "regcheck_scan")) {
    Write-Host "[regcheck-test] ERROR: profile regcheck_scan not found."
    Write-Host "[regcheck-test] Available profiles: $($profileNames -join ', ')"
    exit 2
}

# 3) Stop previous running task if needed
if ($status.status -eq "active") {
    Write-Host "[regcheck-test] Existing run detected. Stopping it first..."
    Stop-Attack
    Start-Sleep -Seconds 2
}

# 4) Start regcheck_scan
$body = @{ profile = "regcheck_scan"; config = @{} } | ConvertTo-Json -Depth 5
$startResp = Invoke-RestMethod -Uri "$BaseUrl/attack/start" -Method Post -ContentType "application/json" -Body $body
Write-Host "[regcheck-test] Start response: $($startResp.status)"
if ($startResp.run) {
    Write-Host "[regcheck-test] Run ID: $($startResp.run.run_id)"
}

# 5) Poll status until idle or timeout
$startTime = Get-Date
while ($true) {
    $s = Get-Status
    $elapsed = [int]((Get-Date) - $startTime).TotalSeconds

    $runInfo = "none"
    if ($s.active_run) {
        $runInfo = "profile=$($s.active_run.profile), run_id=$($s.active_run.run_id), stop_requested=$($s.active_run.stop_requested)"
    }

    Write-Host "[regcheck-test] t=${elapsed}s status=$($s.status) active_run=[$runInfo]"

    if ($s.status -eq "idle") {
        Write-Host "[regcheck-test] Completed."
        break
    }

    if ($elapsed -ge $TimeoutSec) {
        Write-Host "[regcheck-test] TIMEOUT after ${TimeoutSec}s. Sending stop..."
        Stop-Attack
        exit 1
    }

    Start-Sleep -Seconds $PollSec
}

# 6) Final status snapshot
$finalStatus = Get-Status
Write-Host "[regcheck-test] Final status JSON:"
$finalStatus | ConvertTo-Json -Depth 8
