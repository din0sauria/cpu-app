# Meltdown 3a Backend

这个目录提供 regcheck-main 的后端服务实现，技术路线与前端约定一致：

- HTTP 状态与控制接口
- WebSocket 实时攻击流接口

默认端口为 3030。

## 1. 快速启动（Linux）

```bash
cd meltdown3a-backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn main:app --host 0.0.0.0 --port 3030
```

## 2. Windows PowerShell 一键启动

在 meltdown3a-backend 目录执行：

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\run.ps1 -Port 38030
```

可选参数：

```powershell
.\run.ps1 -HostAddress 127.0.0.1 -Port 3030
.\run.ps1 -SkipInstall
```

## 3. 接口地址

- HTTP: `http://localhost:3030`
- WebSocket: `ws://localhost:3030/attack`

如果你用 38030 端口启动，则对应改为：

- HTTP: `http://127.0.0.1:38030`
- WebSocket: `ws://127.0.0.1:38030/attack`

## 4. 可用攻击 Profile

通过 GET /profiles 查看完整列表。默认内置：

- regcheck_scan
- poc_rdpmc
- poc_rdfsbase
- poc_rdgsbase
- poc_rdtsc
- kaslr_break
- spectre_counterleak
- zigzagger_bypass

说明：当前命令均使用 sudo -n（非交互），避免后端卡在密码输入。

## 5. 常用调用示例

### 5.1 HTTP 启动攻击

```bash
curl -X POST http://localhost:3030/attack/start \
  -H "Content-Type: application/json" \
  -d '{"profile":"spectre_counterleak","config":{}}'
```

### 5.2 HTTP 停止攻击

```bash
curl -X POST http://localhost:3030/attack/stop
```

### 5.3 WebSocket 启动攻击

客户端发送：

```json
{
  "action": "start",
  "config": {
    "profile": "kaslr_break"
  }
}
```

客户端停止：

```json
{
  "action": "stop"
}
```

## 6. 环境变量

- MELTDOWN3A_HOST: 监听地址，默认 0.0.0.0
- MELTDOWN3A_PORT: 端口，默认 3030
- MELTDOWN3A_PROJECT_ROOT: 项目根目录，默认 regcheck-main
- MELTDOWN3A_ALLOW_ORIGINS: CORS 白名单，逗号分隔，默认 *

## 7. 一键验证四类演示

后端运行后执行：

```powershell
.\.venv\Scripts\python.exe .\verify_backend_demos.py --ws-url ws://127.0.0.1:38030/attack
```

脚本会依次验证：

- RegCheck 系统扫描
- pocs 基础泄露测试（rdpmc/rdfsbase/rdgsbase/rdtsc）
- Zigzagger Bypass
- Spectre with CounterLeak

## 8. 单项测试脚本

### 8.1 只测 RegCheck

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\test_regcheck.ps1 -BaseUrl http://127.0.0.1:38030 -PollSec 3 -TimeoutSec 180
```

### 8.2 只测 pocs 基础泄露测试

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\test_pocs_basic.ps1 -BaseUrl http://127.0.0.1:38030 -PollSec 3 -TimeoutPerCaseSec 300
```
