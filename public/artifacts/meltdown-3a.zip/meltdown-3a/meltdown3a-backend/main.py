from __future__ import annotations

import asyncio
import datetime as dt
import json
import os
import platform
import re
import shlex
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from profiles import PROFILES, get_profiles_summary, resolve_cwd


load_dotenv()

HOST = os.environ.get("MELTDOWN3A_HOST", "0.0.0.0")
PORT = int(os.environ.get("MELTDOWN3A_PORT", "3030"))
PROJECT_ROOT = os.path.abspath(
    os.environ.get(
        "MELTDOWN3A_PROJECT_ROOT",
        str(Path(__file__).resolve().parent.parent),
    )
)
ALLOW_ORIGINS = [s.strip() for s in os.environ.get("MELTDOWN3A_ALLOW_ORIGINS", "*").split(",") if s.strip()]
DEFAULT_SHELL = "powershell" if os.name == "nt" else "bash"

app = FastAPI(title="Meltdown 3a Backend API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOW_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def now_ts() -> str:
    return dt.datetime.utcnow().isoformat() + "Z"


def strip_ansi(line: str) -> str:
    return re.sub(r"\x1B\[[0-?]*[ -/]*[@-~]", "", line)


RE_HEX = r"0x[0-9a-fA-F]+"
RE_SEARCH = re.compile(r"^search at\s+({}):\s*(\.+)$".format(RE_HEX))
RE_VICTIM = re.compile(r"victim at\s+({})".format(RE_HEX), re.IGNORECASE)
RE_BUFFER = re.compile(r"buffer at\s+({})".format(RE_HEX), re.IGNORECASE)
RE_HIT = re.compile(r"\[\+\]\s*hit\s*@\s*({})".format(RE_HEX), re.IGNORECASE)
RE_KSYM = re.compile(r"ksymbol\s+([a-zA-Z0-9_]+)\s*@\s*({})", re.IGNORECASE)
RE_SUCCESS_RATE = re.compile(r"success rate:\s*(\d+)\s*/\s*(\d+)\s*\(([^\)]+)\)", re.IGNORECASE)
RE_LEAK_RATE = re.compile(r"leakage rate:\s*([0-9\.]+)\s*bit/s", re.IGNORECASE)
RE_TARGETING = re.compile(r"targeting offset\s+(\d+)\s+\('(.+)'\)", re.IGNORECASE)
RE_CURR_LEAK = re.compile(r"curr_leak:\s*(.+)", re.IGNORECASE)
RE_CACHE_MISS = re.compile(r"Cache miss(?:\s*\(CT\))?\s*@\s*(\d+)", re.IGNORECASE)
RE_TRY_HIT = re.compile(r"Try\s+(\d+):\s+Got hit on index\s+(0x[0-9a-fA-F]+)\s+\(delta:\s*(\d+)\)", re.IGNORECASE)
RE_DOTS = re.compile(r"^(build|optimize):\s*(\.+)$", re.IGNORECASE)


class AttackStartRequest(BaseModel):
    profile: Optional[str] = None
    config: Dict[str, Any] = Field(default_factory=dict)


class AttackRunInfo(BaseModel):
    run_id: str
    profile: str
    status: str
    started_at: str


@dataclass
class RunState:
    run_id: str
    profile: str
    started_at: float
    phase_times: Dict[str, float] = field(default_factory=dict)
    total_lines: int = 0
    process: Optional[asyncio.subprocess.Process] = None
    task: Optional[asyncio.Task] = None
    stop_requested: bool = False
    report_markdown: str = ""


class AttackManager:
    def __init__(self) -> None:
        self._state: Optional[RunState] = None
        self._lock = asyncio.Lock()
        self._clients: Set[WebSocket] = set()
        self._last_status: str = "idle"
        self._last_execution_summary: Optional[Dict[str, Any]] = None
        self._last_report_summary: Optional[Dict[str, Any]] = None

    def is_running(self) -> bool:
        return self._state is not None and self._state.task is not None and not self._state.task.done()

    async def register_ws(self, ws: WebSocket) -> None:
        self._clients.add(ws)

    async def unregister_ws(self, ws: WebSocket) -> None:
        self._clients.discard(ws)

    async def _broadcast(self, message: Dict[str, Any]) -> None:
        if "timestamp" not in message:
            message["timestamp"] = now_ts()
        dead: List[WebSocket] = []
        for ws in self._clients:
            try:
                await ws.send_json(message)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self._clients.discard(ws)

    async def get_status(self) -> Dict[str, Any]:
        if not self._state:
            return {
                "status": "idle",
                "active_run": None,
                "last_execution_summary": self._last_execution_summary,
                "last_report_summary": self._last_report_summary,
            }
        return {
            "status": "running" if self.is_running() else self._last_status,
            "active_run": {
                "run_id": self._state.run_id,
                "profile": self._state.profile,
                "started_at": dt.datetime.utcfromtimestamp(self._state.started_at).isoformat() + "Z",
                "stop_requested": self._state.stop_requested,
            },
            "last_execution_summary": self._last_execution_summary,
            "last_report_summary": self._last_report_summary,
        }

    def _phase_payload(
        self,
        phase_index: int,
        phase_name: str,
        display: str,
        render: str,
    ) -> Dict[str, Any]:
        return {
            "phase_index": phase_index,
            "phase_name": phase_name,
            "display": display,
            "render": render,
        }

    def _build_report_markdown(self, run: RunState, success: bool, stopped: bool, total_elapsed: float) -> str:
        started_at = dt.datetime.utcfromtimestamp(run.started_at).isoformat() + "Z"
        finished_at = now_ts()
        lines = [
            "# Meltdown 3a 检测报告",
            "",
            "## 执行概览",
            f"- Run ID: `{run.run_id}`",
            f"- Profile: `{run.profile}`",
            f"- Success: `{success and not stopped}`",
            f"- Stopped: `{stopped}`",
            f"- Started At: `{started_at}`",
            f"- Finished At: `{finished_at}`",
            f"- Total Time (s): `{round(total_elapsed, 6)}`",
            f"- Total Output Lines: `{run.total_lines}`",
            "",
            "## 阶段耗时",
        ]
        if run.phase_times:
            for name, duration in run.phase_times.items():
                lines.append(f"- {name}: `{round(duration, 6)}` s")
        else:
            lines.append("- 无阶段数据")
        return "\n".join(lines) + "\n"

    async def start(self, profile_name: str, config: Dict[str, Any]) -> AttackRunInfo:
        async with self._lock:
            if self.is_running():
                raise RuntimeError("An attack profile is already running.")
            if profile_name not in PROFILES:
                raise RuntimeError(f"Unknown profile: {profile_name}")

            run = RunState(
                run_id=str(uuid.uuid4()),
                profile=profile_name,
                started_at=time.time(),
            )
            run.task = asyncio.create_task(self._run(run, config))
            self._state = run

        return AttackRunInfo(
            run_id=run.run_id,
            profile=run.profile,
            status="running",
            started_at=dt.datetime.utcfromtimestamp(run.started_at).isoformat() + "Z",
        )

    async def stop(self) -> bool:
        async with self._lock:
            if not self._state:
                return False
            self._state.stop_requested = True
            process = self._state.process

        if process and process.returncode is None:
            process.terminate()
            try:
                await asyncio.wait_for(process.wait(), timeout=5)
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
        return True

    async def reset(self) -> None:
        await self.stop()

    async def _run(self, run: RunState, config: Dict[str, Any]) -> None:
        profile = PROFILES[run.profile]
        shell = config.get("shell", DEFAULT_SHELL)
        env_overrides = config.get("env", {})
        extra_args = config.get("extra_args", [])

        self._last_status = "running"

        success = True
        total_start = time.perf_counter()

        try:
            for idx, step in enumerate(profile.steps):
                if run.stop_requested:
                    success = False
                    break

                phase_start = time.perf_counter()
                is_environment_phase = idx == 0
                phase_index = idx + 1
                phase_name = "environment_build" if is_environment_phase else step.phase
                render = "progress_bar" if is_environment_phase else "plain_text"
                await self._broadcast(
                    {
                        "type": "phase_start",
                        "phase": phase_name,
                        "phase_id": phase_index,
                        "display_name": step.display_name,
                        **self._phase_payload(
                            phase_index=phase_index,
                            phase_name=phase_name,
                            display=step.display_name,
                            render=render,
                        ),
                        "timestamp": now_ts(),
                    }
                )

                command = step.command
                if idx == len(profile.steps) - 1 and extra_args:
                    command = command + " " + " ".join(shlex.quote(str(a)) for a in extra_args)

                rc = await self._run_command(
                    run,
                    shell,
                    command,
                    resolve_cwd(PROJECT_ROOT, step.cwd),
                    env_overrides,
                    phase_name,
                    phase_index,
                    is_environment_phase,
                )
                elapsed = time.perf_counter() - phase_start
                run.phase_times[phase_name] = elapsed

                await self._broadcast(
                    {
                        "type": "phase_complete",
                        "phase": phase_name,
                        "phase_id": phase_index,
                        **self._phase_payload(
                            phase_index=phase_index,
                            phase_name=phase_name,
                            display=f"{step.display_name} 完成",
                            render=render,
                        ),
                        "result": {
                            "time_seconds": round(elapsed, 6),
                            "return_code": rc,
                        },
                    }
                )

                if rc != 0:
                    success = False
                    break
        except Exception as exc:
            success = False
            await self._broadcast(
                {
                    "type": "error",
                    "message": f"Runner exception: {exc}",
                }
            )
            report_phase_index = len(profile.steps) + 1
            report_phase_name = "report_generation"
            report_phase_display = "生成报告"
            await self._broadcast(
                {
                    "type": "phase_start",
                    "phase": report_phase_name,
                    "phase_id": report_phase_index,
                    "display_name": report_phase_display,
                    **self._phase_payload(
                        phase_index=report_phase_index,
                        phase_name=report_phase_name,
                        display=report_phase_display,
                        render="markdown",
                    ),
                    "timestamp": now_ts(),
                }
            )
        finally:
            total_elapsed = time.perf_counter() - total_start
            run.report_markdown = self._build_report_markdown(run, success, run.stop_requested, total_elapsed)

            report_phase_index = len(profile.steps) + 1
            report_phase_name = "report_generation"
            report_id = str(uuid.uuid4())
            started_at = dt.datetime.utcfromtimestamp(run.started_at).isoformat() + "Z"
            finished_at = now_ts()
            report_summary = {
                "report_id": report_id,
                "module": "meltdown3a_regcheck",
                "success": success and not run.stop_requested,
                "started_at": started_at,
                "finished_at": finished_at,
                "summary": f"profile={run.profile}, success={success and not run.stop_requested}, total_lines={run.total_lines}",
                "findings": [],
                "artifacts": [],
            }

            await self._broadcast(
                {
                    "type": "report_file",
                    "phase": report_phase_name,
                    "phase_id": report_phase_index,
                    **self._phase_payload(
                        phase_index=report_phase_index,
                        phase_name=report_phase_name,
                        display="报告已生成",
                        render="markdown",
                    ),
                    "report_file": {
                        "name": f"{run.run_id}.md",
                        "format": "markdown",
                        "content": run.report_markdown,
                    },
                    "timestamp": now_ts(),
                }
            )

            await self._broadcast(
                {
                    "type": "phase_complete",
                    "phase": report_phase_name,
                    "phase_id": report_phase_index,
                    **self._phase_payload(
                        phase_index=report_phase_index,
                        phase_name=report_phase_name,
                        display="报告阶段完成",
                        render="markdown",
                    ),
                    "result": {
                        "time_seconds": 0.0,
                        "return_code": 0,
                    },
                    "timestamp": now_ts(),
                }
            )

            await self._broadcast(
                {
                    "type": "attack_complete",
                    "success": success and not run.stop_requested,
                    "stopped": run.stop_requested,
                    "total_time_seconds": round(total_elapsed, 6),
                    "phase_times": {k: round(v, 6) for k, v in run.phase_times.items()},
                    "total_lines": run.total_lines,
                    "report": report_summary,
                }
            )

            self._last_status = "stopped" if run.stop_requested else ("idle" if success else "error")
            self._last_execution_summary = {
                "run_id": run.run_id,
                "profile": run.profile,
                "status": self._last_status,
                "stopped": run.stop_requested,
                "success": success and not run.stop_requested,
                "total_time_seconds": round(total_elapsed, 6),
                "total_lines": run.total_lines,
                "finished_at": finished_at,
            }
            self._last_report_summary = {
                "report_id": report_summary["report_id"],
                "format": "markdown",
                "name": f"{run.run_id}.md",
                "generated_at": finished_at,
                "summary": report_summary["summary"],
            }
            self._state = None

    def _build_shell_command(self, shell: str, command: str) -> List[str]:
        normalized = shell.lower()
        if normalized in {"bash", "sh", "zsh"}:
            return [shell, "-lc", command]
        if normalized in {"powershell", "pwsh"}:
            return [shell, "-NoProfile", "-Command", command]
        if normalized == "cmd":
            return ["cmd", "/c", command]
        return [shell, "-c", command]

    async def _run_command(
        self,
        run: RunState,
        shell: str,
        command: str,
        cwd: str,
        env_overrides: Dict[str, str],
        phase: str,
        phase_id: int,
        is_environment_phase: bool,
    ) -> int:
        env = os.environ.copy()
        env.update({str(k): str(v) for k, v in env_overrides.items()})

        shell_cmd = self._build_shell_command(shell, command)
        try:
            process = await asyncio.create_subprocess_exec(
                *shell_cmd,
                cwd=cwd,
                env=env,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
        except Exception as exc:
            await self._broadcast(
                {
                    "type": "error",
                    "phase": phase,
                    "phase_id": phase_id,
                    "message": f"Failed to launch command with shell '{shell}': {exc}",
                }
            )
            return 127
        run.process = process

        if process.stdout is not None:
            while True:
                raw = await process.stdout.readline()
                if not raw:
                    break

                line = strip_ansi(raw.decode("utf-8", errors="ignore").rstrip("\n"))
                run.total_lines += 1
                await self._broadcast({"type": "log", "phase": phase, "phase_id": phase_id, "line": line})

                if is_environment_phase:
                    percent = min(90, 10 + run.total_lines * 3)
                    await self._broadcast(
                        {
                            "type": "phase_progress",
                            "phase": phase,
                            "phase_id": phase_id,
                            **self._phase_payload(
                                phase_index=phase_id,
                                phase_name="environment_build",
                                display="环境依赖构建中",
                                render="progress_bar",
                            ),
                            "progress": {"percent": percent},
                            "message": "环境依赖构建中",
                            "timestamp": now_ts(),
                        }
                    )

                for evt in self._parse_line(line, phase, phase_id):
                    await self._broadcast(evt)

                if run.stop_requested and process.returncode is None:
                    process.terminate()

        rc = await process.wait()
        run.process = None
        return rc

    def _parse_line(self, line: str, phase: str, phase_id: int) -> List[Dict[str, Any]]:
        events: List[Dict[str, Any]] = []
        if not line:
            return events

        m = RE_SEARCH.search(line)
        if m:
            events.append(
                {
                    "type": "phase_progress",
                    "phase": "break_code_aslr",
                    "phase_id": 1,
                    "progress": {
                        "current": m.group(1),
                        "dots": len(m.group(2)),
                    },
                    "message": line,
                }
            )

        m = RE_DOTS.search(line)
        if m:
            events.append(
                {
                    "type": "eviction_set_progress",
                    "phase": phase,
                    "phase_id": phase_id,
                    "progress": {
                        "stage": m.group(1).lower(),
                        "dots": len(m.group(2)),
                        "message": line,
                    },
                }
            )

        m = RE_VICTIM.search(line)
        if m:
            events.append(
                {
                    "type": "discovery",
                    "discovery_type": "victim_address",
                    "data": {"address": m.group(1), "verified": True},
                }
            )

        m = RE_BUFFER.search(line)
        if m:
            events.append(
                {
                    "type": "discovery",
                    "discovery_type": "reload_buffer",
                    "data": {"address": m.group(1), "verified": True},
                }
            )

        m = RE_HIT.search(line)
        if m:
            events.append(
                {
                    "type": "discovery",
                    "discovery_type": "hit_address",
                    "data": {"address": m.group(1)},
                }
            )

        m = RE_KSYM.search(line)
        if m:
            events.append(
                {
                    "type": "discovery",
                    "discovery_type": "kernel_symbol",
                    "data": {"symbol": m.group(1), "address": m.group(2)},
                }
            )

        m = RE_CACHE_MISS.search(line)
        if m:
            events.append(
                {
                    "type": "discovery",
                    "discovery_type": "cache_miss_baseline",
                    "data": {"cycles": int(m.group(1))},
                }
            )

        m = RE_TRY_HIT.search(line)
        if m:
            events.append(
                {
                    "type": "phase_progress",
                    "phase": phase,
                    "phase_id": phase_id,
                    "progress": {
                        "try": int(m.group(1)),
                        "index": m.group(2),
                        "delta": int(m.group(3)),
                    },
                    "message": line,
                }
            )

        m = RE_TARGETING.search(line)
        if m:
            events.append(
                {
                    "type": "phase_progress",
                    "phase": phase,
                    "phase_id": phase_id,
                    "progress": {
                        "offset": int(m.group(1)),
                        "expected_char": m.group(2),
                    },
                    "message": line,
                }
            )

        m = RE_CURR_LEAK.search(line)
        if m:
            events.append(
                {
                    "type": "secret_leaked",
                    "secret_data": m.group(1),
                }
            )

        if line.startswith("Leaked:"):
            events.append(
                {
                    "type": "secret_leaked",
                    "secret_data": line.split(":", 1)[1].strip(),
                }
            )

        m = RE_SUCCESS_RATE.search(line)
        if m:
            events.append(
                {
                    "type": "discovery",
                    "discovery_type": "success_rate",
                    "data": {
                        "success": int(m.group(1)),
                        "total": int(m.group(2)),
                        "ratio": m.group(3),
                    },
                }
            )

        m = RE_LEAK_RATE.search(line)
        if m:
            events.append(
                {
                    "type": "discovery",
                    "discovery_type": "leakage_rate",
                    "data": {"bit_per_sec": float(m.group(1))},
                }
            )

        if "error" in line.lower() or "failed" in line.lower():
            events.append(
                {
                    "type": "error",
                    "message": line,
                }
            )

        return events


manager = AttackManager()


@app.get("/status")
async def status() -> Dict[str, Any]:
    st = await manager.get_status()
    return {
        "status": st["status"],
        "timestamp": now_ts(),
        "message": "Meltdown 3a backend ready",
        "version": "1.0.0",
        "active_run": st["active_run"],
        "last_execution_summary": st["last_execution_summary"],
        "last_report_summary": st["last_report_summary"],
    }


@app.get("/attack/status")
async def attack_status() -> Dict[str, Any]:
    st = await manager.get_status()
    return {
        "status": st["status"],
        "active_run": st["active_run"],
        "last_execution_summary": st["last_execution_summary"],
        "last_report_summary": st["last_report_summary"],
        "timestamp": now_ts(),
    }


@app.get("/profiles")
async def profiles() -> Dict[str, Any]:
    return {
        "timestamp": now_ts(),
        "profiles": get_profiles_summary(),
    }


@app.post("/attack/start")
async def attack_start(req: AttackStartRequest) -> Dict[str, Any]:
    requested_profile = (req.profile or str(req.config.get("profile", "")).strip() or "regcheck_scan")
    try:
        run_info = await manager.start(requested_profile, req.config)
        return {
            "status": "running",
            "message": "Attack started",
            "timestamp": now_ts(),
            "run": run_info.model_dump(),
        }
    except RuntimeError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/attack/stop")
async def attack_stop() -> Dict[str, Any]:
    stopped = await manager.stop()
    await manager._broadcast(
        {
            "type": "info",
            "message": "Attack stop requested via HTTP",
        }
    )
    return {
        "status": "stopped" if stopped else "idle",
        "message": "Attack stopped successfully" if stopped else "No active attack",
        "timestamp": now_ts(),
    }


@app.post("/attack/reset")
async def attack_reset() -> Dict[str, Any]:
    await manager.reset()
    await manager._broadcast(
        {
            "type": "info",
            "message": "Attack state reset",
        }
    )
    return {
        "status": "reset",
        "message": "Attack state reset successfully",
        "timestamp": now_ts(),
    }


@app.get("/metadata")
async def metadata() -> Dict[str, Any]:
    return {
        "os": f"{platform.system()} {platform.release()}",
        "kernel": platform.release(),
        "arch": platform.machine(),
        "cpu": platform.processor(),
        "hostname": platform.node(),
        "project_root": PROJECT_ROOT,
        "timestamp": now_ts(),
    }


@app.websocket("/attack")
async def ws_attack(ws: WebSocket) -> None:
    await ws.accept()
    await manager.register_ws(ws)
    try:
        await ws.send_json(
            {
                "type": "info",
                "message": "WebSocket connected",
                "timestamp": now_ts(),
            }
        )
        while True:
            data = await ws.receive_text()
            try:
                msg = json.loads(data)
            except json.JSONDecodeError:
                await ws.send_json({"type": "error", "message": "Invalid JSON", "timestamp": now_ts()})
                continue

            action = msg.get("action")
            if action == "start":
                cfg = msg.get("config", {})
                profile = cfg.get("profile", "regcheck_scan")
                try:
                    run_info = await manager.start(profile, cfg)
                    await ws.send_json(
                        {
                            "type": "info",
                            "message": "Attack started",
                            "run": run_info.model_dump(),
                            "timestamp": now_ts(),
                        }
                    )
                except Exception as e:
                    await ws.send_json({"type": "error", "message": str(e), "timestamp": now_ts()})
            elif action == "stop":
                await manager.stop()
                await ws.send_json({"type": "info", "message": "Stop requested", "timestamp": now_ts()})
            elif action == "ping":
                await ws.send_json({"type": "pong", "timestamp": now_ts()})
            else:
                await ws.send_json({"type": "error", "message": f"Unknown action: {action}", "timestamp": now_ts()})
    except WebSocketDisconnect:
        await manager.unregister_ws(ws)
    except Exception:
        await manager.unregister_ws(ws)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host=HOST, port=PORT, log_level="info")
