param(
    [string]$HostAddress = "0.0.0.0",
    [int]$Port = 3030,
    [switch]$SkipInstall
)

$ErrorActionPreference = "Stop"

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptDir

$portHolders = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
if ($portHolders) {
    Write-Host "[meltdown3a-backend] WARNING: Port $Port is already in use by:"
    $portHolders | Select-Object LocalAddress, LocalPort, OwningProcess | ForEach-Object {
        $p = Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue
        if ($p) {
            Write-Host ("  PID={0} Name={1}" -f $p.Id, $p.ProcessName)
        } else {
            Write-Host ("  PID={0}" -f $_.OwningProcess)
        }
    }
    Write-Host "[meltdown3a-backend] Tip: use another port, e.g. .\\run.ps1 -Port 38030"
}

$venvPython = Join-Path $scriptDir ".venv\Scripts\python.exe"
$venvPip = Join-Path $scriptDir ".venv\Scripts\pip.exe"

if (-not (Test-Path $venvPython)) {
    Write-Host "[meltdown3a-backend] Creating virtual environment..."
    py -m venv .venv
}

if (-not $SkipInstall) {
    Write-Host "[meltdown3a-backend] Installing requirements..."
    & $venvPip install -r requirements.txt
}

if (-not (Test-Path ".env") -and (Test-Path ".env.example")) {
    Copy-Item ".env.example" ".env"
    Write-Host "[meltdown3a-backend] Created .env from .env.example"
}

Write-Host "[meltdown3a-backend] Starting API server at http://$HostAddress`:$Port"
& $venvPython -m uvicorn --app-dir $scriptDir main:app --host $HostAddress --port $Port
