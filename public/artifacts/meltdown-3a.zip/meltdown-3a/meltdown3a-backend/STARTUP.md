# Meltdown 3a Backend 启动方式文档

本文档说明在 Windows PowerShell 环境下如何启动、停止和验证后端服务。

## 1. 目录

```powershell
cd D:\360\vscode-data\data1\regcheck-main\meltdown3a-backend
```

## 2. 一键启动（推荐）

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\run.ps1 -Port 38030
```

默认会自动：

- 创建 `.venv`（如果不存在）
- 安装依赖（可用 `-SkipInstall` 跳过）
- 用 `uvicorn` 启动后端

## 3. 手动启动（可选）

```powershell
py -m venv .venv
& .\.venv\Scripts\python.exe -m pip install -r .\requirements.txt
& .\.venv\Scripts\python.exe -m uvicorn main:app --host 0.0.0.0 --port 38030
```

## 4. 停止服务

在运行服务的终端按 `Ctrl + C`。

## 5. 快速自检

```powershell
Invoke-RestMethod http://127.0.0.1:38030/status
Invoke-RestMethod http://127.0.0.1:38030/profiles
```

## 6. 单项测试脚本

### 6.1 只测 RegCheck

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\test_regcheck.ps1 -BaseUrl http://127.0.0.1:38030 -PollSec 3 -TimeoutSec 180
```

### 6.2 只测 pocs 基础泄露测试

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\test_pocs_basic.ps1 -BaseUrl http://127.0.0.1:38030 -PollSec 3 -TimeoutPerCaseSec 300
```

## 7. 常见问题

- 脚本被系统禁止执行：
  - 执行 `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`
- 长时间 `status=active`：
  - 检查是否有旧任务残留，执行 `POST /attack/stop`
- 端口冲突：
  - 改用其他端口，例如 `-Port 38031`
