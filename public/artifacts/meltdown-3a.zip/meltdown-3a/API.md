# meltdown3a_regcheck API

此模块将 regcheck-main 目录整体作为 unified_platform 模块源目录接入。

## 必选控制接口

- `POST /attack/start`
- `POST /attack/stop`
- `POST /attack/reset`
- `GET /attack/status`

## 事件流

- `WS /attack`

## 启动参数说明

`POST /attack/start` 请求体兼容以下两种写法：

```json
{
  "profile": "regcheck_scan",
  "config": {}
}
```

```json
{
  "config": {
    "profile": "regcheck_scan"
  }
}
```

可用 `profile`（与 `meltdown3a-backend/profiles.py` 对应）：

- `regcheck_scan`
- `poc_rdpmc`
- `poc_rdfsbase`
- `poc_rdgsbase`
- `poc_rdtsc`
- `kaslr_break`
- `spectre_counterleak`
- `zigzagger_bypass`

## 阶段规范

固定首阶段为 `environment_build`，末阶段为 `report_generation`。

报告阶段事件顺序固定：

1. `report_file`（`format=markdown`，`content` 为完整 Markdown）
2. `attack_complete`
