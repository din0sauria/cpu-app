#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR/meltdown3a-backend"

python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

exec python3 -m uvicorn main:app --host 0.0.0.0 --port "${PORT:-4051}"
