import asyncio
import datetime
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI(title="TransientFail Spectre API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class StartRequest(BaseModel):
    config: Dict[str, Any] = Field(default_factory=dict)


@dataclass
class SpectreCase:
    case_id: str
    display_name: str
    variant: str
    rel_dir: str


SPECTRE_CASES: List[SpectreCase] = [
    SpectreCase("spectre_v1", "Spectre V1 (PHT)", "v1", "pocs/spectre/PHT/sa_ip"),
]
CASE_BY_VARIANT: Dict[str, SpectreCase] = {c.variant: c for c in SPECTRE_CASES}


runtime_lock = asyncio.Lock()
active_websockets: List[WebSocket] = []
runner_task: Optional[asyncio.Task] = None
current_process: Optional[asyncio.subprocess.Process] = None
stop_requested = False
status_state: Dict[str, Any] = {
    "status": "idle",
    "current_phase": None,
    "started_at": None,
    "updated_at": None,
}
last_report: Dict[str, Any] = {}
ANSI_ESCAPE_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")


def ts() -> str:
    return datetime.datetime.utcnow().isoformat() + "Z"


def root_dir() -> Path:
    return Path(__file__).resolve().parents[1]


def clean_terminal_text(text: str) -> str:
    # Remove ANSI color/control sequences and keep the final segment after carriage-return redraws.
    no_ansi = ANSI_ESCAPE_RE.sub("", text or "")
    if "\r" in no_ansi:
        parts = [p for p in no_ansi.split("\r") if p.strip()]
        no_ansi = parts[-1] if parts else ""
    return no_ansi.replace("\t", "    ").strip()


async def broadcast(payload: Dict[str, Any]) -> None:
    payload.setdefault("timestamp", ts())
    dead: List[WebSocket] = []
    for ws in active_websockets:
        try:
            await ws.send_json(payload)
        except Exception:
            dead.append(ws)
    for ws in dead:
        try:
            active_websockets.remove(ws)
        except ValueError:
            pass


def update_status(status: str, phase: Optional[str] = None) -> None:
    status_state["status"] = status
    status_state["current_phase"] = phase
    status_state["updated_at"] = ts()


async def emit_phase_progress(phase_index: int, phase_name: str, percent: int, display: str) -> None:
    await broadcast(
        {
            "type": "phase_progress",
            "phase": phase_name,
            "phase_id": phase_index - 1,
            "phase_index": phase_index,
            "phase_name": phase_name,
            "progress": {"percent": max(0, min(100, percent))},
            "display": display,
            "render": "progress_bar",
        }
    )


async def emit_phase_start(phase_index: int, phase_name: str, display: str) -> None:
    await broadcast(
        {
            "type": "phase_start",
            "phase": phase_name,
            "phase_id": phase_index - 1,
            "phase_index": phase_index,
            "phase_name": phase_name,
            "display": display,
            "render": "plain_text",
        }
    )


async def emit_phase_complete(phase_index: int, phase_name: str, result: Dict[str, Any]) -> None:
    await broadcast(
        {
            "type": "phase_complete",
            "phase": phase_name,
            "phase_id": phase_index - 1,
            "phase_index": phase_index,
            "phase_name": phase_name,
            "result": result,
            "display": f"{phase_name} completed",
            "render": "plain_text",
        }
    )


async def run_cmd(cmd: List[str], cwd: Path, timeout_sec: int, log_prefix: str) -> Dict[str, Any]:
    global current_process
    start = datetime.datetime.utcnow()
    lines: List[str] = []
    timed_out = False

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        cwd=str(cwd),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    current_process = proc

    async def _reader() -> None:
        if proc.stdout is None:
            return
        while True:
            line = await proc.stdout.readline()
            if not line:
                break
            text = line.decode(errors="ignore").rstrip()
            if text:
                lines.append(text)
                await broadcast(
                    {
                        "type": "log",
                        "source": log_prefix,
                        "line": text,
                    }
                )

    reader_task = asyncio.create_task(_reader())
    try:
        await asyncio.wait_for(proc.wait(), timeout=timeout_sec)
    except asyncio.TimeoutError:
        timed_out = True
        try:
            proc.terminate()
            await asyncio.wait_for(proc.wait(), timeout=3)
        except Exception:
            proc.kill()
            await proc.wait()
    finally:
        await reader_task
        current_process = None

    end = datetime.datetime.utcnow()
    duration = (end - start).total_seconds()
    return {
        "cmd": cmd,
        "cwd": str(cwd),
        "exit_code": proc.returncode,
        "timeout": timed_out,
        "duration_seconds": duration,
        "lines": lines,
    }


def evaluate_case_output(lines: List[str]) -> Dict[str, Any]:
    text = "\n".join(lines)
    normalized = clean_terminal_text(text)
    has_done = ("[>] Done" in text) or ("Done" in text) or ("Done" in normalized)
    # Keep secret markers as auxiliary evidence only. Different terminals/ANSI redraws
    # may split words and cause string-based checks to miss.
    has_secret = (
        ("SECRET" in text)
        or ("INACCESSIBLE" in text)
        or ("SECRET" in normalized.upper())
        or ("INACCESSIBLE" in normalized.upper())
    )
    return {
        "has_done_marker": has_done,
        "has_secret_marker": has_secret,
        "line_count": len(lines),
    }


def select_cases(config: Dict[str, Any]) -> List[SpectreCase]:
    return list(SPECTRE_CASES)


async def run_attack(config: Dict[str, Any]) -> None:
    global runner_task, stop_requested, last_report

    work_root = root_dir()
    timeout_build = int(config.get("build_timeout_sec", 180))
    timeout_case = int(config.get("case_timeout_sec", 120))

    selected_cases = list(SPECTRE_CASES)
    report_cases: List[Dict[str, Any]] = []
    execution_ok = True

    status_state["started_at"] = ts()
    update_status("running", "environment_build")

    await emit_phase_start(1, "environment_build", "Build shared dependencies and required Spectre PoCs")

    build_steps: List[tuple] = [(["make", "-C", "pocs/libcache"], 20, "Building libcache")]
    variant_build = {
        "v1": (["make", "x86"], "Building Spectre v1 (PHT)", "pocs/spectre/PHT/sa_ip"),
        "v2": (["make", "x86"], "Building Spectre v2 (BTB)", "pocs/spectre/BTB/sa_ip"),
        "v4": (["make", "x86"], "Building Spectre v4 (STL)", "pocs/spectre/STL"),
        "v5": (["make", "x86"], "Building Spectre v5 (RSB)", "pocs/spectre/RSB/sa_ip"),
    }
    if selected_cases:
        pct_start = 35
        pct_step = max(1, int(60 / len(selected_cases)))
        for i, case in enumerate(selected_cases):
            cmd, display, rel = variant_build[case.variant]
            pct = min(95, pct_start + i * pct_step)
            build_steps.append((cmd, pct, display, rel))

    await emit_phase_progress(1, "environment_build", 5, "Preparing build environment")

    for step in build_steps:
        if stop_requested:
            execution_ok = False
            break
        if len(step) == 3:
            cmd, percent, display = step
            cwd = work_root
        else:
            cmd, percent, display, rel_cwd = step
            cwd = work_root / rel_cwd

        await emit_phase_progress(1, "environment_build", percent, display)
        out = await run_cmd(cmd, cwd, timeout_build, "build")
        if out["exit_code"] != 0 or out["timeout"]:
            execution_ok = False
            await broadcast(
                {
                    "type": "error",
                    "phase_name": "environment_build",
                    "phase_index": 1,
                    "display": f"Build failed: {display}",
                    "render": "plain_text",
                    "message": f"Command failed: {' '.join(cmd)} (exit={out['exit_code']}, timeout={out['timeout']})",
                }
            )
            break

    await emit_phase_progress(1, "environment_build", 100, "Environment build finished")
    await emit_phase_complete(1, "environment_build", {"ok": execution_ok})

    # Spectre variant phases: 2..N
    for idx, case in enumerate(selected_cases, start=2):
        if stop_requested:
            execution_ok = False
            break

        phase_name = case.case_id
        update_status("running", phase_name)
        await emit_phase_start(idx, phase_name, f"Run {case.display_name}")

        run_out = await run_cmd(["./poc_x86"], work_root / case.rel_dir, timeout_case, case.case_id)
        eval_result = evaluate_case_output(run_out["lines"])

        ok = (run_out["exit_code"] == 0) and (not run_out["timeout"]) and (eval_result["line_count"] > 0)
        # Secret marker is the primary evidence. A run may still be terminated by
        # timeout after printing leaked data, so exit status must not suppress hit.
        vuln_hit = bool(eval_result["has_secret_marker"])
        execution_ok = execution_ok and ok

        case_result = {
            "variant": case.variant,
            "display_name": case.display_name,
            "ok": ok,
            "vulnerability_hit": vuln_hit,
            "exit_code": run_out["exit_code"],
            "timeout": run_out["timeout"],
            "duration_seconds": run_out["duration_seconds"],
            "evaluation": eval_result,
            "sample_output": [clean_terminal_text(x) for x in run_out["lines"][:30] if clean_terminal_text(x)],
        }
        report_cases.append(case_result)

        await emit_phase_complete(idx, phase_name, case_result)

    # Final report phase
    report_phase_index = 2 + len(selected_cases)
    update_status("running", "report_generation")
    await emit_phase_start(report_phase_index, "report_generation", "Generate markdown report")

    total_duration = 0.0
    for item in report_cases:
        total_duration += float(item.get("duration_seconds", 0.0))

    vulnerability_present = bool(
        (not stop_requested)
        and report_cases
        and any(bool(item.get("vulnerability_hit")) for item in report_cases)
    )

    lines = [
        "# 检测报告 (Spectre)",
        "",
        f"- 生成时间: {ts()}",
        f"- 漏洞结论: {'存在漏洞' if vulnerability_present else '未确认漏洞'}",
        f"- 运行状态: {'成功' if execution_ok and not stop_requested else '失败'}",
        f"- 选择变体: {', '.join(c.variant for c in selected_cases)}",
        f"- 总耗时(秒): {total_duration:.3f}",
        "",
        "## 各阶段执行结果",
    ]

    for item in report_cases:
        lines.append("")
        lines.append(f"### {item['display_name']} ({item['variant']})")
        lines.append(f"- 状态正常: {item['ok']}")
        lines.append(f"- 退出码: {item['exit_code']}")
        lines.append(f"- 超时: {item['timeout']}")
        lines.append(f"- 耗时(秒): {item['duration_seconds']:.3f}")
        lines.append(f"- 输出行数: {item['evaluation']['line_count']}")
        lines.append(f"- 命中漏洞特征: {item.get('vulnerability_hit', False)}")
        lines.append(f"- 存在结束标识: {item['evaluation']['has_done_marker']}")
        lines.append(f"- 存在秘密标识: {item['evaluation']['has_secret_marker']}")
        if item["sample_output"]:
            lines.append("- 预期窃取目标: 'INACCESSIBLE SECRET'")
            lines.append("- 实际窃取到的信息 (部分输出展示):")
            lines.append("```text")
            for out_line in item["sample_output"][:10]:
                safe_line = out_line.replace("`", "'")
                lines.append(safe_line)
            lines.append("```")

    if stop_requested:
        lines.append("")
        lines.append("## 停止原因")
        lines.append("- 用户在执行时请求了停止/重置")

    report_md = "\n".join(lines)

    report_obj = {
        "report_id": f"transientfail-{int(datetime.datetime.utcnow().timestamp())}",
        "module": "transientfail",
        "success": vulnerability_present,
        "started_at": status_state.get("started_at"),
        "finished_at": ts(),
        "summary": (
            "Secret-dependent speculative behavior observed: target is vulnerable"
            if vulnerability_present
            else "No secret-leak evidence observed in this run"
        ),
        "findings": report_cases,
        "artifacts": [{"name": "transientfail_spectre_report.md", "format": "markdown"}],
    }
    last_report = report_obj

    await broadcast(
        {
            "type": "report_file",
            "phase": "report_generation",
            "phase_id": report_phase_index - 1,
            "phase_index": report_phase_index,
            "phase_name": "report_generation",
            "display": "TransientFail markdown report generated",
            "render": "markdown",
            "report_file": {
                "name": "transientfail_spectre_report.md",
                "format": "markdown",
                "content": report_md,
            },
        }
    )

    await broadcast(
        {
            "type": "attack_complete",
            "success": vulnerability_present,
            "total_lines": sum(len(c.get("sample_output", [])) for c in report_cases),
            "return_code": 0 if execution_ok and not stop_requested else 1,
            "report": report_obj,
        }
    )

    update_status("idle", None)
    runner_task = None


@app.get("/attack/status")
async def attack_status() -> Dict[str, Any]:
    return {
        "status": status_state.get("status", "idle"),
        "current_phase": status_state.get("current_phase"),
        "started_at": status_state.get("started_at"),
        "updated_at": status_state.get("updated_at"),
        "timestamp": ts(),
        "report": last_report,
        "message": "TransientFail Spectre validation backend ready",
    }


@app.post("/attack/start")
async def attack_start(req: StartRequest) -> Dict[str, Any]:
    global runner_task, stop_requested
    async with runtime_lock:
        if runner_task and not runner_task.done():
            return {"status": "running", "message": "Attack already running", "timestamp": ts()}

        stop_requested = False
        update_status("running", "environment_build")
        runner_task = asyncio.create_task(run_attack(req.config))
        return {"status": "running", "message": "TransientFail run started", "timestamp": ts()}


@app.post("/attack/stop")
async def attack_stop() -> Dict[str, Any]:
    global stop_requested, current_process
    async with runtime_lock:
        stop_requested = True
        proc = current_process
        if proc and proc.returncode is None:
            try:
                proc.terminate()
                await asyncio.wait_for(proc.wait(), timeout=3)
            except Exception:
                proc.kill()
                await proc.wait()
        update_status("idle", None)
    return {"status": "stopped", "message": "Stop signal accepted", "timestamp": ts()}


@app.post("/attack/reset")
async def attack_reset() -> Dict[str, Any]:
    global stop_requested, last_report
    await attack_stop()
    stop_requested = False
    last_report = {}
    status_state["started_at"] = None
    status_state["updated_at"] = ts()
    return {"status": "reset", "message": "State reset", "timestamp": ts()}


@app.websocket("/attack")
async def ws_attack(websocket: WebSocket) -> None:
    await websocket.accept()
    active_websockets.append(websocket)
    try:
        while True:
            raw = await websocket.receive_text()
            # Optional local compatibility: allow start/stop over WS
            try:
                import json

                msg = json.loads(raw)
                action = msg.get("action")
                if action == "start":
                    cfg = msg.get("config", {}) if isinstance(msg.get("config", {}), dict) else {}
                    await attack_start(StartRequest(config=cfg))
                elif action == "stop":
                    await attack_stop()
                elif action == "reset":
                    await attack_reset()
            except Exception:
                continue
    except WebSocketDisconnect:
        pass
    finally:
        try:
            active_websockets.remove(websocket)
        except ValueError:
            pass


if __name__ == "__main__":
    import uvicorn

    port = int(os.environ.get("PORT", "4041"))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=False)
