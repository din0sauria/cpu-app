#!/usr/bin/env bash
set -euo pipefail

PORT="${PORT:-4038}"
HOST="${HOST:-0.0.0.0}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODULE_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

cd "${MODULE_ROOT}/backend"
exec python3 -m uvicorn app:app --host "${HOST}" --port "${PORT}"
