#!/bin/bash

set -e

echo "=========================================="
echo "Step 1: 编译 demo"
echo "=========================================="
cd /mnt/d/360/vscode-data/data3/fallout-main
sudo apt update
sudo apt install -y build-essential cmake make gcc

cd /mnt/d/360/vscode-data/data3/fallout-main/demos
make notsx=TSX || true

cd /mnt/d/360/vscode-data/data3/fallout-main

echo ""
echo "Step 1b: 注意 - WSL2 不需要 linux-headers，已跳过"
echo ""

echo "=========================================="
echo "Step 2: 创建 venv"
echo "=========================================="
sudo apt install -y python3-venv

cd /mnt/d/360/vscode-data/data3/fallout-main/backend
python3 -m venv .venv
source .venv/bin/activate

echo ""
echo "=========================================="
echo "Step 3: 安装依赖"
echo "=========================================="
cat > requirements.txt <<'EOF'
Flask==2.3.3
Flask-SocketIO==5.6.1
eventlet==0.33.3
python-dotenv==1.0.0
EOF

pip install --upgrade pip
pip install -r requirements.txt

echo ""
echo "=========================================="
echo "Step 4: 启动后端服务"
echo "=========================================="
echo "服务已启动在 http://127.0.0.1:3030"
echo "请在另一个终端执行后续 curl 命令"
echo ""

python app.py
