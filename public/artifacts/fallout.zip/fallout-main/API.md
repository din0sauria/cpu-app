# Fallout API.md

## Required interfaces

- POST /attack/start
- POST /attack/stop
- POST /attack/reset
- GET /attack/status
- WS /attack

## Start payload

```json
{
  "config": {
    "demo": "wtf|data_bounce|kaslr",
    "args": []
  }
}
```

## Required report order

When detection completes, websocket events must follow this order:

1. report_file (markdown content)
2. attack_complete

## report_file payload

```json
{
  "type": "report_file",
  "phase_index": 3,
  "phase_name": "report_generation",
  "display": "Fallout markdown report generated",
  "render": "markdown",
  "report_file": {
    "name": "fallout_report.md",
    "format": "markdown",
    "content": "# Fallout Detection Report\n..."
  },
  "timestamp": "2026-04-06T00:00:00Z"
}
```

## status response (minimum)

- status: idle/running/stopped/error
- last_run_summary: latest execution summary
- report: latest report object
