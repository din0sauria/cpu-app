#!/bin/bash

echo "=========================================="
echo "Demo 1: Write Transient Forwarding (WTF)"
echo "=========================================="
curl -X POST http://127.0.0.1:3030/attack/reset -s > /dev/null
curl -X POST http://127.0.0.1:3030/attack/start \
  -H "Content-Type: application/json" \
  -d '{"demo":"wtf"}' -s
echo ""

echo "等待 Demo 1 完成（约 30 秒）..."
sleep 35

echo ""
echo "Demo 1 结果："
curl http://127.0.0.1:3030/status -s
echo ""

echo ""
echo "=========================================="
echo "Demo 3: Data Bounce"
echo "=========================================="
curl -X POST http://127.0.0.1:3030/attack/reset -s > /dev/null
curl -X POST http://127.0.0.1:3030/attack/start \
  -H "Content-Type: application/json" \
  -d '{"demo":"data_bounce"}' -s
echo ""

echo "等待 Demo 3 完成（约 20 秒）..."
sleep 25

echo ""
echo "Demo 3 结果："
curl http://127.0.0.1:3030/status -s
echo ""

echo ""
echo "=========================================="
echo "Demo 4: Breaking KASLR"
echo "=========================================="
curl -X POST http://127.0.0.1:3030/attack/reset -s > /dev/null
curl -X POST http://127.0.0.1:3030/attack/start \
  -H "Content-Type: application/json" \
  -d '{"demo":"kaslr"}' -s
echo ""

echo "等待 Demo 4 完成（约 30 秒）..."
sleep 35

echo ""
echo "Demo 4 结果："
curl http://127.0.0.1:3030/status -s
echo ""

echo ""
echo "=========================================="
echo "所有 Demo 执行完成"
echo "=========================================="

