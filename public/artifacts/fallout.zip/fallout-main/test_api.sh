#!/bin/bash

echo "=========================================="
echo "验证服务"
echo "=========================================="
curl http://127.0.0.1:3030/status
echo ""

echo ""
echo "=========================================="
echo "获取元数据"
echo "=========================================="
curl http://127.0.0.1:3030/metadata
echo ""

echo ""
echo "=========================================="
echo "启动 WTF Demo"
echo "=========================================="
curl -X POST http://127.0.0.1:3030/attack/start \
  -H "Content-Type: application/json" \
  -d '{"demo":"wtf"}'
echo ""

echo ""
echo "=========================================="
echo "启动 Data_bounce Demo"
echo "=========================================="
curl -X POST http://127.0.0.1:3030/attack/start \
  -H "Content-Type: application/json" \
  -d '{"demo":"data_bounce"}'
echo ""

echo ""
echo "=========================================="
echo "启动 KASLR Demo"
echo "=========================================="
curl -X POST http://127.0.0.1:3030/attack/start \
  -H "Content-Type: application/json" \
  -d '{"demo":"kaslr"}'
echo ""

echo ""
echo "=========================================="
echo "观察当前状态（10秒后）"
echo "=========================================="
sleep 10
curl http://127.0.0.1:3030/status
echo ""

echo ""
echo "=========================================="
echo "停止攻击"
echo "=========================================="
curl -X POST http://127.0.0.1:3030/attack/stop
echo ""

echo ""
echo "=========================================="
echo "重置状态"
echo "=========================================="
curl -X POST http://127.0.0.1:3030/attack/reset
echo ""

echo "完毕"
