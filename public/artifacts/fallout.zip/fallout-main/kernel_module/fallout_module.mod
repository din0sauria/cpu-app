/mnt/hgfs/360/fallout-main/fallout-main/kernel_module/fallout_module.o

