# Fallout -> unified_platform 接入说明

本文件说明如何在不修改 unified_platform 框架代码的前提下，接入 Fallout 模块。

## 1. 放置目录

将整个 fallout-main 目录放到：

- unified_platform/program/fallout/

接入后目录关键文件应为：

- unified_platform/program/fallout/module_spec.json
- unified_platform/program/fallout/API.md
- unified_platform/program/fallout/scripts/one_click_start.sh
- unified_platform/program/fallout/backend/requirements.txt
- unified_platform/program/fallout/backend/app.py

## 2. 注册表示例（仅新增条目）

在 unified_platform/module_registry.json 新增 fallout 条目：

```json
"fallout": {
  "source_dir": "fallout",
  "runtime_subdir": "fallout",
  "start_command": ["bash", "scripts/one_click_start.sh"],
  "workdir": "fallout",
  "env": {"PORT": "4038"},
  "local_api_base": "http://127.0.0.1:4038",
  "event_stream": {"type": "websocket_json", "url": "ws://127.0.0.1:4038/attack"},
  "control": {
    "start": {
      "type": "http",
      "method": "POST",
      "path": "/attack/start",
      "payload_mode": "json",
      "default_payload": {"config": {"demo": "data_bounce"}}
    },
    "stop": {"type": "http", "method": "POST", "path": "/attack/stop", "payload_mode": "none"},
    "reset": {"type": "http", "method": "POST", "path": "/attack/reset", "payload_mode": "none"},
    "status": {"type": "http", "method": "GET", "path": "/attack/status", "payload_mode": "none"}
  }
}
```

说明：module_registry.json 属于框架仓库，fallout 仓库无法直接提交该文件；这里给出的是你在框架仓库中应添加的条目模板。

## 3. 兼容要点

- 控制接口固定：POST /attack/start|stop|reset, GET /attack/status
- 事件流固定：WS /attack（原生 websocket json）
- 第一阶段固定：environment_build，且必须有 phase_progress
- 最后一阶段固定：report_generation
- 结束顺序固定：先 report_file，再 attack_complete

## 4. 本仓库已完成改造内容

- backend/app.py 已改为 FastAPI + 原生 WS，并输出标准阶段事件
- 新增 module_spec.json, API.md, scripts/one_click_start.sh
- 保留 GET /status 兼容旧脚本，同时新增标准 GET /attack/status
