# Fallout PoC 后端部署指南

## 系统要求

- **操作系统**: Linux (Ubuntu 20.04+ 或 WSL2)
- **软件**: Python 3.8+, gcc, make, cmake
- **网络**: 本地 IP 访问 (默认 127.0.0.1:3030)

---

## 快速启动 (一键部署)

### 方案 1: 使用部署脚本 (推荐)

#### Linux / WSL2

在项目根目录打开终端：

```bash
cd /path/to/fallout-main
bash setup_and_run.sh
```

脚本会自动：
1. 安装依赖 (build-essential, cmake, make, gcc, python3-venv)
2. 编译 PoC demos
3. 创建 Python 虚拟环境
4. 安装 Python 依赖
5. **启动后端服务**

成功时输出：
```
Running on http://0.0.0.0:3030
Running on http://127.0.0.1:3030
```

---

### 方案 2: 手动步骤

#### Step 1: 安装系统依赖

```bash
sudo apt update
sudo apt install -y build-essential cmake make gcc python3-venv
```

#### Step 2: 编译 demos

```bash
cd /path/to/fallout-main
cd demos
make notsx=TSX
cd ..
```

成功输出会显示编译的可执行文件：
- `demo_user_read` (WTF)
- `demo_data_bounce` (Data Bounce)
- `demo_kaslr_noroot` (KASLR)
- `demo_kaslr` (KASLR with root)
- `demo_kernel_read`

#### Step 3: 创建 Python 虚拟环境

```bash
cd /path/to/fallout-main/backend
python3 -m venv .venv
source .venv/bin/activate
```

#### Step 4: 安装 Python 依赖

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

依赖清单：
- fastapi==0.115.0
- uvicorn==0.30.6
- pydantic==2.9.2
- python-dotenv==1.0.1

#### Step 5: 启动后端服务

```bash
python -m uvicorn app:app --host 0.0.0.0 --port 3030
```

---

## VS Code 中使用 WSL 开发

### 打开 WSL 终端

1. 在 VS Code 中按 `Ctrl + Backtick` 打开终端
2. 如果不是 WSL，点击右下角的终端类型选择器，选择 **WSL**
3. 确认提示符为 `$` 或 `root@`

### 分离式运行

**终端 1** (服务进程):
```bash
cd /path/to/fallout-main/backend
source .venv/bin/activate
python -m uvicorn app:app --host 0.0.0.0 --port 3030
```

**终端 2** (测试脚本):
```bash
cd /path/to/fallout-main
bash test_api.sh
# 或
bash run_all_demos.sh
```

---

## Docker 部署 (可选)

### 创建 Dockerfile

```dockerfile
FROM python:3.12-slim

WORKDIR /app

# 安装编译工具
RUN apt-get update && apt-get install -y \
    build-essential cmake make gcc \
    && rm -rf /var/lib/apt/lists/*

# 复制项目
COPY . /app

# 编译 demos
WORKDIR /app/demos
RUN make notsx=TSX

# 安装 Python 依赖
WORKDIR /app/backend
RUN pip install --no-cache-dir -r requirements.txt

# 暴露端口
EXPOSE 3030

# 启动服务
CMD ["python", "-m", "uvicorn", "app:app", "--host", "0.0.0.0", "--port", "3030"]
```

### 创建 docker-compose.yml

```yaml
version: '3.8'
services:
  fallout-backend:
    build: .
    ports:
      - "3030:3030"
    volumes:
      - ./:/app
    working_dir: /app/backend
    command: python -m uvicorn app:app --host 0.0.0.0 --port 3030
```

### 启动容器

```bash
docker-compose up --build
```

---

## 验证部署

### 基本连通性测试

```bash
curl http://127.0.0.1:3030/status
```

预期响应：
```json
{"status":"idle","attack_state":{...},"timestamp":"..."}
```

### 获取系统信息

```bash
curl http://127.0.0.1:3030/metadata
```

---

## 运行 Demo

### 单个 Demo 测试

```bash
# 重置状态
curl -X POST http://127.0.0.1:3030/attack/reset

# 启动 WTF Demo
curl -X POST http://127.0.0.1:3030/attack/start \
  -H "Content-Type: application/json" \
  -d '{"config":{"demo":"wtf"}}'

# 观察状态 (可重复)
curl http://127.0.0.1:3030/attack/status
```

### 连续运行所有 Demo

```bash
bash /path/to/fallout-main/run_all_demos.sh
```

脚本会：
1. Demo 1 (WTF): ~30 秒
2. Demo 3 (Data Bounce): ~15 秒
3. Demo 4 (KASLR): ~30 秒

**总耗时**: ~90 秒

---

## 项目文件结构

```
fallout-main/
├─ backend/
│  ├─ app.py              # FastAPI + WebSocket 后端主程序
│  ├─ requirements.txt    # Python 依赖
│  ├─ API.md              # 简化 API 文档
│  ├─ .venv/              # Python 虚拟环境 (首次创建)
│  └─ ...
├─ demos/
│  ├─ data_bounce.c       # Demo 3 源码
│  ├─ kaslr.c             # Demo 4 (root) 源码
│  ├─ kaslr_noroot.c      # Demo 4 (无 root) 源码
│  ├─ user_read.c         # Demo 1 源码
│  ├─ Makefile            # 编译配置
│  └─ ...
├─ primitives/
│  ├─ basic_primitives.c  # 核心原语实现
│  └─ basic_primitives.h
├─ setup_and_run.sh       # 一键部署脚本
├─ test_api.sh            # API 测试脚本
├─ run_all_demos.sh       # 运行所有 demo 脚本
├─ API_DOCUMENT.md        # 完整 API 文档 (此文件)
├─ DEPLOYMENT.md          # 部署指南 (此文件)
├─ fallout.md             # 项目说明文档
├─ README.md              # 项目 README
└─ ...
```

---

## 环境变量配置 (可选)

创建 `backend/.env`:

```
PORT=3030
```

---

## 常见问题排查

### 问题 1: `ModuleNotFoundError: No module named 'fastapi'`

**解决**: 确认虚拟环境已激活
```bash
source .venv/bin/activate
pip install -r requirements.txt
```

### 问题 2: `ERROR: Error loading ASGI app. Could not import module 'app'`

**解决**: 确认当前目录在 `backend/`，并使用 `python -m uvicorn app:app --host 0.0.0.0 --port 3030`

### 问题 3: `Executable not found: demo_data_bounce`

**解决**: 重新编译 demos
```bash
cd demos
make notsx=TSX
cd ..
```

### 问题 4: WSL2 连接超时

**解决**: 使用 WSL2 IP 而非 localhost
```bash
curl http://172.29.246.71:3030/attack/status
```

### 问题 5: 权限不足 (Permission denied)

**解决**: 确保脚本可执行
```bash
chmod +x setup_and_run.sh test_api.sh run_all_demos.sh
```

---

## 性能注意事项

### 资源消耗
- **CPU**: 单核占用 (调用 `taskset` 限制)
- **内存**: ~50MB (Python + 运行中的 demo)
- **I/O**: 低频文件访问

### 优化建议
1. 在物理机运行以获得准确的 Timing 测量
2. WSL2 已应用微架构缓解，demo 成功率较低（预期行为）
3. 不要在 Docker/VM 中期望高成功率（微架构隔离）

---

## 日志查看

### 后端日志

**终端 1** 的 `uvicorn` 启动命令会输出：
```
INFO:     Uvicorn running on http://0.0.0.0:3030

[日志行]
phase_start -> environment_build
phase_progress -> demo_execution
...
```

### Demo 输出捕获

Demo 的标准输出被后端捕获并存储在：
```
GET /attack/status → last_run_summary.output
```

---

## 停止服务

### 优雅停止

```bash
curl -X POST http://127.0.0.1:3030/attack/stop
```

### 强制停止

在后端终端按 `Ctrl + C`

---

## 下一步

完成部署后，你可以：

1. **开发前端**: 使用 WebSocket 接收实时事件
2. **集成监控**: 定期轮询 `/status` 获取进度
3. **自动化测试**: 编写脚本批量运行 demo，收集数据
4. **性能分析**: 对比不同环境下的成功率

参考 [API_DOCUMENT.md](API_DOCUMENT.md) 了解完整的接口规范。

