import asyncio
import datetime
import os
import platform
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI(title="Fallout Attack API", version="2.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEMO_EXEC = {
    "wtf": PROJECT_ROOT / "demo_user_read",
    "data_bounce": PROJECT_ROOT / "demo_data_bounce",
    "kaslr": PROJECT_ROOT / "demo_kaslr_noroot",
}


class StartRequest(BaseModel):
    config: Dict[str, Any] = Field(default_factory=dict)
    demo: Optional[str] = None
    args: List[Any] = Field(default_factory=list)


runtime_lock = asyncio.Lock()
active_websockets: List[WebSocket] = []
runner_task: Optional[asyncio.Task] = None
current_process: Optional[asyncio.subprocess.Process] = None
stop_requested = False

status_state: Dict[str, Any] = {
    "status": "idle",
    "current_phase": None,
    "started_at": None,
    "updated_at": None,
    "selected_demo": None,
    "last_output": None,
}
last_run_summary: Dict[str, Any] = {}
last_report: Dict[str, Any] = {}


def ts() -> str:
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def update_status(status: str, phase: Optional[str]) -> None:
    status_state["status"] = status
    status_state["current_phase"] = phase
    status_state["updated_at"] = ts()


def phase_payload(event_type: str, phase_index: int, phase_name: str, **kwargs: Any) -> Dict[str, Any]:
    payload: Dict[str, Any] = {
        "type": event_type,
        "phase": phase_name,
        "phase_id": phase_index - 1,
        "phase_index": phase_index,
        "phase_name": phase_name,
    }
    payload.update(kwargs)
    return payload


async def broadcast(payload: Dict[str, Any]) -> None:
    payload.setdefault("timestamp", ts())
    dead: List[WebSocket] = []
    for ws in active_websockets:
        try:
            await ws.send_json(payload)
        except Exception:
            dead.append(ws)
    for ws in dead:
        try:
            active_websockets.remove(ws)
        except ValueError:
            pass


async def emit_phase_start(phase_index: int, phase_name: str, display: str, render: str = "plain_text") -> None:
    await broadcast(phase_payload("phase_start", phase_index, phase_name, display=display, render=render))


async def emit_phase_progress(phase_index: int, phase_name: str, percent: int, display: str) -> None:
    await broadcast(
        phase_payload(
            "phase_progress",
            phase_index,
            phase_name,
            progress={"percent": max(0, min(100, int(percent)))},
            display=display,
            render="progress_bar",
        )
    )


async def emit_phase_complete(phase_index: int, phase_name: str, result: Dict[str, Any], display: str) -> None:
    await broadcast(
        phase_payload(
            "phase_complete",
            phase_index,
            phase_name,
            result=result,
            display=display,
            render="plain_text",
        )
    )


def resolve_demo(config: Dict[str, Any]) -> str:
    demo = str(config.get("demo", "data_bounce")).strip().lower()
    if demo not in DEMO_EXEC:
        return "data_bounce"
    return demo


def build_report_markdown(demo: str, summary: Dict[str, Any], started_at: str, finished_at: str) -> str:
    lines: List[str] = []
    lines.append("# Fallout Detection Report")
    lines.append("")
    lines.append(f"- Module: fallout")
    lines.append(f"- Demo: {demo}")
    lines.append(f"- Started At: {started_at}")
    lines.append(f"- Finished At: {finished_at}")
    lines.append(f"- Success: {summary.get('success', False)}")
    lines.append(f"- Exit Code: {summary.get('exit_code')}")
    lines.append("")
    lines.append("## Summary")
    lines.append(f"- {summary.get('summary', '')}")
    lines.append("")
    lines.append("## Output Preview")
    lines.append("")
    lines.append("```text")
    for line in summary.get("output", [])[:60]:
        lines.append(str(line))
    lines.append("```")
    lines.append("")
    return "\n".join(lines)


async def run_attack(config: Dict[str, Any]) -> None:
    global runner_task, current_process, stop_requested, last_run_summary, last_report

    selected_demo = resolve_demo(config)
    executable = DEMO_EXEC[selected_demo]
    args = config.get("args", [])
    if not isinstance(args, list):
        args = []

    started_at = ts()
    status_state["started_at"] = started_at
    status_state["selected_demo"] = selected_demo
    status_state["last_output"] = None
    update_status("running", "environment_build")

    await emit_phase_start(1, "environment_build", "Checking Fallout executable and runtime environment")
    await emit_phase_progress(1, "environment_build", 20, "Preparing attack environment")

    if not executable.exists():
        err = f"Executable not found: {executable}"
        await broadcast({"type": "error", "message": err, "display": err, "render": "plain_text"})
        await emit_phase_progress(1, "environment_build", 100, "Environment check failed")
        await emit_phase_complete(1, "environment_build", {"ok": False, "error": err}, "Environment build failed")
        update_status("error", None)
        runner_task = None
        return

    if os.name != "nt" and not os.access(executable, os.X_OK):
        err = f"Executable is not runnable: {executable}"
        await broadcast({"type": "error", "message": err, "display": err, "render": "plain_text"})
        await emit_phase_progress(1, "environment_build", 100, "Environment check failed")
        await emit_phase_complete(1, "environment_build", {"ok": False, "error": err}, "Environment build failed")
        update_status("error", None)
        runner_task = None
        return

    await emit_phase_progress(1, "environment_build", 100, "Environment build complete")
    await emit_phase_complete(1, "environment_build", {"ok": True, "executable": str(executable)}, "Environment build completed")

    update_status("running", "demo_execution")
    await emit_phase_start(2, "demo_execution", f"Running Fallout demo: {selected_demo}")

    cmd = [str(executable), *[str(v) for v in args]]
    lines: List[str] = []
    success = False
    stopped = False
    exit_code: Optional[int] = None

    try:
        current_process = await asyncio.create_subprocess_exec(
            *cmd,
            cwd=str(PROJECT_ROOT),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )

        percent = 5
        while True:
            if stop_requested and current_process.returncode is None:
                stopped = True
                current_process.terminate()

            if current_process.stdout is None:
                break

            raw = await current_process.stdout.readline()
            if not raw:
                break

            text = raw.decode(errors="ignore").rstrip()
            if not text:
                continue

            lines.append(text)
            status_state["last_output"] = text
            percent = min(95, percent + 2)
            await emit_phase_progress(2, "demo_execution", percent, text)

            if "Your kernel's base address should be" in text or "was not broken" in text:
                await broadcast(
                    {
                        "type": "discovery",
                        "phase": "demo_execution",
                        "phase_id": 1,
                        "phase_index": 2,
                        "phase_name": "demo_execution",
                        "display": "KASLR related discovery",
                        "render": "plain_text",
                        "data": {"line": text},
                    }
                )

        if current_process.returncode is None:
            await current_process.wait()
        exit_code = current_process.returncode
        success = bool(exit_code == 0 and not stopped)

    except Exception as ex:
        await broadcast(
            {
                "type": "error",
                "phase": "demo_execution",
                "phase_id": 1,
                "phase_index": 2,
                "phase_name": "demo_execution",
                "display": f"Execution error: {ex}",
                "render": "plain_text",
                "message": str(ex),
            }
        )
        success = False
        lines.append(f"[backend-error] {ex}")
    finally:
        current_process = None

    summary_text = "Fallout demo finished successfully" if success else "Fallout demo failed or was stopped"
    result = {
        "demo": selected_demo,
        "success": success,
        "stopped": stopped,
        "exit_code": exit_code,
        "summary": summary_text,
        "line_count": len(lines),
        "output": lines,
    }
    last_run_summary = result

    await emit_phase_complete(2, "demo_execution", result, summary_text)

    update_status("running", "report_generation")
    await emit_phase_start(3, "report_generation", "Generating markdown report", render="markdown")
    await emit_phase_progress(3, "report_generation", 70, "Composing report content")

    finished_at = ts()
    report_md = build_report_markdown(selected_demo, result, started_at, finished_at)
    report_obj = {
        "report_id": f"fallout-{int(datetime.datetime.utcnow().timestamp())}",
        "module": "fallout",
        "success": success,
        "started_at": started_at,
        "finished_at": finished_at,
        "summary": summary_text,
        "findings": [
            {
                "demo": selected_demo,
                "exit_code": exit_code,
                "line_count": len(lines),
                "stopped": stopped,
            }
        ],
        "artifacts": [{"name": "fallout_report.md", "format": "markdown"}],
    }
    last_report = report_obj

    # Mandatory order: report_file first, then attack_complete.
    await broadcast(
        {
            "type": "report_file",
            "phase": "report_generation",
            "phase_id": 2,
            "phase_index": 3,
            "phase_name": "report_generation",
            "display": "Fallout markdown report generated",
            "render": "markdown",
            "report_file": {
                "name": "fallout_report.md",
                "format": "markdown",
                "content": report_md,
            },
        }
    )

    await emit_phase_progress(3, "report_generation", 100, "Report generation complete")
    await emit_phase_complete(3, "report_generation", {"ok": True, "report_file": "fallout_report.md"}, "Report generation completed")
    await broadcast({"type": "attack_complete", "success": success, "report": report_obj})

    update_status("idle", None)
    runner_task = None
    stop_requested = False


@app.get("/metadata")
async def metadata() -> Dict[str, Any]:
    return {
        "os": platform.platform(),
        "kernel": platform.release(),
        "arch": platform.machine(),
        "cpu": platform.processor(),
        "hostname": platform.node(),
        "timestamp": ts(),
    }


@app.get("/attack/status")
async def attack_status() -> Dict[str, Any]:
    return {
        "status": status_state.get("status", "idle"),
        "current_phase": status_state.get("current_phase"),
        "started_at": status_state.get("started_at"),
        "updated_at": status_state.get("updated_at"),
        "selected_demo": status_state.get("selected_demo"),
        "last_output": status_state.get("last_output"),
        "last_run_summary": last_run_summary,
        "report": last_report,
        "message": "Fallout backend ready",
        "timestamp": ts(),
    }


@app.get("/status")
async def status_compat() -> Dict[str, Any]:
    # Keep compatibility with old scripts while exposing the new status schema.
    detail = await attack_status()
    return {
        "status": "active" if detail.get("status") == "running" else "idle",
        "attack_state": detail,
        "timestamp": ts(),
    }


@app.post("/attack/start")
async def attack_start(req: StartRequest) -> Dict[str, Any]:
    global runner_task, stop_requested
    cfg = dict(req.config or {})
    if req.demo and "demo" not in cfg:
        cfg["demo"] = req.demo
    if req.args and "args" not in cfg:
        cfg["args"] = req.args

    async with runtime_lock:
        if runner_task and not runner_task.done():
            return {"status": "running", "message": "Attack already running", "timestamp": ts()}

        stop_requested = False
        update_status("running", "environment_build")
        runner_task = asyncio.create_task(run_attack(cfg))
        return {"status": "running", "message": "Fallout attack started", "timestamp": ts()}


@app.post("/attack/stop")
async def attack_stop() -> Dict[str, Any]:
    global stop_requested, current_process
    async with runtime_lock:
        stop_requested = True
        proc = current_process
        if proc and proc.returncode is None:
            try:
                proc.terminate()
                await asyncio.wait_for(proc.wait(), timeout=3)
            except Exception:
                proc.kill()
                await proc.wait()
        update_status("stopped", None)
    return {"status": "stopped", "message": "Stop signal accepted", "timestamp": ts()}


@app.post("/attack/reset")
async def attack_reset() -> Dict[str, Any]:
    global stop_requested, last_report, last_run_summary
    await attack_stop()
    stop_requested = False
    last_report = {}
    last_run_summary = {}
    status_state["started_at"] = None
    status_state["last_output"] = None
    status_state["selected_demo"] = None
    update_status("idle", None)
    return {"status": "reset", "message": "State reset", "timestamp": ts()}


@app.websocket("/attack")
async def ws_attack(websocket: WebSocket) -> None:
    await websocket.accept()
    active_websockets.append(websocket)
    try:
        await websocket.send_json({"type": "connected", "display": "WebSocket connected", "timestamp": ts()})
        while True:
            raw = await websocket.receive_text()
            try:
                import json

                msg = json.loads(raw)
                action = msg.get("action")
                if action == "start":
                    cfg = msg.get("config", {}) if isinstance(msg.get("config", {}), dict) else {}
                    await attack_start(StartRequest(config=cfg))
                elif action == "stop":
                    await attack_stop()
                elif action == "reset":
                    await attack_reset()
                elif action == "status":
                    await websocket.send_json({"type": "status", "payload": await attack_status(), "timestamp": ts()})
                else:
                    await websocket.send_json(
                        {
                            "type": "error",
                            "display": f"Unsupported ws action: {action}",
                            "render": "plain_text",
                            "timestamp": ts(),
                        }
                    )
            except Exception as ex:
                await websocket.send_json(
                    {
                        "type": "error",
                        "display": f"Invalid websocket payload: {ex}",
                        "render": "plain_text",
                        "timestamp": ts(),
                    }
                )
    except WebSocketDisconnect:
        pass
    finally:
        try:
            active_websockets.remove(websocket)
        except ValueError:
            pass


if __name__ == "__main__":
    import uvicorn

    port = int(os.environ.get("PORT", "3030"))
    uvicorn.run("app:app", host="0.0.0.0", port=port, reload=False)
