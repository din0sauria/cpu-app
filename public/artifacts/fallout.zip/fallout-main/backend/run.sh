#!/bin/bash
set -e
cd "$(dirname "$0")"
VENV=.venv
if [ ! -d "$VENV" ]; then
  python3 -m venv "$VENV"
fi
source "$VENV/bin/activate"
pip install -r requirements.txt
cd ..
make
cd backend
python app.py
