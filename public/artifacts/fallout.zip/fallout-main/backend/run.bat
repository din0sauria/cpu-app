@echo off
cd /d %~dp0
if not exist .venv (python -m venv .venv)
.venv\Scripts\activate
pip install -r requirements.txt
cd ..
make
cd backend
python app.py
