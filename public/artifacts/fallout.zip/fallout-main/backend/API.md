# Fallout PoC Backend API

本服务已对齐 unified_platform 模块接入规范（控制接口 + 原生 WebSocket 事件流）。

## HTTP

- GET `/attack/status`
  - 返回 `{status, current_phase, started_at, report, last_run_summary, timestamp}`

- POST `/attack/start`
  - Body JSON: `{ "config": {"demo": "wtf|data_bounce|kaslr", "args": []} }`
  - 返回 `{status:'running'}`

- POST `/attack/stop`
  - 停止当前任务，返回 `{status:'stopped'}`

- POST `/attack/reset`
  - 清理状态，返回 `{status:'reset'}`

- GET `/metadata`
  - 返回宿主机信息

- GET `/status`
  - 兼容旧脚本的别名接口

## WebSocket

- URL `ws://localhost:3030/attack`
- 协议：原生 websocket（JSON），不是 Socket.IO
- 客户端可发送 action：`start|stop|reset|status`

### 阶段事件（关键字段）

所有阶段事件均包含：

- `phase_index`（从 1 开始）
- `phase_name`
- `display`
- `render`
- `timestamp`

阶段流程：

1. `environment_build`
2. `demo_execution`
3. `report_generation`

### 结束顺序（强制）

1. 先推送 `report_file`（markdown 文本内容）
2. 后推送 `attack_complete`
