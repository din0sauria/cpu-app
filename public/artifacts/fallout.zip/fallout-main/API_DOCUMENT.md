# Fallout PoC 后端 API 文档

## 概览

Fallout 后端服务提供 HTTP REST API 和 WebSocket 接口，用于控制和监控 Fallout 漏洞演示程序的执行。

**基础 URL**: `http://localhost:3030`  
**WebSocket URL**: `ws://localhost:3030/attack`

---

## HTTP REST API

### 1. 查询服务状态
获取当前服务和攻击状态。

**请求**
```bash
GET /status
```

**响应 (200 OK)**
```json
{
  "status": "idle|active",
  "attack_state": {
    "status": "idle|starting|running|completed|stopped|failed",
    "phase": null,
    "phase_id": null,
    "progress": {},
    "last_output": null,
    "result": null
  },
  "timestamp": "2026-03-26T13:12:07Z"
}
```

**示例**
```bash
curl http://127.0.0.1:3030/status
```

---

### 2. 获取系统元数据
获取宿主机系统信息。

**请求**
```bash
GET /metadata
```

**响应 (200 OK)**
```json
{
  "os": "Linux-6.6.87.2-microsoft-standard-WSL2-x86_64-with-glibc2.39",
  "kernel": "6.6.87.2-microsoft-standard-WSL2",
  "arch": "x86_64",
  "cpu": "x86_64",
  "hostname": "LAPTOP-2MUU7OUI",
  "timestamp": "2026-03-26T13:12:07Z"
}
```

**示例**
```bash
curl http://127.0.0.1:3030/metadata
```

---

### 3. 启动攻击演示
在后台异步启动指定 demo。

**请求**
```bash
POST /attack/start
Content-Type: application/json

{
  "demo": "wtf|data_bounce|kaslr",
  "config": {}
}
```

**参数说明**
- `demo` (string, 必需): 要运行的 demo
  - `wtf`: Write Transient Forwarding (Demo 1)
  - `data_bounce`: Data Bounce 原语 (Demo 3)
  - `kaslr`: Breaking KASLR (Demo 4)
- `config` (object, 可选): 额外配置，预留字段

**响应 (202 Accepted)**
```json
{
  "status": "started",
  "demo": "wtf",
  "message": "Attack started."
}
```

**错误响应 (409 Conflict)**
```json
{
  "status": "running",
  "message": "Attack already running"
}
```

**示例**
```bash
# 启动 WTF Demo
curl -X POST http://127.0.0.1:3030/attack/start \
  -H "Content-Type: application/json" \
  -d '{"demo":"wtf"}'

# 启动 Data Bounce Demo
curl -X POST http://127.0.0.1:3030/attack/start \
  -H "Content-Type: application/json" \
  -d '{"demo":"data_bounce"}'

# 启动 KASLR Demo
curl -X POST http://127.0.0.1:3030/attack/start \
  -H "Content-Type: application/json" \
  -d '{"demo":"kaslr"}'
```

---

### 4. 停止当前攻击
立即终止正在运行的 demo。

**请求**
```bash
POST /attack/stop
```

**响应 (200 OK)**
```json
{
  "status": "stopped",
  "message": "Attack process terminated."
}
```

**示例**
```bash
curl -X POST http://127.0.0.1:3030/attack/stop
```

---

### 5. 重置攻击状态
清除旧的攻击数据，准备下一次运行。

**请求**
```bash
POST /attack/reset
```

**响应 (200 OK)**
```json
{
  "status": "reset",
  "message": "Attack state reset successfully"
}
```

**示例**
```bash
curl -X POST http://127.0.0.1:3030/attack/reset
```

---

## WebSocket 接口

### 连接
```javascript
const ws = new WebSocket('ws://localhost:3030/attack');
```

### 客户端发送消息

#### 启动攻击
```json
{
  "action": "start",
  "config": {
    "demo": "wtf|data_bounce|kaslr"
  }
}
```

#### 停止攻击
```json
{
  "action": "stop"
}
```

### 服务器推送事件

WebSocket 会实时推送以下事件：

#### 1. 连接确认
```json
{
  "message": "WebSocket connected",
  "timestamp": "..."
}
```

#### 2. 阶段开始 (phase_start)
```json
{
  "type": "phase_start",
  "phase": "initialize",
  "phase_id": 0,
  "message": "Initialize attack",
  "timestamp": "..."
}
```

#### 3. 阶段进度 (phase_progress)
```json
{
  "type": "phase_progress",
  "phase": "break_code_aslr",
  "phase_id": 1,
  "message": "Searching kernel base...",
  "progress": {
    "current": 10,
    "total": 100
  },
  "timestamp": "..."
}
```

#### 4. 发现关键信息 (discovery)
```json
{
  "type": "discovery",
  "phase": "break_code_aslr",
  "phase_id": 1,
  "message": "Your kernel's base address should be 0xffffffff88200000",
  "data": {
    "line": "..."
  },
  "timestamp": "..."
}
```

#### 5. 阶段完成 (phase_complete)
```json
{
  "type": "phase_complete",
  "phase": "initialize",
  "phase_id": 0,
  "message": "Initialization complete",
  "data": {
    "executable": "/path/to/demo"
  },
  "timestamp": "..."
}
```

#### 6. 攻击完成 (attack_complete)
```json
{
  "type": "attack_complete",
  "phase": "initialize",
  "phase_id": 0,
  "data": {
    "success": true,
    "summary": {
      "exit_code": 0,
      "output": [
        "Demo output line 1",
        "Demo output line 2",
        "..."
      ]
    }
  },
  "timestamp": "..."
}
```

#### 7. 错误信息 (error)
```json
{
  "type": "error",
  "phase": "initialize",
  "phase_id": 0,
  "message": "Error description",
  "timestamp": "..."
}
```

### WebSocket 示例代码

```javascript
const ws = new WebSocket('ws://localhost:3030/attack');

ws.onopen = () => {
  console.log('WebSocket connected');
  
  // 启动 WTF Demo
  ws.send(JSON.stringify({
    action: 'start',
    config: { demo: 'wtf' }
  }));
};

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('Event:', data.type, data);
  
  if (data.type === 'attack_complete') {
    console.log('Attack finished!', data.data);
    ws.close();
  }
};

ws.onerror = (error) => {
  console.error('WebSocket error:', error);
};

ws.onclose = () => {
  console.log('WebSocket disconnected');
};
```

---

## Demo 说明

### Demo 1: Write Transient Forwarding (WTF)
- **命令**: `{"demo":"wtf"}`
- **耗时**: ~30 秒
- **输出示例**:
  ```
  Demo 1: Write Transient Forwarding, version 1.
  Attempting 20000 random reads...
  84 of 20000 reads succeeded.
  Success rate: 0.42 %
  ```
- **预期结果**: 
  - 现代 Intel CPU (未缓解): ~90% 成功率
  - WSL2 虚拟环境 (已缓解): <1% 成功率

### Demo 3: Data Bounce
- **命令**: `{"demo":"data_bounce"}`
- **耗时**: ~15 秒
- **输出示例**:
  ```
  Demo 3: Data bounce
  500 tests were performed.
  * Rate of hits at a mapped address (true positives): 31.20%
  * Rate of hits at an unmapped address (false positives): 0.00%
  ```
- **预期结果**:
  - 真阳性 (true positives): 接近 100% (有效地址)
  - 假阳性 (false positives): 接近 0% (无效地址)

### Demo 4: Breaking KASLR
- **命令**: `{"demo":"kaslr"}`
- **耗时**: ~30 秒
- **输出示例**:
  ```
  Demo 4: Breaking KASLR (without access to /proc/kallsyms)
  ...
  Your kernel's base address should be 0xffffffff88200000
  (or 0xffffffff87800000 if KPTI is enabled).
  ```
- **预期结果**: 成功发现内核基地址

---

## 快速测试脚本

### 运行单个 Demo
```bash
curl -X POST http://127.0.0.1:3030/attack/reset -s > /dev/null
curl -X POST http://127.0.0.1:3030/attack/start \
  -H "Content-Type: application/json" \
  -d '{"demo":"data_bounce"}'
sleep 20
curl http://127.0.0.1:3030/status
```

### 运行所有 Demo
```bash
cd /mnt/d/360/vscode-data/data3/fallout-main
bash run_all_demos.sh
```

---

## 状态码参考

| 状态码 | 含义 |
|--------|------|
| `200` | 请求成功 |
| `202` | 请求已接受，攻击后台运行 |
| `400` | 请求错误 (无效的 demo 名称) |
| `409` | 冲突 (已有攻击在运行) |

---

## 错误处理

如果 demo 不存在或崩溃，服务会返回：

```json
{
  "type": "error",
  "message": "Executable not found or not executable: ...",
  "timestamp": "..."
}
```

并设置状态为 `failed`。

---

## 注意事项

1. **单一控制**: 每次只能运行一个 demo
2. **调用顺序**: 必须在启动新 demo 前调用 `/attack/reset`
3. **超时**: 建议为每个 demo 预留 40 秒等待时间
4. **WebSocket**: 适合实时监控和前端集成
5. **HTTP**: 适合脚本化测试和后续处理

