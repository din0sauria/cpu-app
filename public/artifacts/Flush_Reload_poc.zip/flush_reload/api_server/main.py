import asyncio
import datetime
import re
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI(title="Mastik Cache Side-Channel API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class StartRequest(BaseModel):
    config: Dict[str, Any] = Field(default_factory=dict)


@dataclass(frozen=True)
class AttackProfile:
    profile_id: str
    phase_name: str
    display_name: str
    command: List[str]
    timeout_sec: int


PROFILES: Dict[str, AttackProfile] = {
    "flush_reload": AttackProfile(
        profile_id="flush_reload",
        phase_name="flush_reload",
        display_name="Flush+Reload (FR-threshold)",
        command=["./FR-threshold"],
        timeout_sec=90,
    ),
}

runtime_lock = asyncio.Lock()
active_websockets: List[WebSocket] = []
runner_task: Optional[asyncio.Task] = None
current_process: Optional[asyncio.subprocess.Process] = None
stop_requested = False

status_state: Dict[str, Any] = {
    "status": "idle",
    "current_phase": None,
    "selected_profiles": [],
    "started_at": None,
    "updated_at": None,
}
last_report: Dict[str, Any] = {}
last_run_results: List[Dict[str, Any]] = []


def ts() -> str:
    return datetime.datetime.utcnow().isoformat() + "Z"


def root_dir() -> Path:
    return Path(__file__).resolve().parents[1]


def now_iso() -> str:
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


async def broadcast(payload: Dict[str, Any]) -> None:
    payload.setdefault("timestamp", ts())
    dead: List[WebSocket] = []
    for ws in active_websockets:
        try:
            await ws.send_json(payload)
        except Exception:
            dead.append(ws)
    for ws in dead:
        try:
            active_websockets.remove(ws)
        except ValueError:
            pass


def update_status(status: str, phase: Optional[str] = None) -> None:
    status_state["status"] = status
    status_state["current_phase"] = phase
    status_state["updated_at"] = ts()


def phase_payload(event_type: str, phase_index: int, phase_name: str, **kwargs: Any) -> Dict[str, Any]:
    payload: Dict[str, Any] = {
        "type": event_type,
        "phase": phase_name,
        "phase_id": phase_index - 1,
        "phase_index": phase_index,
        "phase_name": phase_name,
    }
    payload.update(kwargs)
    return payload


async def emit_phase_start(phase_index: int, phase_name: str, display: str, render: str = "plain_text") -> None:
    await broadcast(phase_payload("phase_start", phase_index, phase_name, display=display, render=render))


async def emit_phase_progress(
    phase_index: int,
    phase_name: str,
    percent: int,
    display: str,
    render: str = "progress_bar",
) -> None:
    await broadcast(
        phase_payload(
            "phase_progress",
            phase_index,
            phase_name,
            progress={"percent": max(0, min(100, int(percent)))},
            display=display,
            render=render,
        )
    )


async def emit_phase_complete(
    phase_index: int,
    phase_name: str,
    result: Dict[str, Any],
    display: Optional[str] = None,
) -> None:
    await broadcast(
        phase_payload(
            "phase_complete",
            phase_index,
            phase_name,
            result=result,
            display=display or f"{phase_name} completed",
            render="plain_text",
        )
    )


async def run_cmd(cmd: List[str], cwd: Path, timeout_sec: int, source: str) -> Dict[str, Any]:
    global current_process

    start = datetime.datetime.utcnow()
    lines: List[str] = []
    timed_out = False

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        cwd=str(cwd),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    current_process = proc

    async def _reader() -> None:
        if proc.stdout is None:
            return
        while True:
            line = await proc.stdout.readline()
            if not line:
                break
            text = line.decode(errors="ignore").rstrip()
            if not text:
                continue
            lines.append(text)
            await broadcast({"type": "log", "source": source, "line": text})

    reader_task = asyncio.create_task(_reader())
    try:
        await asyncio.wait_for(proc.wait(), timeout=timeout_sec)
    except asyncio.TimeoutError:
        timed_out = True
        try:
            proc.terminate()
            await asyncio.wait_for(proc.wait(), timeout=3)
        except Exception:
            proc.kill()
            await proc.wait()
    finally:
        await reader_task
        current_process = None

    duration = (datetime.datetime.utcnow() - start).total_seconds()
    return {
        "cmd": cmd,
        "cwd": str(cwd),
        "exit_code": proc.returncode,
        "timeout": timed_out,
        "duration_seconds": duration,
        "lines": lines,
    }


def normalize_profile_name(value: str) -> str:
    raw = value.strip().lower()
    aliases = {
        "fr": "flush_reload",
        "flush+reload": "flush_reload",
        "flush_reload": "flush_reload",
        "flush-reload": "flush_reload",
        "pp": "prime_probe",
        "prime+probe": "prime_probe",
        "prime_probe": "prime_probe",
        "prime-probe": "prime_probe",
        "all": "all",
        "both": "all",
    }
    return aliases.get(raw, raw)


def resolve_profiles(config: Dict[str, Any]) -> List[AttackProfile]:
    requested: List[str] = []

    raw_profile = config.get("profile")
    if isinstance(raw_profile, str) and raw_profile.strip():
        requested.append(raw_profile)

    raw_types = config.get("attack_types")
    if isinstance(raw_types, list):
        requested.extend(str(item) for item in raw_types)
    elif isinstance(raw_types, str) and raw_types.strip():
        requested.append(raw_types)

    normalized = [normalize_profile_name(item) for item in requested if str(item).strip()]
    if not normalized or "all" in normalized:
        return [next(iter(PROFILES.values()))]

    result: List[AttackProfile] = []
    for item in normalized:
        profile = PROFILES.get(item)
        if profile and profile not in result:
            result.append(profile)

    return result or [next(iter(PROFILES.values()))]


def extract_flush_reload_metrics(lines: List[str]) -> Dict[str, Optional[int]]:
    metrics = {
        "memory_min": None,
        "cache_min": None,
        "memory_median": None,
        "cache_median": None,
    }
    patterns = {
        "minimum": re.compile(r"^Minimum\s*:\s*(\d+)\s+(\d+)"),
        "median": re.compile(r"^Median\s*:\s*(\d+)\s+(\d+)"),
    }
    for line in lines:
        m = patterns["minimum"].search(line)
        if m:
            metrics["memory_min"] = int(m.group(1))
            metrics["cache_min"] = int(m.group(2))
            continue
        m = patterns["median"].search(line)
        if m:
            metrics["memory_median"] = int(m.group(1))
            metrics["cache_median"] = int(m.group(2))
    return metrics


def extract_prime_probe_guesses(lines: List[str]) -> List[Dict[str, str]]:
    guesses: List[Dict[str, str]] = []
    pattern = re.compile(r"^Key byte\s+(\d+)\s+Guess:([0-9a-fA-F]+)-")
    for line in lines:
        m = pattern.search(line)
        if not m:
            continue
        guesses.append({"byte": m.group(1), "guess": m.group(2).lower()})
    return guesses


def summarize_case(profile: AttackProfile, result: Dict[str, Any]) -> Dict[str, Any]:
    run_success = bool(result["exit_code"] == 0 and not result["timeout"])
    lines: List[str] = result["lines"]

    parsed: Dict[str, Any] = {}
    vulnerability_present = False
    vulnerability_reason = "No vulnerability evidence rule matched"
    if profile.profile_id == "flush_reload":
        parsed = extract_flush_reload_metrics(lines)
        mem_med = parsed.get("memory_median")
        cache_med = parsed.get("cache_median")
        mem_min = parsed.get("memory_min")
        cache_min = parsed.get("cache_min")
        if (
            run_success
            and isinstance(mem_med, int)
            and isinstance(cache_med, int)
            and isinstance(mem_min, int)
            and isinstance(cache_min, int)
            and (mem_med - cache_med >= 20)
            and (mem_min - cache_min >= 10)
        ):
            vulnerability_present = True
            vulnerability_reason = "Flush+Reload timing gap is significant (cache hit markedly faster than memory)"
        elif run_success:
            vulnerability_reason = "Flush+Reload timing gap not significant enough"
    elif profile.profile_id == "prime_probe":
        guesses = extract_prime_probe_guesses(lines)
        parsed = {"key_guesses": guesses}
        if run_success and len(guesses) >= 8:
            vulnerability_present = True
            vulnerability_reason = "Prime+Probe recovered stable key-byte guesses"
        elif run_success:
            vulnerability_reason = "Prime+Probe did not recover enough key-byte guesses"

    return {
        "profile": profile.profile_id,
        "phase_name": profile.phase_name,
        "display_name": profile.display_name,
        "success": run_success,
        "exit_code": result["exit_code"],
        "timeout": result["timeout"],
        "duration_seconds": result["duration_seconds"],
        "line_count": len(lines),
        "parsed": parsed,
        "vulnerability_present": vulnerability_present,
        "vulnerability_reason": vulnerability_reason,
        "sample_output": lines[:40],
    }


def build_report_markdown(
    started_at: str,
    finished_at: str,
    selected_profiles: List[AttackProfile],
    case_results: List[Dict[str, Any]],
) -> str:
    lines: List[str] = []
    lines.append("# Mastik 检测报告")
    lines.append("")
    lines.append(f"- 开始时间: {started_at}")
    lines.append(f"- 结束时间: {finished_at}")
    lines.append(f"- 检测项: {', '.join(p.profile_id for p in selected_profiles)}")
    lines.append("")

    for idx, item in enumerate(case_results, start=1):
        lines.append(f"## {idx}. {item['display_name']}")
        lines.append(f"- 执行状态: {'success' if item['success'] else 'failed'}")
        lines.append(f"- 漏洞结论: {'存在漏洞' if item.get('vulnerability_present') else '未确认漏洞'}")
        lines.append(f"- 判定依据: {item.get('vulnerability_reason', '-')}")
        lines.append(f"- 退出码: {item['exit_code']}")
        lines.append(f"- 超时: {item['timeout']}")
        lines.append(f"- 耗时: {item['duration_seconds']:.2f}s")
        lines.append(f"- 输出行数: {item['line_count']}")

        parsed = item.get("parsed", {})
        if item["profile"] == "flush_reload":
            lines.append("- 预期窃取目标: 不窃取具体数据，仅测量并标定 Cache 与 Memory 的时间延迟差距 (Threshold)")
            lines.append("- 实际检测到的信息 (关键时间指标):")
            lines.append(f"  - memory_min: {parsed.get('memory_min')}")
            lines.append(f"  - cache_min: {parsed.get('cache_min')}")
            lines.append(f"  - memory_median: {parsed.get('memory_median')}")
            lines.append(f"  - cache_median: {parsed.get('cache_median')}")
        elif item["profile"] == "prime_probe":
            lines.append("- 预期窃取目标: 'AES KEY: 2b7e151628aed2a6abf7158809cf4f3c (Leaking High Nibbles: 2, 7, 1, 1, 2, a, d, a, a, f, 1, 8, 0, c, 4, 3)'")
            lines.append("- 实际窃取到的信息 (密钥猜测情况):")
            guesses = parsed.get("key_guesses", [])
            lines.append(f"  - 密钥猜测条目: {len(guesses)}")
            if guesses:
                preview = ", ".join(f"b{g['byte']}={g['guess']}" for g in guesses[:8])
                lines.append(f"  - 预览: {preview}")

        sample = item.get("sample_output", [])
        if sample:
            lines.append("")
            lines.append("- 原始终端片段:")
            lines.append("```text")
            lines.extend(sample[:20])
            lines.append("```")

        lines.append("")

    return "\n".join(lines).strip() + "\n"


async def run_attack(config: Dict[str, Any]) -> None:
    global runner_task, stop_requested, last_report, last_run_results

    work_root = root_dir()
    selected_profiles = resolve_profiles(config)
    status_state["selected_profiles"] = [p.profile_id for p in selected_profiles]

    started_at = ts()
    status_state["started_at"] = started_at
    update_status("running", "environment_build")
    case_results: List[Dict[str, Any]] = []

    try:
        build_timeout_sec = int(config.get("build_timeout_sec", 300))

        await emit_phase_start(1, "environment_build", "构建 Mastik 依赖与 PoC 二进制")
        await emit_phase_progress(1, "environment_build", 10, "开始构建 libmastik")

        step1 = await run_cmd(["make", "-C", "src"], work_root, build_timeout_sec, "build")
        if step1["exit_code"] != 0:
            raise RuntimeError("build libmastik failed")

        await emit_phase_progress(1, "environment_build", 55, "开始构建 FR/PP 演示程序")
        step2 = await run_cmd(
            ["make", "-C", "demo", "FR-threshold"],
            work_root,
            build_timeout_sec,
            "build",
        )
        if step2["exit_code"] != 0:
            raise RuntimeError("build demo binaries failed")

        await emit_phase_progress(1, "environment_build", 100, "环境依赖构建完成")
        await emit_phase_complete(
            1,
            "environment_build",
            {
                "step_results": [
                    {"step": "make -C src", "exit_code": step1["exit_code"], "timeout": step1["timeout"]},
                    {
                        "step": "make -C demo FR-threshold",
                        "exit_code": step2["exit_code"],
                        "timeout": step2["timeout"],
                    },
                ]
            },
        )

        phase_index = 2
        for profile in selected_profiles:
            if stop_requested:
                break

            update_status("running", profile.phase_name)
            await emit_phase_start(phase_index, profile.phase_name, f"运行 {profile.display_name}")
            run_result = await run_cmd(profile.command, work_root / "demo", profile.timeout_sec, profile.profile_id)
            summary = summarize_case(profile, run_result)
            case_results.append(summary)
            await emit_phase_complete(phase_index, profile.phase_name, summary)
            phase_index += 1

        report_phase_index = len(selected_profiles) + 2
        update_status("running", "report_generation")
        await emit_phase_start(report_phase_index, "report_generation", "生成 Markdown 报告", render="markdown")

        finished_at = ts()
        report_markdown = build_report_markdown(started_at, finished_at, selected_profiles, case_results)

        success = bool(
            (not stop_requested)
            and case_results
            and any(item.get("vulnerability_present") for item in case_results)
        )

        report = {
            "report_id": uuid.uuid4().hex,
            "module": "mastik",
            "success": success,
            "started_at": started_at,
            "finished_at": finished_at,
            "summary": (
                "Mastik observed cache side-channel behavior indicating vulnerability"
                if success
                else "Mastik did not observe convincing cache side-channel evidence in this run"
            ),
            "findings": [
                {
                    "profile": item["profile"],
                    "success": item["success"],
                    "vulnerability_present": item.get("vulnerability_present", False),
                    "vulnerability_reason": item.get("vulnerability_reason", ""),
                    "duration_seconds": item["duration_seconds"],
                    "parsed": item.get("parsed", {}),
                }
                for item in case_results
            ],
            "artifacts": [
                {
                    "name": "mastik_report.md",
                    "format": "markdown",
                    "content_preview": report_markdown[:120],
                }
            ],
        }

        last_report = report
        last_run_results = case_results

        await broadcast(
            phase_payload(
                "report_file",
                report_phase_index,
                "report_generation",
                report_file={
                    "name": "mastik_report.md",
                    "format": "markdown",
                    "content": report_markdown,
                },
                display="报告已生成",
                render="markdown",
            )
        )

        await emit_phase_complete(
            report_phase_index,
            "report_generation",
            {"report_id": report["report_id"], "report_name": "mastik_report.md"},
        )

        await broadcast({"type": "attack_complete", "success": success, "report": report})
        update_status("stopped", "report_generation")
    except Exception as exc:
        update_status("error", status_state.get("current_phase"))
        await broadcast({"type": "error", "message": str(exc)})
        await broadcast({"type": "attack_complete", "success": False})
    finally:
        runner_task = None
        stop_requested = False


@app.post("/attack/start")
async def attack_start(req: StartRequest) -> Dict[str, Any]:
    global runner_task, stop_requested

    async with runtime_lock:
        if runner_task and not runner_task.done():
            return {"status": "already_running"}

        stop_requested = False
        status_state["selected_profiles"] = [p.profile_id for p in resolve_profiles(req.config)]
        runner_task = asyncio.create_task(run_attack(req.config))
        return {
            "status": "running",
            "profiles": status_state["selected_profiles"],
            "phase_count": len(status_state["selected_profiles"]) + 2,
        }


@app.post("/attack/stop")
async def attack_stop() -> Dict[str, Any]:
    global stop_requested, current_process

    stop_requested = True
    proc = current_process
    if proc and proc.returncode is None:
        try:
            proc.terminate()
        except Exception:
            pass

    update_status("stopped", status_state.get("current_phase"))
    await broadcast({"type": "log", "source": "control", "line": "Stop requested by controller"})
    return {"status": "stopping"}


@app.post("/attack/reset")
async def attack_reset() -> Dict[str, Any]:
    global last_report, last_run_results, stop_requested

    async with runtime_lock:
        if runner_task and not runner_task.done():
            return {"status": "busy", "message": "cannot reset while running"}

        stop_requested = False
        last_report = {}
        last_run_results = []
        status_state["status"] = "idle"
        status_state["current_phase"] = None
        status_state["selected_profiles"] = []
        status_state["started_at"] = None
        status_state["updated_at"] = ts()
        return {"status": "idle"}


@app.get("/attack/status")
async def attack_status() -> Dict[str, Any]:
    return {
        "status": status_state.get("status", "idle"),
        "current_phase": status_state.get("current_phase"),
        "selected_profiles": status_state.get("selected_profiles", []),
        "started_at": status_state.get("started_at"),
        "updated_at": status_state.get("updated_at"),
        "last_report": last_report,
        "last_run_results": last_run_results,
    }


@app.websocket("/attack")
async def attack_ws(websocket: WebSocket) -> None:
    await websocket.accept()
    active_websockets.append(websocket)
    await websocket.send_json(
        {
            "type": "hello",
            "module": "mastik",
            "profiles": sorted(PROFILES.keys()),
            "time": now_iso(),
        }
    )
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        try:
            active_websockets.remove(websocket)
        except ValueError:
            pass
