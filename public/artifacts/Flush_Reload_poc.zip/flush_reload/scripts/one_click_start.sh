#!/usr/bin/env bash
set -euo pipefail

PORT="${PORT:-4045}"
HOST="${HOST:-0.0.0.0}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODULE_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

cd "${MODULE_ROOT}/api_server"
exec python3 -m uvicorn main:app --host "${HOST}" --port "${PORT}"
