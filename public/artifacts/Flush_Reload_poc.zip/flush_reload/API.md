# mastik_flush_reload API

该模块仅验证 `flush_reload` 单一检测项。

## HTTP 控制接口

- `POST /attack/start`
- `POST /attack/stop`
- `POST /attack/reset`
- `GET /attack/status`

`POST /attack/start` 示例：

```json
{
  "config": {
    "build_timeout_sec": 300
  }
}
```

## WebSocket 事件流

- `WS /attack`

常见事件：`phase_start`、`phase_progress`、`phase_complete`、`log`、`report_file`、`attack_complete`。

## 阶段定义

1. `environment_build`
2. `flush_reload`
3. `report_generation`

最后阶段顺序固定：先 `report_file`（markdown），再 `attack_complete`。
