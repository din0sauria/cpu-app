savedcmd_rvzr_executor.o := ld -m elf_x86_64 -z noexecstack --no-warn-rwx-segments   -r -o rvzr_executor.o @rvzr_executor.mod 
