#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x1bdf2bc8, "sme_me_mask" },
	{ 0xc45d298e, "is_vmalloc_addr" },
	{ 0x8904df5e, "sysfs_create_file_ns" },
	{ 0xd710adbf, "__kmalloc_noprof" },
	{ 0x531fca41, "vmalloc_to_page" },
	{ 0xd272d446, "__SCT__preempt_schedule" },
	{ 0x2c23b1ea, "sysfs_create_bin_file" },
	{ 0xa53f4e29, "memcpy" },
	{ 0xf296206e, "pgdir_shift" },
	{ 0xf1de9e85, "vunmap" },
	{ 0xcb8b6ec6, "kfree" },
	{ 0x4ff89cd9, "pcpu_hot" },
	{ 0x8a832107, "kernel_kobj" },
	{ 0x5ae9ee26, "__per_cpu_offset" },
	{ 0xdb3a16c0, "do_trace_read_msr" },
	{ 0xd272d446, "__fentry__" },
	{ 0x5a844b26, "__x86_indirect_thunk_rax" },
	{ 0xe8213e80, "_printk" },
	{ 0xd272d446, "__stack_chk_fail" },
	{ 0x6c1b4046, "kernel_fpu_begin_mask" },
	{ 0xd272d446, "kernel_fpu_end" },
	{ 0xdf157197, "__free_pages" },
	{ 0x90a48d82, "__ubsan_handle_out_of_bounds" },
	{ 0xbd03ed67, "page_offset_base" },
	{ 0x095159b2, "physical_mask" },
	{ 0xbd03ed67, "random_kmalloc_seed" },
	{ 0xd7a59a65, "vmalloc_noprof" },
	{ 0x5a844b26, "__x86_indirect_thunk_rbx" },
	{ 0xf5bae445, "__virt_addr_valid" },
	{ 0xbd03ed67, "phys_base" },
	{ 0x0392bc4c, "vmap" },
	{ 0x173ec8da, "sscanf" },
	{ 0xe54e0a6b, "__fortify_panic" },
	{ 0x69fc1ea6, "__tracepoint_write_msr" },
	{ 0x5fc55113, "__default_kernel_pte_mask" },
	{ 0x27683a56, "memset" },
	{ 0xf296206e, "ptrs_per_p4d" },
	{ 0xd272d446, "__x86_return_thunk" },
	{ 0xdec6d135, "kobject_create_and_add" },
	{ 0xb3f8c2e9, "pv_ops" },
	{ 0xdd6830c7, "sprintf" },
	{ 0xbd03ed67, "vmemmap_base" },
	{ 0x82fd7238, "__ubsan_handle_shift_out_of_bounds" },
	{ 0xf1de9e85, "vfree" },
	{ 0xb1ad3f2f, "cpu_info" },
	{ 0xdb3a16c0, "do_trace_write_msr" },
	{ 0x70db3fe4, "__kmalloc_cache_noprof" },
	{ 0x69fc1ea6, "__tracepoint_read_msr" },
	{ 0x1c489eb6, "register_kprobe" },
	{ 0xb54d37ac, "alloc_pages_noprof" },
	{ 0xb1ad3f2f, "boot_cpu_data" },
	{ 0x7a8e92c6, "unregister_kprobe" },
	{ 0xe4de56b4, "__ubsan_handle_load_invalid_value" },
	{ 0x5a844b26, "__x86_indirect_thunk_r8" },
	{ 0xd272d446, "BUG_func" },
	{ 0xfed1e3bc, "kmalloc_caches" },
	{ 0xe125349f, "kobject_put" },
	{ 0xba157484, "module_layout" },
};

static const u32 ____version_ext_crcs[]
__used __section("__version_ext_crcs") = {
	0x1bdf2bc8,
	0xc45d298e,
	0x8904df5e,
	0xd710adbf,
	0x531fca41,
	0xd272d446,
	0x2c23b1ea,
	0xa53f4e29,
	0xf296206e,
	0xf1de9e85,
	0xcb8b6ec6,
	0x4ff89cd9,
	0x8a832107,
	0x5ae9ee26,
	0xdb3a16c0,
	0xd272d446,
	0x5a844b26,
	0xe8213e80,
	0xd272d446,
	0x6c1b4046,
	0xd272d446,
	0xdf157197,
	0x90a48d82,
	0xbd03ed67,
	0x095159b2,
	0xbd03ed67,
	0xd7a59a65,
	0x5a844b26,
	0xf5bae445,
	0xbd03ed67,
	0x0392bc4c,
	0x173ec8da,
	0xe54e0a6b,
	0x69fc1ea6,
	0x5fc55113,
	0x27683a56,
	0xf296206e,
	0xd272d446,
	0xdec6d135,
	0xb3f8c2e9,
	0xdd6830c7,
	0xbd03ed67,
	0x82fd7238,
	0xf1de9e85,
	0xb1ad3f2f,
	0xdb3a16c0,
	0x70db3fe4,
	0x69fc1ea6,
	0x1c489eb6,
	0xb54d37ac,
	0xb1ad3f2f,
	0x7a8e92c6,
	0xe4de56b4,
	0x5a844b26,
	0xd272d446,
	0xfed1e3bc,
	0xe125349f,
	0xba157484,
};
static const char ____version_ext_names[]
__used __section("__version_ext_names") =
	"sme_me_mask\0"
	"is_vmalloc_addr\0"
	"sysfs_create_file_ns\0"
	"__kmalloc_noprof\0"
	"vmalloc_to_page\0"
	"__SCT__preempt_schedule\0"
	"sysfs_create_bin_file\0"
	"memcpy\0"
	"pgdir_shift\0"
	"vunmap\0"
	"kfree\0"
	"pcpu_hot\0"
	"kernel_kobj\0"
	"__per_cpu_offset\0"
	"do_trace_read_msr\0"
	"__fentry__\0"
	"__x86_indirect_thunk_rax\0"
	"_printk\0"
	"__stack_chk_fail\0"
	"kernel_fpu_begin_mask\0"
	"kernel_fpu_end\0"
	"__free_pages\0"
	"__ubsan_handle_out_of_bounds\0"
	"page_offset_base\0"
	"physical_mask\0"
	"random_kmalloc_seed\0"
	"vmalloc_noprof\0"
	"__x86_indirect_thunk_rbx\0"
	"__virt_addr_valid\0"
	"phys_base\0"
	"vmap\0"
	"sscanf\0"
	"__fortify_panic\0"
	"__tracepoint_write_msr\0"
	"__default_kernel_pte_mask\0"
	"memset\0"
	"ptrs_per_p4d\0"
	"__x86_return_thunk\0"
	"kobject_create_and_add\0"
	"pv_ops\0"
	"sprintf\0"
	"vmemmap_base\0"
	"__ubsan_handle_shift_out_of_bounds\0"
	"vfree\0"
	"cpu_info\0"
	"do_trace_write_msr\0"
	"__kmalloc_cache_noprof\0"
	"__tracepoint_read_msr\0"
	"register_kprobe\0"
	"alloc_pages_noprof\0"
	"boot_cpu_data\0"
	"unregister_kprobe\0"
	"__ubsan_handle_load_invalid_value\0"
	"__x86_indirect_thunk_r8\0"
	"BUG_func\0"
	"kmalloc_caches\0"
	"kobject_put\0"
	"module_layout\0"
;

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "910FF710450912220AF1704");
