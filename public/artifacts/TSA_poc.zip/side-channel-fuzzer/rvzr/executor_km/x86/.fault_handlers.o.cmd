savedcmd_x86/fault_handlers.o := gcc-13 -Wp,-MMD,x86/.fault_handlers.o.d -nostdinc -I/usr/src/linux-headers-6.14.0-37-generic/arch/x86/include -I/usr/src/linux-headers-6.14.0-37-generic/arch/x86/include/generated -I/usr/src/linux-headers-6.14.0-37-generic/include -I/usr/src/linux-headers-6.14.0-37-generic/include -I/usr/src/linux-headers-6.14.0-37-generic/arch/x86/include/uapi -I/usr/src/linux-headers-6.14.0-37-generic/arch/x86/include/generated/uapi -I/usr/src/linux-headers-6.14.0-37-generic/include/uapi -I/usr/src/linux-headers-6.14.0-37-generic/include/generated/uapi -include /usr/src/linux-headers-6.14.0-37-generic/include/linux/compiler-version.h -include /usr/src/linux-headers-6.14.0-37-generic/include/linux/kconfig.h -I/usr/src/linux-headers-6.14.0-37-generic/ubuntu/include -D__KERNEL__ -D__ASSEMBLY__ -fno-PIE -m64 -DCC_USING_FENTRY -g -gdwarf-5 -I././include -DVENDOR_ID=2 -DPHYSICAL_WIDTH=48 -DL1D_ASSOCIATIVITY=8 -DL1D_SIZE_KB=32 -I././include -DVENDOR_ID=2 -DPHYSICAL_WIDTH=48 -DL1D_ASSOCIATIVITY=8 -DL1D_SIZE_KB=32  -DMODULE  -DKBUILD_MODNAME='"rvzr_executor"' -D__KBUILD_MODNAME=kmod_rvzr_executor -c -o x86/fault_handlers.o x86/fault_handlers.S 

source_x86/fault_handlers.o := x86/fault_handlers.S

deps_x86/fault_handlers.o := \
  /usr/src/linux-headers-6.14.0-37-generic/include/linux/compiler-version.h \
    $(wildcard include/config/CC_VERSION_TEXT) \
  /usr/src/linux-headers-6.14.0-37-generic/include/linux/kconfig.h \
    $(wildcard include/config/CPU_BIG_ENDIAN) \
    $(wildcard include/config/BOOGER) \
    $(wildcard include/config/FOO) \
  include/sandbox_constants.h \
  include/hardware_desc.h \
  /usr/src/linux-headers-6.14.0-37-generic/include/linux/types.h \
    $(wildcard include/config/HAVE_UID16) \
    $(wildcard include/config/UID16) \
    $(wildcard include/config/ARCH_DMA_ADDR_T_64BIT) \
    $(wildcard include/config/PHYS_ADDR_T_64BIT) \
    $(wildcard include/config/64BIT) \
    $(wildcard include/config/ARCH_32BIT_USTAT_F_TINODE) \
  /usr/src/linux-headers-6.14.0-37-generic/include/uapi/linux/types.h \
  /usr/src/linux-headers-6.14.0-37-generic/arch/x86/include/generated/uapi/asm/types.h \
  /usr/src/linux-headers-6.14.0-37-generic/include/uapi/asm-generic/types.h \
  /usr/src/linux-headers-6.14.0-37-generic/include/asm-generic/int-ll64.h \
  /usr/src/linux-headers-6.14.0-37-generic/include/uapi/asm-generic/int-ll64.h \
  /usr/src/linux-headers-6.14.0-37-generic/arch/x86/include/uapi/asm/bitsperlong.h \
  /usr/src/linux-headers-6.14.0-37-generic/include/asm-generic/bitsperlong.h \
  /usr/src/linux-headers-6.14.0-37-generic/include/uapi/asm-generic/bitsperlong.h \
  x86/registers.h \

x86/fault_handlers.o: $(deps_x86/fault_handlers.o)

$(deps_x86/fault_handlers.o):
