#!/usr/bin/env python3
"""
Foreshadow-VMM WebSocket Client Example
Used for testing the L1TF attack service
"""

import socketio
import json
import argparse
import sys
from datetime import datetime

# Initialize Socket.IO client
sio = socketio.Client()

# Color codes for terminal output
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

def print_message(msg_type, content, color=Colors.BLUE):
    """Pretty print message with timestamp and type"""
    timestamp = datetime.now().strftime("%H:%M:%S")
    print(f"{color}[{timestamp}] {msg_type}:{Colors.ENDC} {content}")

@sio.event
def connect():
    """Handle connection"""
    print_message("INFO", "Connected to server", Colors.GREEN)

@sio.event
def connection_response(data):
    """Handle connection response"""
    print_message("SERVER", json.dumps(data, indent=2), Colors.GREEN)

@sio.on('attack_started')
def on_attack_started(data):
    """Attack has started"""
    print_message("ATTACK", "Attack started!", Colors.YELLOW)
    print(f"  Command: {data.get('command')}")
    print(f"  Address: {data.get('phys_addr')}")
    print(f"  Length: {data.get('length')}")

@sio.on('phase_start')
def on_phase_start(data):
    """Phase started"""
    phase = data.get('phase', 'unknown')
    phase_id = data.get('phase_id', '?')
    print_message("PHASE", f"[{phase_id}] {phase.upper()}: {data.get('message')}", Colors.CYAN)

@sio.on('discovery')
def on_discovery(data):
    """Discovery event"""
    disc_type = data.get('discovery_type', 'unknown')
    msg = data.get('message', '')
    disc_data = data.get('data', {})
    print_message("DISCOVERY", f"[{disc_type}] {msg}", Colors.CYAN)
    for key, value in disc_data.items():
        print(f"    {key}: {value}")

@sio.on('hex_data')
def on_hex_data(data):
    """Hex data received"""
    hex_output = data.get('data', '')
    print_message("DATA", hex_output, Colors.GREEN)

@sio.on('log')
def on_log(data):
    """Log message"""
    msg = data.get('message', '')
    print_message("LOG", msg, Colors.BLUE)

@sio.on('attack_complete')
def on_attack_complete(data):
    """Attack completed"""
    success = data.get('success', False)
    total_time = data.get('total_time_seconds', 0)
    
    if success:
        print_message("SUCCESS", f"Attack completed! Total time: {total_time:.2f}s", Colors.GREEN)
        leaked = data.get('leaked_data', '')
        if leaked:
            print("\n=== LEAKED DATA ===")
            print(leaked)
            print("==================\n")
    else:
        error = data.get('error', 'Unknown error')
        print_message("FAILURE", f"Attack failed: {error}", Colors.RED)

@sio.on('status')
def on_status(data):
    """Status update"""
    print_message("STATUS", json.dumps(data, indent=2), Colors.BLUE)

@sio.on('error')
def on_error(data):
    """Error message"""
    msg = data.get('message', 'Unknown error')
    print_message("ERROR", msg, Colors.RED)

@sio.event
def disconnect():
    """Handle disconnection"""
    print_message("INFO", "Disconnected from server", Colors.RED)

def main():
    parser = argparse.ArgumentParser(description='L1TF WebSocket Client')
    parser.add_argument('--host', default='localhost', help='Server host')
    parser.add_argument('--port', type=int, default=3030, help='Server port')
    parser.add_argument('--addr', default='0x1000', help='Physical address to attack')
    parser.add_argument('--len', type=int, default=0x40, help='Bytes to read')
    parser.add_argument('--no-attack', action='store_true', help='Connect without starting attack')
    
    args = parser.parse_args()
    
    url = f'http://{args.host}:{args.port}'
    
    try:
        print(f"{Colors.BOLD}Connecting to {url}...{Colors.ENDC}")
        sio.connect(url, wait_timeout=10)
        
        if not args.no_attack:
            print(f"\n{Colors.YELLOW}Starting attack...{Colors.ENDC}")
            print(f"  Target address: {args.addr}")
            print(f"  Bytes to read: {args.len} (0x{args.len:x})\n")
            
            sio.emit('start_attack', {
                'phys_addr': args.addr,
                'length': args.len
            })
        else:
            print(f"\n{Colors.CYAN}Connected. Waiting for events...{Colors.ENDC}")
            sio.emit('get_status')
        
        # Keep running until disconnected
        sio.wait()
    
    except ConnectionError:
        print(f"{Colors.RED}Error: Could not connect to server at {url}{Colors.ENDC}")
        sys.exit(1)
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}Interrupted by user{Colors.ENDC}")
        if sio.connected:
            sio.emit('stop_attack')
            sio.disconnect()
        sys.exit(0)
    except Exception as e:
        print(f"{Colors.RED}Error: {e}{Colors.ENDC}")
        sys.exit(1)

if __name__ == '__main__':
    main()
