#!/usr/bin/env python3
import asyncio
import datetime
import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI(title="L1TF (Foreshadow) API", version="2.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class StartRequest(BaseModel):
    config: Dict[str, Any] = Field(default_factory=dict)


runtime_lock = asyncio.Lock()
active_websockets: List[WebSocket] = []
runner_task: Optional[asyncio.Task] = None
current_process: Optional[asyncio.subprocess.Process] = None
stop_requested = False
status_state: Dict[str, Any] = {
    "status": "idle",
    "current_phase": None,
    "started_at": None,
    "updated_at": None,
}
last_execution: Dict[str, Any] = {}
last_report: Dict[str, Any] = {}


def ts() -> str:
    return datetime.datetime.utcnow().isoformat() + "Z"


def module_root() -> Path:
    return Path(__file__).resolve().parents[1]


async def broadcast(payload: Dict[str, Any]) -> None:
    payload.setdefault("timestamp", ts())
    dead: List[WebSocket] = []
    for ws in active_websockets:
        try:
            await ws.send_json(payload)
        except Exception:
            dead.append(ws)
    for ws in dead:
        try:
            active_websockets.remove(ws)
        except ValueError:
            pass


def update_status(status: str, phase: Optional[str] = None) -> None:
    status_state["status"] = status
    status_state["current_phase"] = phase
    status_state["updated_at"] = ts()


async def emit_phase_start(phase_index: int, phase_name: str, display: str, render: str = "plain_text") -> None:
    await broadcast(
        {
            "type": "phase_start",
            "phase_index": phase_index,
            "phase_name": phase_name,
            "display": display,
            "render": render,
        }
    )


async def emit_phase_progress(phase_index: int, phase_name: str, percent: int, display: str) -> None:
    await broadcast(
        {
            "type": "phase_progress",
            "phase_index": phase_index,
            "phase_name": phase_name,
            "progress": {"percent": max(0, min(100, int(percent)))},
            "display": display,
            "render": "progress_bar",
        }
    )


async def emit_phase_complete(phase_index: int, phase_name: str, result: Dict[str, Any]) -> None:
    await broadcast(
        {
            "type": "phase_complete",
            "phase_index": phase_index,
            "phase_name": phase_name,
            "result": result,
            "display": f"{phase_name} completed",
            "render": "plain_text",
        }
    )


async def run_cmd(
    cmd: List[str],
    cwd: Path,
    timeout_sec: int,
    log_prefix: str,
    env: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    global current_process

    start = datetime.datetime.utcnow()
    lines: List[str] = []
    timed_out = False

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        cwd=str(cwd),
        env=env,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    current_process = proc

    async def _reader() -> None:
        if proc.stdout is None:
            return
        while True:
            line = await proc.stdout.readline()
            if not line:
                break
            text = line.decode(errors="ignore").rstrip()
            if text:
                lines.append(text)
                await broadcast(
                    {
                        "type": "log",
                        "source": log_prefix,
                        "line": text,
                        "display": text,
                        "render": "plain_text",
                    }
                )

    reader_task = asyncio.create_task(_reader())
    try:
        await asyncio.wait_for(proc.wait(), timeout=timeout_sec)
    except asyncio.TimeoutError:
        timed_out = True
        try:
            proc.terminate()
            await asyncio.wait_for(proc.wait(), timeout=3)
        except Exception:
            proc.kill()
            await proc.wait()
    finally:
        await reader_task
        current_process = None

    end = datetime.datetime.utcnow()
    return {
        "cmd": cmd,
        "cwd": str(cwd),
        "exit_code": proc.returncode,
        "timeout": timed_out,
        "duration_seconds": (end - start).total_seconds(),
        "lines": lines,
    }


def parse_doit_events(line: str) -> Optional[Dict[str, Any]]:
    if re.search(r"Looking for the PTE for VA", line):
        return {
            "event": "phase_start",
            "phase_index": 2,
            "phase_name": "pte_search",
            "display": line,
            "render": "plain_text",
        }

    if re.search(r"Dumping from VA", line):
        return {
            "event": "phase_start",
            "phase_index": 3,
            "phase_name": "memory_dump",
            "display": line,
            "render": "plain_text",
        }

    hex_matches = re.findall(r"([0-9a-fA-F]{2}|\?\?)", line)
    if hex_matches:
        return {
            "event": "hex_data",
            "hex_data": " ".join(hex_matches),
            "display": " ".join(hex_matches),
            "render": "plain_text",
        }

    return None


async def run_attack(config: Dict[str, Any]) -> None:
    global runner_task, stop_requested, last_execution, last_report

    root = module_root()
    build_timeout_sec = int(config.get("build_timeout_sec", 180))
    attack_timeout_sec = int(config.get("attack_timeout_sec", 120))
    build_before_run = bool(config.get("build_before_run", True))
    skip_kmod_build = bool(config.get("skip_kmod_build", True))

    phys_addr = str(config.get("phys_addr", "0x0"))
    length = int(config.get("length", 64))

    status_state["started_at"] = ts()
    update_status("running", "environment_build")

    stage_results: Dict[str, Any] = {
        "environment_build": {"ok": True},
        "pte_search": {"ok": False},
        "memory_dump": {"ok": False},
    }
    leaked_lines: List[str] = []
    raw_log_lines: List[str] = []

    await emit_phase_start(1, "environment_build", "准备环境并检查可执行文件")
    await emit_phase_progress(1, "environment_build", 10, "检查模块目录")

    doit_path = root / "doit"
    build_env = os.environ.copy()
    if skip_kmod_build:
        build_env["SKIP_KMOD_BUILD"] = "1"

    if build_before_run:
        build_script = root / "build.sh"
        if not build_script.exists():
            stage_results["environment_build"] = {
                "ok": False,
                "reason": "build.sh not found",
            }
            await broadcast(
                {
                    "type": "error",
                    "phase_index": 1,
                    "phase_name": "environment_build",
                    "display": "缺少 build.sh，无法构建 PoC",
                    "render": "plain_text",
                    "message": "build.sh not found",
                }
            )
        else:
            await emit_phase_progress(1, "environment_build", 40, "执行 build.sh")
            build_out = await run_cmd(["bash", "build.sh"], root, build_timeout_sec, "build", env=build_env)
            if build_out["exit_code"] != 0 or build_out["timeout"]:
                stage_results["environment_build"] = {
                    "ok": False,
                    "exit_code": build_out["exit_code"],
                    "timeout": build_out["timeout"],
                }
            else:
                stage_results["environment_build"] = {
                    "ok": True,
                    "exit_code": build_out["exit_code"],
                    "timeout": build_out["timeout"],
                }
    else:
        stage_results["environment_build"] = {"ok": True, "skipped": True}

    if not doit_path.exists():
        stage_results["environment_build"]["ok"] = False
        stage_results["environment_build"]["reason"] = "doit binary not found"

    await emit_phase_progress(1, "environment_build", 100, "环境构建阶段完成")
    await emit_phase_complete(1, "environment_build", stage_results["environment_build"])

    overall_success = bool(stage_results["environment_build"].get("ok", False))

    if overall_success and not stop_requested:
        update_status("running", "pte_search")
        await emit_phase_start(2, "pte_search", "开始执行 L1TF PoC")
        await emit_phase_start(3, "memory_dump", "等待进入内存转储阶段")

        cmd = [str(doit_path), phys_addr, hex(length)]
        run_out = await run_cmd(cmd, root, attack_timeout_sec, "attack")
        raw_log_lines = run_out["lines"]

        phase2_seen = False
        phase3_seen = False
        for line in raw_log_lines:
            parsed = parse_doit_events(line)
            if not parsed:
                continue
            if parsed["event"] == "phase_start" and parsed["phase_name"] == "pte_search":
                phase2_seen = True
                await emit_phase_start(2, "pte_search", parsed["display"])
            elif parsed["event"] == "phase_start" and parsed["phase_name"] == "memory_dump":
                phase3_seen = True
                await emit_phase_start(3, "memory_dump", parsed["display"])
            elif parsed["event"] == "hex_data":
                leaked_lines.append(parsed["hex_data"])
                await broadcast(
                    {
                        "type": "phase_progress",
                        "phase_index": 3,
                        "phase_name": "memory_dump",
                        "display": parsed["display"],
                        "render": "plain_text",
                    }
                )

        run_ok = (run_out["exit_code"] == 0) and (not run_out["timeout"])
        stage_results["pte_search"] = {
            "ok": phase2_seen and run_ok,
            "phase_seen": phase2_seen,
            "exit_code": run_out["exit_code"],
            "timeout": run_out["timeout"],
        }
        stage_results["memory_dump"] = {
            "ok": phase3_seen and len(leaked_lines) > 0 and run_ok,
            "phase_seen": phase3_seen,
            "leaked_line_count": len(leaked_lines),
            "exit_code": run_out["exit_code"],
            "timeout": run_out["timeout"],
        }
        await emit_phase_complete(2, "pte_search", stage_results["pte_search"])
        await emit_phase_complete(3, "memory_dump", stage_results["memory_dump"])

        if not (stage_results["pte_search"]["ok"] and stage_results["memory_dump"]["ok"]):
            overall_success = False
    else:
        overall_success = False
        if not stage_results["pte_search"].get("ok"):
            stage_results["pte_search"] = {"ok": False, "reason": "skipped because environment_build failed"}
        if not stage_results["memory_dump"].get("ok"):
            stage_results["memory_dump"] = {"ok": False, "reason": "skipped because environment_build failed"}

    report_phase_index = 4
    update_status("running", "report_generation")
    await emit_phase_start(report_phase_index, "report_generation", "生成 markdown 报告", render="markdown")

    report_lines = [
        "# L1TF (Foreshadow-VMM) Report",
        "",
        f"- generated_at: {ts()}",
        f"- module: l1tf",
        f"- overall_success: {overall_success and not stop_requested}",
        f"- phys_addr: {phys_addr}",
        f"- length: {length}",
        "",
        "## Stage Results",
        "",
        f"- environment_build: {stage_results['environment_build']}",
        f"- pte_search: {stage_results['pte_search']}",
        f"- memory_dump: {stage_results['memory_dump']}",
    ]

    if leaked_lines:
        report_lines.append("")
        report_lines.append("## Leaked Hex Data (sample)")
        for line in leaked_lines[:40]:
            report_lines.append(f"- {line}")

    if raw_log_lines:
        report_lines.append("")
        report_lines.append("## Raw Log (sample)")
        for line in raw_log_lines[:80]:
            report_lines.append(f"- {line.replace('`', "'")}")

    report_md = "\n".join(report_lines)

    report_obj = {
        "report_id": f"l1tf-{int(datetime.datetime.utcnow().timestamp())}",
        "module": "l1tf",
        "success": bool(overall_success and not stop_requested),
        "started_at": status_state.get("started_at"),
        "finished_at": ts(),
        "summary": "L1TF Foreshadow run finished",
        "findings": [stage_results],
        "artifacts": [{"name": "l1tf_report.md", "format": "markdown"}],
    }

    last_execution = {
        "success": report_obj["success"],
        "phys_addr": phys_addr,
        "length": length,
        "finished_at": report_obj["finished_at"],
    }
    last_report = report_obj

    await broadcast(
        {
            "type": "report_file",
            "phase_index": report_phase_index,
            "phase_name": "report_generation",
            "display": "报告已生成",
            "render": "markdown",
            "report_file": {
                "name": "l1tf_report.md",
                "format": "markdown",
                "content": report_md,
            },
        }
    )

    await broadcast(
        {
            "type": "attack_complete",
            "success": bool(overall_success and not stop_requested),
            "report": report_obj,
        }
    )

    update_status("idle", None)
    runner_task = None


@app.get("/attack/status")
async def attack_status() -> Dict[str, Any]:
    return {
        "status": status_state.get("status", "idle"),
        "current_phase": status_state.get("current_phase"),
        "started_at": status_state.get("started_at"),
        "updated_at": status_state.get("updated_at"),
        "timestamp": ts(),
        "last_execution": last_execution,
        "report": last_report,
        "message": "L1TF backend ready",
    }


@app.post("/attack/start")
async def attack_start(req: StartRequest) -> Dict[str, Any]:
    global runner_task, stop_requested

    async with runtime_lock:
        if runner_task and not runner_task.done():
            return {"status": "running", "message": "Attack already running", "timestamp": ts()}

        stop_requested = False
        update_status("running", "environment_build")
        runner_task = asyncio.create_task(run_attack(req.config))
        return {"status": "running", "message": "L1TF run started", "timestamp": ts()}


@app.post("/attack/stop")
async def attack_stop() -> Dict[str, Any]:
    global stop_requested, current_process

    async with runtime_lock:
        stop_requested = True
        proc = current_process
        if proc and proc.returncode is None:
            try:
                proc.terminate()
                await asyncio.wait_for(proc.wait(), timeout=3)
            except Exception:
                proc.kill()
                await proc.wait()
        update_status("stopped", None)
    return {"status": "stopped", "message": "Stop signal accepted", "timestamp": ts()}


@app.post("/attack/reset")
async def attack_reset() -> Dict[str, Any]:
    global stop_requested, last_report, last_execution

    await attack_stop()
    stop_requested = False
    last_report = {}
    last_execution = {}
    status_state["started_at"] = None
    status_state["updated_at"] = ts()
    status_state["status"] = "idle"
    return {"status": "reset", "message": "State reset", "timestamp": ts()}


@app.websocket("/attack")
async def ws_attack(websocket: WebSocket) -> None:
    await websocket.accept()
    active_websockets.append(websocket)

    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        try:
            active_websockets.remove(websocket)
        except ValueError:
            pass


if __name__ == "__main__":
    import uvicorn

    port = int(os.environ.get("PORT", "3030"))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=False)
