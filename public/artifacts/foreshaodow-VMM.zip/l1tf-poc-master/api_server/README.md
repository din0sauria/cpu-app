# L1TF API Server (Unified Platform Compatible)

该目录是 l1tf 模块的后端服务实现，已按 unified_platform 模块规范改造。

## 实现的标准接口

- POST /attack/start
- POST /attack/stop
- POST /attack/reset
- GET /attack/status
- WS /attack

## 运行

```bash
cd api_server
python3 -m pip install -r requirements.txt
python3 -m uvicorn main:app --host 0.0.0.0 --port 3030
```

或使用模块根目录的一键脚本:

```bash
./scripts/one_click_start.sh
```

## 说明

- 第一阶段固定为 environment_build。
- 最后一阶段固定为 report_generation。
- 报告事件顺序固定为: report_file -> attack_complete。

详细字段与事件结构见 API.md。
