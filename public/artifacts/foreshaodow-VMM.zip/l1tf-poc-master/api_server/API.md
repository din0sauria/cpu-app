# L1TF 模块接口文档（Unified Platform 兼容）

本文档描述 l1tf 模块后端接口，遵循 Poc_Exp_Backend-main 的 MODULE_INTEGRATION 规范。

## 1. 基本信息

- 默认端口: 3030
- HTTP 基地址: http://127.0.0.1:3030
- 事件流: ws://127.0.0.1:3030/attack

## 2. 控制接口（HTTP）

### 2.1 启动攻击

- 路径: POST /attack/start
- 请求体:

```json
{
  "config": {
    "phys_addr": "0x123456000",
    "length": 64,
    "build_before_run": true,
    "skip_kmod_build": true,
    "build_timeout_sec": 180,
    "attack_timeout_sec": 120
  }
}
```

- 响应示例:

```json
{
  "status": "running",
  "message": "L1TF run started",
  "timestamp": "2026-04-06T10:00:00.000000Z"
}
```

### 2.2 停止攻击

- 路径: POST /attack/stop
- 响应示例:

```json
{
  "status": "stopped",
  "message": "Stop signal accepted",
  "timestamp": "2026-04-06T10:01:00.000000Z"
}
```

### 2.3 重置状态

- 路径: POST /attack/reset
- 响应示例:

```json
{
  "status": "reset",
  "message": "State reset",
  "timestamp": "2026-04-06T10:02:00.000000Z"
}
```

### 2.4 查询状态

- 路径: GET /attack/status
- 响应示例:

```json
{
  "status": "idle",
  "current_phase": null,
  "started_at": null,
  "updated_at": "2026-04-06T10:02:00.000000Z",
  "timestamp": "2026-04-06T10:02:00.000000Z",
  "last_execution": {},
  "report": {},
  "message": "L1TF backend ready"
}
```

## 3. 事件流（WebSocket）

- 路径: WS /attack
- 协议: 原生 websocket JSON

服务端会推送以下事件类型:

1. phase_start
2. phase_progress
3. phase_complete
4. log
5. error
6. report_file
7. attack_complete

所有阶段事件都包含:

- phase_index
- phase_name
- display
- render
- timestamp

## 4. 阶段定义

固定阶段顺序:

1. environment_build
2. pte_search
3. memory_dump
4. report_generation

其中:

- 第一阶段固定是 environment_build，并会输出 phase_progress。
- 最后一阶段固定是 report_generation。

## 5. 报告事件顺序

严格顺序:

1. 先发送 report_file（markdown 内容）
2. 再发送 attack_complete

`report_file` 示例:

```json
{
  "type": "report_file",
  "phase_index": 4,
  "phase_name": "report_generation",
  "report_file": {
    "name": "l1tf_report.md",
    "format": "markdown",
    "content": "# L1TF (Foreshadow-VMM) Report\\n..."
  },
  "display": "报告已生成",
  "render": "markdown",
  "timestamp": "2026-04-06T10:03:00.000000Z"
}
```

`attack_complete` 示例:

```json
{
  "type": "attack_complete",
  "success": true,
  "report": {
    "report_id": "l1tf-1712397780",
    "module": "l1tf",
    "success": true,
    "started_at": "2026-04-06T10:00:00.000000Z",
    "finished_at": "2026-04-06T10:03:00.000000Z",
    "summary": "L1TF Foreshadow run finished",
    "findings": [],
    "artifacts": [
      {
        "name": "l1tf_report.md",
        "format": "markdown"
      }
    ]
  },
  "timestamp": "2026-04-06T10:03:00.000000Z"
}
```
