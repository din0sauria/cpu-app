# 🖥️ Windows 系统上的演示指南

针对 Windows 用户的详细步骤（已在 Windows 11 测试）

---

## 📋 前置要求

### 必需：
- [ ] Docker Desktop（已安装并运行）  
  [下载](https://www.docker.com/products/docker-desktop)

- [ ] Python 3.8+ 或通过 Microsoft Store 安装  
  验证：`python --version`

### 可选：
- [ ] VSCode 或其他代码编辑器
- [ ] PowerShell 7+（不强制，Windows 默认的也可以）

---

## ✅ 快速演示（7 分钟）

### 步骤 1：启动后端服务（2 分钟）

#### (1) 打开 PowerShell（管理员）

```powershell
# 进入项目目录
cd d:\360\vscode-data\data5\l1tf-poc-master

# 或者
cd l1tf-poc-master
```

#### (2) 启动 Docker 容器

```powershell
# 第一次运行会进行构建，需要 2-3 分钟
docker-compose up --build

# 输出应该看起来像这样（等到看到绿色的运行信息）：
# ...
# l1tf-poc-master_l1tf-backend_1 | [INFO] Starting L1TF attack service...
# l1tf-poc-master_l1tf-backend_1 |  * Running on http://0.0.0.0:3030
```

✅ **保持这个窗口打开，后续测试需要**

---

### 步骤 2：验证前端界面（1 分钟）

#### (1) 打开浏览器

打开新的浏览器窗口或标签页，访问：

```
http://localhost:3030
```

#### (2) 查看界面

您应该看到：
- 标题："L1TF (Foreshadow) 攻击演示"
- 左侧：控制面板（输入框和按钮）
- 右侧：系统信息（显示 OS、CPU 等）
- 底部：消息日志和数据输出区

如果能看到这个界面 ✅ **说明后端运行成功！**

---

### 步骤 3：开始进行攻击演示（4 分钟）

#### (1) 打开新的 PowerShell 窗口

进行演示和测试（保持第一个 PowerShell 窗口持续运行后端）

#### (2) 安装 Python 客户端依赖

```powershell
# 进入项目目录
cd l1tf-poc-master

# 创建虚拟环境（推荐）
python -m venv venv

# 激活虚拟环境
.\venv\Scripts\Activate.ps1

# 安装依赖
pip install requests python-socketio colorama
```

#### (3) 运行完整演示

```powershell
# 运行演示脚本
python demo.py

# 您会看到：
# ============================================================
#                    Foreshadow-VMM 后端演示和测试
# ============================================================
# 
# 服务器: localhost:3030
# 物理地址: 0x1000, 长度: 64 字节
#
# [步骤 1] 检查服务状态
# ✓ 收到状态响应
# {
#   "status": "active",
#   ...
# }
#
# [步骤 2] HTTP API 测试通过！
# ...
```

#### (4) 观察输出

演示脚本将执行三个测试：

```
1️⃣  HTTP API 测试
   ✓ 状态检查
   ✓ 系统信息
   ✓ HTTP API 测试通过

2️⃣  WebSocket 连接测试
   ✓ 已连接到服务器
   ✓ WebSocket 连接测试通过

3️⃣  模拟攻击演示
   ✓ 攻击已启动
   → 阶段开始: Looking for PTE...
   → 数据: 70 72 a7 84 ff ff ff...
   ✓ 攻击成功完成! 耗时: 2.34s

============================================================
                          测试结果总结
============================================================
HTTP API..................✓ 通过
WebSocket 连接............✓ 通过
模拟攻击..................✓ 通过

总体结果: 所有测试通过!
```

✅ **如果看到这些输出，说明后端完全正常工作！**

---

## 🎯 Web 前端交互演示

### 演示 1：通过 Web 界面手动运行攻击

#### (1) 输入参数

在浏览器中的 Web 前端（http://localhost:3030）：

- **物理地址**: `0x1000`
- **字节数**: `64`

#### (2) 点击"开始攻击"

观察以下变化：

```
消息日志：
✅ 已连接到服务器
🚀 启动攻击: 0x1000, 读取 64 字节
📍 阶段 [1] Looking for the PTE for VA 0x... in RAM...
🔍 发现: pte_mapped - {'pte_value': '7badbee235'}
📍 阶段 [2] Dumping from VA 0x...

数据输出：
70 72 a7 84 ff ff ff ff 30 73 a7 84 ff ff ff ff
00 45 a7 84 ff ff ff ff 30 20 a7 84 ff ff ff ff
...
```

#### (3) 等待完成

```
✨ 攻击成功完成! 耗时: 23.45s
```

---

### 演示 2：停止攻击

#### (1) 在攻击运行中点击"停止"按钮

#### (2) 查看消息日志

```
⏹️ 停止攻击...
```

---

### 演示 3：尝试不同参数

#### (1) 修改地址和长度

```
物理地址: 0x2000
字节数: 128
```

#### (2) 再次点击"开始攻击"

---

## 📊 命令行演示选项

### 选项 1：基础演示

```powershell
python demo.py
```

### 选项 2：指定物理地址

```powershell
python demo.py --addr 0x2000
```

### 选项 3：指定读取长度

```powershell
python demo.py --len 128
```

### 选项 4：所有参数

```powershell
python demo.py --addr 0x1000 --len 256 --host localhost --port 3030
```

### 选项 5：查看示例

```powershell
python demo.py --examples
```

输出将显示：
```
1️⃣  HTTP API 调用（cURL）
2️⃣  Python WebSocket 客户端
3️⃣  JavaScript WebSocket 客户端
4️⃣  测试客户端运行
5️⃣  Web 前端界面
```

### 选项 6：跳过某些测试

```powershell
# 只测试 HTTP API
python demo.py --skip-ws --skip-demo

# 只测试 WebSocket
python demo.py --skip-http --skip-demo

# 只运行攻击演示
python demo.py --skip-http --skip-ws
```

---

## 🧪 其他测试工具

### 使用 cURL（需要安装 curl）

```powershell
# 检查状态
curl http://localhost:3030/status

# 获取系统信息
curl http://localhost:3030/metadata

# 停止攻击
curl.exe -X POST http://localhost:3030/attack/stop
```

### 使用 Invoke-WebRequest（PowerShell 原生）

```powershell
# 检查状态
Invoke-WebRequest -Uri "http://localhost:3030/status" -Method GET

# 获取系统信息
Invoke-WebRequest -Uri "http://localhost:3030/metadata" -Method GET

# 停止攻击
Invoke-WebRequest -Uri "http://localhost:3030/attack/stop" -Method POST
```

### 使用 test_ws.py 脚本

```powershell
# 只连接，不攻击
python api_server/test_ws.py --no-attack

# 指定参数运行
python api_server/test_ws.py --host localhost --port 3030 --addr 0x1000 --len 64
```

---

## 📋 完整演示检查清单

完成以下所有步骤可以确保后端正常工作：

### 阶段 1：服务启动
- [ ] Docker 容器成功启动
- [ ] 看到 "Running on http://0.0.0.0:3030" 消息
- [ ] 后端日志没有错误

### 阶段 2：Web 前端
- [ ] 浏览器能打开 http://localhost:3030
- [ ] 页面正确加载（有控制面板和数据区）
- [ ] 显示"在线"状态（绿色）
- [ ] 系统信息已加载

### 阶段 3：HTTP API
- [ ] `python demo.py` 中 HTTP 测试通过
- [ ] `/status` 端点返回 200 OK
- [ ] `/metadata` 端点返回系统信息

### 阶段 4：WebSocket
- [ ] WebSocket 连接建立成功
- [ ] 能够接收连接响应
- [ ] 连接状态显示为"在线"

### 阶段 5：完整攻击
- [ ] 演示脚本能启动攻击
- [ ] 能接收实时消息
- [ ] 能收到十六进制数据
- [ ] 攻击能正常完成

### 阶段 6：Web 交互
- [ ] 打开 Web 前端
- [ ] 输入地址和长度
- [ ] 点击"开始攻击"
- [ ] 实时看到消息和数据
- [ ] 攻击完成后显示耗时

---

## 🎥 演示录制建议

如果要录制演示视频：

1. **录制后端窗口**
   ```powershell
   # 第一个 PowerShell 窗口显示的日志
   docker-compose up --build
   ```

2. **录制浏览器窗口**
   ```
   http://localhost:3030
   ```

3. **录制演示脚本输出**
   ```powershell
   python demo.py
   ```

组合这三个窗口可以完整展示整个系统的工作流程。

---

## 🚀 快速参考命令表

| 目标 | 命令 |
|------|------|
| 启动后端 | `docker-compose up --build` |
| 停止后端 | `Ctrl+C` 或 `docker-compose down` |
| 查看日志 | `docker-compose logs -f` |
| 运行完整演示 | `python demo.py` |
| 运行 WebSocket 测试 | `python api_server/test_ws.py` |
| 打开 Web 前端 | `http://localhost:3030` |
| 检查 API 状态 | `curl http://localhost:3030/status` |
| 进入容器 | `docker-compose exec l1tf-backend bash` |

---

## ❌ 常见问题（Windows 特定）

### Q1："Docker daemon is not running"

```
Error response from daemon: Get http://%2F%2F.%2Fpipe%2Fdocker_engine/v1.24/containers/json: open //./pipe/docker_engine: The system cannot find the file specified.
```

**解决方案：**
1. 打开 Docker Desktop 应用
2. 等待它完全启动
3. 重新运行命令

### Q2：端口 3030 已被占用

```
Error starting userland proxy: Bind for 0.0.0.0:3030 failed: port is already in use
```

**解决方案：**
```powershell
# 查看占用端口的进程
netstat -ano | findstr :3030

# 杀死进程（PID 是最后一列）
taskkill /PID <PID> /F

# 或使用不同端口
docker-compose up -p 3031:3030
```

### Q3：权限不足

```
Error: Access denied
```

**解决方案：**
以管理员身份打开 PowerShell

### Q4：网络连接失败

```
ConnectionRefusedError: [WinError 10061] ...
```

**解决方案：**
1. 确认 Docker 容器在运行：`docker ps`
2. 检查容器日志：`docker-compose logs`
3. 尝试重启：`docker-compose restart`

---

## 💡 提示和技巧

### 技巧 1：使用快捷键

```powershell
# 创建别名以简化命令
Set-Alias demo 'python demo.py'
Set-Alias dlog 'docker-compose logs -f'
Set-Alias dstart 'docker-compose up --build'
Set-Alias dstop 'docker-compose down'

# 然后直接使用
demo
dlog
```

### 技巧 2：将命令保存为脚本

创建 `demo.ps1`：
```powershell
# 激活虚拟环境
.\venv\Scripts\Activate.ps1

# 运行演示
python demo.py $args
```

然后使用：
```powershell
.\demo.ps1 --addr 0x2000
```

### 技巧 3：后台运行后端

```powershell
# 在后台运行 docker-compose
docker-compose up -d

# 查看后台日志
docker-compose logs -f
```

### 技巧 4：多个浏览器标签页

同时打开多个标签页进行并发测试：
```
http://localhost:3030  # 标签 1
http://localhost:3030  # 标签 2
http://localhost:3030  # 标签 3
```

每个标签页都能独立执行攻击。

---

## 📸 预期结果截图参考

完成后您会看到：

1. **Docker 启动日志**
   ```
   Creating network...
   Building l1tf-backend...
   Running on http://0.0.0.0:3030
   ```

2. **Web 前端界面**
   - 绿色"在线"指示灯
   - 系统信息已显示
   - 控制面板就绪

3. **演示脚本输出**
   ```
   [步骤 1] 检查服务状态
   ✓ HTTP API 测试通过
   ```

4. **WebSocket 实时数据**
   ```
   → 数据: 70 72 a7 84 ff ff ff...
   ✓ 完成
   ```

---

## 🎉 完成！

所有步骤完成后，您已经成功：

✅ 部署了完整的 L1TF 后端服务  
✅ 验证了 HTTP API  
✅ 测试了 WebSocket 连接  
✅ 运行了模拟攻击演示  
✅ 使用了 Web 前端交互  

现在您可以：
1. 进一步定制和修改代码
2. 开发自己的前端应用
3. 集成到更大的系统中
4. 进行学术研究或教学演示

---

## 📞 需要帮助？

查看这些文件获取更多信息：
- [API 文档](api_server/API.md) - API 参考
- [后端指南](README_BACKEND.md) - 详细用法
- [演示和测试](DEMO_AND_TEST.md) - 完整测试指南
- [快速开始](QUICK_START.md) - 部署说明

---

祝演示顺利！🚀
