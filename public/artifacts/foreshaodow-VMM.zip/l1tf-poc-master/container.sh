#!/bin/bash

# Foreshadow-VMM Backend Service Docker Manager

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

function print_info() {
    echo -e "${BLUE}[*]${NC} $1"
}

function print_success() {
    echo -e "${GREEN}[+]${NC} $1"
}

function print_error() {
    echo -e "${RED}[-]${NC} $1"
}

function print_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
}

function show_usage() {
    cat << EOF
L1TF Backend Service Container Manager

Usage: ./container.sh [COMMAND]

Commands:
  build       Build the Docker image
  up          Start the service (build and run)
  down        Stop the service
  logs        View service logs
  shell       Open a shell in the running container
  clean       Remove the image and containers
  help        Show this help message

Examples:
  ./container.sh build
  ./container.sh up
  ./container.sh logs -f
  ./container.sh down

EOF
}

function check_docker() {
    if ! command -v docker &> /dev/null; then
        print_error "Docker is not installed"
        exit 1
    fi
    if ! command -v docker-compose &> /dev/null; then
        print_error "docker-compose is not installed"
        exit 1
    fi
    print_success "Docker environment OK"
}

function build_image() {
    print_info "Building Docker image..."
    docker-compose build
    print_success "Image built successfully"
}

function start_service() {
    print_info "Starting L1TF backend service..."
    docker-compose up -d
    print_success "Service started"
    
    # Wait for service to be ready
    print_info "Waiting for service to be ready..."
    sleep 3
    
    # Check if service is responding
    if curl -s http://localhost:3030/status > /dev/null 2>&1; then
        print_success "Service is ready at http://localhost:3030"
        print_info "View status: curl http://localhost:3030/status"
        print_info "API docs at: http://localhost:3030/api/docs"
    else
        print_warning "Service may still be starting, check with: ./container.sh logs"
    fi
}

function stop_service() {
    print_info "Stopping L1TF backend service..."
    docker-compose down
    print_success "Service stopped"
}

function show_logs() {
    docker-compose logs "$@"
}

function open_shell() {
    print_info "Opening shell in l1tf-backend container..."
    docker-compose exec l1tf-backend /bin/bash
}

function clean_all() {
    print_warning "This will remove the Docker image and all containers"
    read -p "Continue? (y/N) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        print_info "Cleaning up..."
        docker-compose down -v
        docker rmi l1tf-poc-master_l1tf-backend 2>/dev/null || true
        print_success "Cleanup complete"
    else
        print_info "Cleanup cancelled"
    fi
}

function main() {
    local cmd="${1:-help}"
    
    case "$cmd" in
        build)
            check_docker
            build_image
            ;;
        up)
            check_docker
            build_image
            start_service
            ;;
        down|stop)
            stop_service
            ;;
        logs)
            shift
            show_logs "$@"
            ;;
        shell)
            open_shell
            ;;
        clean)
            clean_all
            ;;
        help|--help|-h)
            show_usage
            ;;
        *)
            print_error "Unknown command: $cmd"
            echo ""
            show_usage
            exit 1
            ;;
    esac
}

main "$@"
