#!/usr/bin/env python3
"""
Foreshadow-VMM Backend Demo - 后端测试演示
这个脚本演示如何调用后端 API 和 WebSocket
"""

import requests
import socketio
import json
import argparse
import time
import sys
from datetime import datetime

class Colors:
    BOLD = '\033[1m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    CYAN = '\033[96m'
    END = '\033[0m'

def print_header(text):
    print(f"\n{Colors.BOLD}{Colors.CYAN}{'='*60}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.CYAN}{text:^60}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.CYAN}{'='*60}{Colors.END}\n")

def print_step(num, text):
    print(f"{Colors.BOLD}{Colors.BLUE}[步骤 {num}]{Colors.END} {text}")

def print_success(text):
    print(f"{Colors.GREEN}✓ {text}{Colors.END}")

def print_error(text):
    print(f"{Colors.RED}✗ {text}{Colors.END}")

def print_info(text):
    print(f"{Colors.CYAN}→ {text}{Colors.END}")

def test_http_api(host='localhost', port=3030):
    """测试 HTTP API"""
    print_header("第一步：测试 HTTP API")
    
    base_url = f'http://{host}:{port}'
    
    try:
        # 1. 检查服务状态
        print_step(1, "检查服务状态")
        response = requests.get(f'{base_url}/status', timeout=5)
        if response.status_code == 200:
            data = response.json()
            print_success("收到状态响应")
            print(json.dumps(data, indent=2, ensure_ascii=False))
        else:
            print_error(f"HTTP {response.status_code}")
            return False
        
        # 2. 获取系统信息
        print_step(2, "获取系统信息")
        response = requests.get(f'{base_url}/metadata', timeout=5)
        if response.status_code == 200:
            data = response.json()
            print_success("收到系统信息")
            print(json.dumps(data, indent=2, ensure_ascii=False))
        else:
            print_error(f"HTTP {response.status_code}")
        
        print_success("HTTP API 测试通过！")
        return True
        
    except requests.exceptions.ConnectionError:
        print_error(f"无法连接到 {base_url}")
        print_info("请确保后端服务正在运行")
        return False
    except Exception as e:
        print_error(f"错误: {e}")
        return False

def test_websocket_connection(host='localhost', port=3030):
    """测试 WebSocket 连接"""
    print_header("第二步：测试 WebSocket 连接")
    
    sio = socketio.Client()
    connected = False
    
    @sio.event
    def connect():
        nonlocal connected
        connected = True
        print_success("WebSocket 已连接")
    
    @sio.event
    def disconnect():
        print_info("WebSocket 已断开")
    
    @sio.on('connection_response')
    def on_connection_response(data):
        print_success(f"收到连接响应: {data['message']}")
    
    try:
        print_step(1, "连接到 WebSocket")
        sio.connect(f'http://{host}:{port}', wait_timeout=10)
        time.sleep(1)
        
        if connected:
            print_success("WebSocket 连接测试通过！")
            sio.disconnect()
            return True
        else:
            print_error("连接失败")
            return False
            
    except Exception as e:
        print_error(f"WebSocket 连接失败: {e}")
        return False

def simulate_attack_demo(host='localhost', port=3030, phys_addr='0x1000', length=64):
    """模拟攻击演示"""
    print_header("第三步：模拟攻击演示")
    
    sio = socketio.Client()
    messages_received = []
    attack_complete = False
    
    @sio.event
    def connect():
        print_success("已连接到后端服务")
    
    @sio.on('attack_started')
    def on_attack_started(data):
        print_success(f"攻击已启动")
        print_info(f"命令: {data.get('command')}")
    
    @sio.on('phase_start')
    def on_phase_start(data):
        msg = data.get('message', '未知')
        print_info(f"阶段开始: {msg}")
        messages_received.append(('phase_start', msg))
    
    @sio.on('discovery')
    def on_discovery(data):
        print_success(f"发现: {data.get('discovery_type')}")
        msg_data = data.get('data', {})
        print_info(f"详情: {msg_data}")
        messages_received.append(('discovery', msg_data))
    
    @sio.on('hex_data')
    def on_hex_data(data):
        hex_output = data.get('data', '')[:50]  # 只显示前 50 个字符
        print_info(f"数据: {hex_output}...")
        messages_received.append(('hex_data', data.get('data')))
    
    @sio.on('log')
    def on_log(data):
        msg = data.get('message', '')[:80]
        print_info(f"日志: {msg}")
    
    @sio.on('attack_complete')
    def on_attack_complete(data):
        nonlocal attack_complete
        attack_complete = True
        success = data.get('success', False)
        if success:
            print_success(f"攻击成功完成！耗时: {data.get('total_time_seconds', 0):.2f}s")
        else:
            print_error(f"攻击失败: {data.get('error', '未知错误')}")
        messages_received.append(('attack_complete', data))
    
    @sio.on('error')
    def on_error(data):
        print_error(f"错误: {data.get('message')}")
    
    try:
        print_step(1, "连接到后端")
        sio.connect(f'http://{host}:{port}', wait_timeout=10)
        time.sleep(1)
        
        print_step(2, f"启动攻击 (地址: {phys_addr}, 长度: {length})")
        sio.emit('start_attack', {
            'phys_addr': phys_addr,
            'length': length
        })
        
        print_step(3, "等待攻击完成（预计 10-30 秒）")
        start_time = time.time()
        timeout = 60  # 60 秒超时
        
        while not attack_complete and (time.time() - start_time) < timeout:
            time.sleep(0.5)
        
        if attack_complete:
            print_success(f"收到 {len(messages_received)} 条消息")
            return True
        else:
            print_error("攻击超时")
            sio.emit('stop_attack')
            return False
            
    except Exception as e:
        print_error(f"演示失败: {e}")
        return False
    finally:
        if sio.connected:
            sio.disconnect()

def show_test_results(http_ok, ws_ok, demo_ok):
    """显示测试结果"""
    print_header("测试结果总结")
    
    results = [
        ("HTTP API", http_ok),
        ("WebSocket 连接", ws_ok),
        ("模拟攻击", demo_ok),
    ]
    
    for name, result in results:
        status = f"{Colors.GREEN}✓ 通过{Colors.END}" if result else f"{Colors.RED}✗ 失败{Colors.END}"
        print(f"{name:.<30} {status}")
    
    all_passed = all(r for _, r in results)
    print(f"\n{Colors.BOLD}总体结果: {'所有测试通过！' if all_passed else '部分测试失败'}{Colors.END}\n")
    
    return all_passed

def show_usage_examples():
    """显示使用示例"""
    print_header("后端 API 使用示例")
    
    examples = """
1️⃣  HTTP API 调用（cURL）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# 检查服务状态
curl http://localhost:3030/status

# 获取系统信息
curl http://localhost:3030/metadata

# 停止攻击
curl -X POST http://localhost:3030/attack/stop

# 重置状态
curl -X POST http://localhost:3030/attack/reset

2️⃣  Python WebSocket 客户端
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

import socketio

sio = socketio.Client()

@sio.on('hex_data')
def on_data(data):
    print(f"Leaked: {data['data']}")

sio.connect('http://localhost:3030')
sio.emit('start_attack', {
    'phys_addr': '0x123456000',
    'length': 64
})
sio.wait()

3️⃣  JavaScript WebSocket 客户端
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

const socket = io('http://localhost:3030');

socket.on('hex_data', (data) => {
  console.log('Leaked:', data.data);
});

socket.emit('start_attack', {
  phys_addr: '0x123456000',
  length: 64
});

4️⃣  测试客户端运行
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# 基础测试
python3 api_server/test_ws.py

# 指定地址和长度
python3 api_server/test_ws.py --addr 0x123456000 --len 128

# 仅连接（不攻击）
python3 api_server/test_ws.py --no-attack

5️⃣  Web 前端界面
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# 打开浏览器访问
http://localhost:3030

# 输入物理地址和要读取的字节数
# 点击"开始攻击"按钮
# 实时查看泄露的数据
"""
    print(examples)

def main():
    parser = argparse.ArgumentParser(
        description='Foreshadow-VMM 后端演示和测试',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python3 demo.py                    # 完整演示（需要后端运行）
  python3 demo.py --skip-http        # 跳过 HTTP 测试
  python3 demo.py --skip-demo        # 跳过模拟攻击
  python3 demo.py --addr 0x2000      # 指定物理地址
  python3 demo.py --host 192.168.1.100  # 指定服务器地址
        """
    )
    
    parser.add_argument('--host', default='localhost', help='服务器地址 (默认: localhost)')
    parser.add_argument('--port', type=int, default=3030, help='服务器端口 (默认: 3030)')
    parser.add_argument('--skip-http', action='store_true', help='跳过 HTTP API 测试')
    parser.add_argument('--skip-ws', action='store_true', help='跳过 WebSocket 连接测试')
    parser.add_argument('--skip-demo', action='store_true', help='跳过模拟攻击演示')
    parser.add_argument('--addr', default='0x1000', help='物理地址 (默认: 0x1000)')
    parser.add_argument('--len', type=int, default=64, help='读取字节数 (默认: 64)')
    parser.add_argument('--examples', action='store_true', help='显示使用示例')
    
    args = parser.parse_args()
    
    # 显示使用示例
    if args.examples:
        show_usage_examples()
        return 0
    
    # 显示欢迎信息
    print_header("Foreshadow-VMM 后端演示和测试")
    print(f"服务器: {args.host}:{args.port}")
    print(f"物理地址: {args.addr}, 长度: {args.len} 字节\n")
    
    # 运行测试
    http_ok = True
    ws_ok = True
    demo_ok = True
    
    if not args.skip_http:
        http_ok = test_http_api(args.host, args.port)
    
    if http_ok and not args.skip_ws:
        ws_ok = test_websocket_connection(args.host, args.port)
    
    if ws_ok and not args.skip_demo:
        demo_ok = simulate_attack_demo(args.host, args.port, args.addr, args.len)
    
    # 显示结果
    show_test_results(http_ok, ws_ok, demo_ok)
    
    # 显示下一步
    print_header("下一步")
    print("✅ 后端服务测试完成！\n")
    print("现在您可以:")
    print("  1. 访问 Web 前端: http://localhost:3030")
    print("  2. 运行自己的客户端代码")
    print("  3. 参考 API 文档进行集成: api_server/API.md")
    print("\n使用示例:")
    print("  python3 demo.py --examples  # 查看更多用法")
    print()

if __name__ == '__main__':
    main()
