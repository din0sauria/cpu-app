#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PORT="${PORT:-3030}"

cd "$ROOT_DIR"

if [[ ! -f "api_server/requirements.txt" ]]; then
  echo "[x] requirements file not found: api_server/requirements.txt"
  exit 1
fi

python3 -m pip install -r api_server/requirements.txt

cd api_server
exec python3 -m uvicorn main:app --host 0.0.0.0 --port "$PORT"
