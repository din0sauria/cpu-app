# 🧪 Foreshadow-VMM 后端演示和测试指南

本指南将帮助您完整测试后端服务是否正常工作。

---

## 📋 测试前检查清单

- [ ] 已安装 Docker Desktop（Windows/Mac）或 Docker + Docker Compose（Linux）
- [ ] 已安装 Python 3.8+
- [ ] 已安装 Git
- [ ] 网络连接良好

---

## 🚀 快速演示（5 分钟）

### 环境 1：在 Windows 上使用 Docker Desktop

#### 1️⃣ 启动后端服务

```powershell
# 进入项目目录
cd l1tf-poc-master

# 构建并启动服务
docker-compose up --build

# 输出类似于:
# l1tf-poc-master_l1tf-backend_1 | [INFO] Starting L1TF attack service...
# l1tf-poc-master_l1tf-backend_1 |  * Running on http://0.0.0.0:3030
```

✅ 服务已启动，保持这个窗口打开

#### 2️⃣ 在新的 PowerShell 窗口中运行演示

```powershell
# 进入项目目录并创建 Python 虚拟环境
cd l1tf-poc-master

# 创建虚拟环境（如果还没有）
python -m venv venv
.\venv\Scripts\Activate.ps1

# 安装客户端依赖
pip install requests python-socketio

# 运行演示
python demo.py

# 或者指定物理地址
python demo.py --addr 0x2000 --len 128
```

📊 您将看到完整的测试流程，包括：
- ✅ HTTP API 状态检查
- ✅ WebSocket 连接测试
- ✅ 模拟攻击演示

---

### 环境 2：在 Linux 上（原生或 WSL2）

#### 1️⃣ 启动后端服务

```bash
cd l1tf-poc-master

# 方式一：使用 Docker
docker-compose up --build

# 或方式二：本地运行（需要更多配置）
./build.sh
pip install -r api_server/requirements.txt
sudo python3 api_server/main.py
```

#### 2️⃣ 运行演示

```bash
# 创建虚拟环境
python3 -m venv venv
source venv/bin/activate

# 安装依赖
pip install requests python-socketio

# 运行完整演示
python3 demo.py

# 或查看更多示例
python3 demo.py --examples
```

---

## 🧬 详细测试流程

### 第一步：验证 HTTP API

#### 检查服务状态

```bash
# 使用 curl
curl http://localhost:3030/status

# 预期响应：
# {
#   "status": "active",
#   "message": "L1TF attack service ready",
#   "version": "1.0.0",
#   "attack_running": false,
#   "timestamp": "2024-03-21T10:00:00.000Z"
# }
```

#### 获取系统信息

```bash
curl http://localhost:3030/metadata

# 预期响应：
# {
#   "os": "Ubuntu 22.04",
#   "kernel": "Linux-5.15.0",
#   "arch": "x86_64",
#   "cpu": "Intel...",
#   "hostname": "...",
#   "cpu_count": 8,
#   "total_memory_gb": 15.6,
#   "timestamp": "2024-03-21T10:00:00.000Z"
# }
```

✅ 如果两个请求都成功，说明 HTTP API 正常！

### 第二步：测试 WebSocket 连接

```bash
# 运行测试脚本，仅测试连接
python3 api_server/test_ws.py --no-attack

# 输出应该类似于：
# [10:00:00] INFO: Connected to server
# [10:00:01] STATUS: is_running: false
```

✅ WebSocket 连接成功！

### 第三步：模拟完整演示

```bash
# 使用演示脚本
python3 demo.py

# 或使用测试客户端
python3 api_server/test_ws.py --addr 0x1000 --len 64
```

**演示流程：**

```
1. 连接到 WebSocket
   ✓ Connected to server

2. 启动攻击
   ✓ Attack started - Address: 0x1000

3. 实时接收消息
   → Phase start: Looking for PTE...
   → Discovery: PTE mapped
   → Data: 70 72 a7 84 ff ff ff ff...

4. 攻击完成
   ✓ Attack completed! Time: 2.34s
   ✓ Total leaked bytes: 64
```

---

## 🧪 高级测试

### 测试 1：压力测试（多次运行）

```bash
# 连续运行 5 次攻击
for i in {1..5}; do
  echo "Run $i/5"
  python3 api_server/test_ws.py --addr 0x1000 --len 32
  sleep 2
done
```

**预期结果：** 所有运行都应该成功，无内存泄漏

### 测试 2：不同物理地址

```bash
# 测试多个地址
python3 demo.py --addr 0x1000
python3 demo.py --addr 0x2000
python3 demo.py --addr 0x100000
```

**预期结果：** 所有地址都能成功读取

### 测试 3：不同数据长度

```bash
# 测试不同长度
python3 demo.py --len 16
python3 demo.py --len 64
python3 demo.py --len 256
```

**预期结果：** 能够正确处理各种长度

### 测试 4：并发连接

```bash
# 创建 test_concurrent.py
python3 << 'EOF'
import subprocess
import threading

def run_test(addr, length):
    subprocess.run(['python3', 'demo.py', '--addr', addr, '--len', str(length)])

threads = []
for i in range(3):
    t = threading.Thread(target=run_test, args=(f'0x{1000 + i*1000:x}', 32))
    threads.append(t)
    t.start()

for t in threads:
    t.join()
EOF
```

**预期结果：** 后端能够处理多个并发请求

---

## 🌐 Web 前端测试

### 1. 打开 Web UI

在浏览器中访问：
```
http://localhost:3030
```

### 2. 界面检查

- [ ] 能正常加载页面
- [ ] 显示"在线"状态（绿色）
- [ ] 系统信息已加载
- [ ] 输入框和按钮都可用

### 3. 执行攻击

1. 输入物理地址：`0x1000`
2. 输入字节数：`64`
3. 点击"开始攻击"按钮
4. 观察：
   - 消息日志实时更新
   - 数据输出区显示十六进制数据
   - 完成后显示总耗时

### 4. 高级操作

- 点击"停止"按钮停止运行中的攻击
- 点击"重置状态"清空数据
- 尝试修改地址和长度再次攻击

---

## 📊 预期输出示例

### HTTP API 输出

```json
{
  "status": "active",
  "timestamp": "2024-03-21T10:23:45.123Z",
  "message": "L1TF attack service ready",
  "version": "1.0.0",
  "attack_running": false
}
```

### WebSocket 消息流

```
[10:23:45] attack_started: Command: sudo ./doit 0x1000 0x40
[10:23:46] phase_start: Looking for the PTE for VA 0x7fd992a62000 in RAM...
[10:23:47] discovery: pte_mapped - PTE Value: 7badbee235
[10:23:47] phase_start: Dumping from VA 0x7fd992a621a0
[10:23:48] hex_data: 70 72 a7 84 ff ff ff ff 30 73 a7 84 ff ff ff ff
[10:23:49] hex_data: 00 45 a7 84 ff ff ff ff 30 20 a7 84 ff ff ff ff
[10:24:10] attack_complete: Success! Total time: 23.45s
```

---

## ❌ 故障排除

### 问题 1：连接被拒绝

```
Error: ConnectionRefusedError [Errno 111] Connection refused
```

**解决方案：**
```bash
# 检查服务是否运行
curl http://localhost:3030/status

# 如果失败，重新启动服务
docker-compose down
docker-compose up --build
```

### 问题 2：Permission Denied

```
PermissionError: [Errno 13] Permission denied: '/dev/mem'
```

**解决方案：**
```bash
# 确保内核模块已加载
sudo insmod devmem_allow_ko/devmem_allow.ko

# 或重启 Docker 容器
docker-compose restart
```

### 问题 3：超时

```
TimeoutError: Timeout waiting for attack to complete
```

**解决方案：**
```bash
# 查看服务日志
docker-compose logs -f

# 尝试更短的运行时间
python3 demo.py --len 16
```

### 问题 4：没有收到数据

**检查步骤：**
1. 确认是否支持 L1TF（真实 Intel CPU）
2. 查看日志是否有错误
3. 尝试不同的物理地址
4. 检查 PoC 二进制文件是否正确编译

```bash
# 重新编译
./build.sh

# 检查二进制文件
ls -la doit phys
```

---

## 📝 测试报告模板

当所有测试完成后，您可以记录结果：

```markdown
## 测试报告

### 环境信息
- 操作系统: [Windows/Linux/macOS]
- Docker 版本: [版本]
- CPU: [型号]
- 内存: [大小]

### 测试结果
- [ ] HTTP API 测试: ✅ 通过 / ❌ 失败
- [ ] WebSocket 测试: ✅ 通过 / ❌ 失败
- [ ] 模拟攻击测试: ✅ 通过 / ❌ 失败
- [ ] Web 前端测试: ✅ 通过 / ❌ 失败

### 性能数据
- 平均响应时间: XXXms
- 攻击耗时: XXs
- 内存泄露: No / Yes
- 并发处理: ✅ 正常

### 备注
[任何特殊情况或问题]
```

---

## ✅ 验证检查清单

完整的测试应该包含：

- [ ] HTTP API 能够响应
- [ ] WebSocket 能够连接
- [ ] 模拟攻击能够启动
- [ ] 能够收到十进制数据
- [ ] 能够停止正在进行的攻击
- [ ] 能够重置状态
- [ ] Web 前端能够正常加载
- [ ] Web 前端能够实时更新
- [ ] 多次运行无故障
- [ ] 并发请求能处理

所有 ✅ 都通过 = 后端部署成功！

---

## 🎓 学习资源

- [后端 API 文档](api_server/API.md)
- [使用指南](README_BACKEND.md)
- [快速开始](QUICK_START.md)
- [实现摘要](IMPLEMENTATION_SUMMARY.md)

---

## 🆘 需要帮助？

1. 查看日志：
   ```bash
   docker-compose logs -f l1tf-backend
   ```

2. 进入容器调试：
   ```bash
   docker-compose exec l1tf-backend bash
   ```

3. 检查端口占用：
   ```bash
   # Windows
   netstat -ano | findstr :3030
   
   # Linux/Mac
   lsof -i :3030
   ```

4. 查看 API 响应：
   ```bash
   curl -v http://localhost:3030/status
   ```

---

祝您测试顺利！🎉
