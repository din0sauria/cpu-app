#!/bin/bash
set -e

echo "[*] Building L1TF PoC..."
gcc -g -D_GNU_SOURCE -std=gnu99 -O0 -o doit doit.c doit.S
gcc -g -o phys phys.c
echo "[+] PoC binaries built successfully"

if [ "${SKIP_KMOD_BUILD:-0}" = "1" ]; then
	echo "[*] Skipping devmem_allow kernel module build (SKIP_KMOD_BUILD=1)"
else
	echo "[*] Building devmem_allow kernel module..."
	cd devmem_allow_ko
	make
	cd ..
	echo "[+] Kernel module built successfully"
fi

echo "[*] All components built successfully!"
