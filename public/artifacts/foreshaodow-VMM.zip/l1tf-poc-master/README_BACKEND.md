# L1TF PoC 后端服务指南

## 概述

该项目现已集成完整的后端服务，支持通过 HTTP 和 WebSocket 接口远程控制和监控 L1TF 攻击演示。

## 快速开始

### 方式一：Docker Compose（推荐）

```bash
# 1. 进入项目目录
cd l1tf-poc-master

# 2. 构建并启动服务
docker-compose up --build

# 或使用便捷脚本
chmod +x container.sh
./container.sh up

# 3. 服务将在 http://localhost:3030 启动
```

### 方式二：裸机运行

```bash
# 1. 编译 PoC（编译 C 代码和内核模块）
chmod +x build.sh
./build.sh

# 2. 加载内核模块
cd devmem_allow_ko
make
sudo insmod devmem_allow.ko
cd ..

# 3. 安装 Python 依赖
pip install -r api_server/requirements.txt

# 4. 启动后端服务（需要 sudo）
cd api_server
sudo python3 main.py --host 0.0.0.0 --port 3030
```

## 使用方式

### HTTP API

#### 1. 检查服务状态

```bash
curl http://localhost:3030/status
```

响应：
```json
{
  "status": "active",
  "timestamp": "2024-03-21T10:00:00.000Z",
  "message": "L1TF attack service ready",
  "version": "1.0.0"
}
```

#### 2. 获取系统信息

```bash
curl http://localhost:3030/metadata
```

#### 3. 停止攻击

```bash
curl -X POST http://localhost:3030/attack/stop
```

#### 4. 重置系统状态

```bash
curl -X POST http://localhost:3030/attack/reset
```

### WebSocket 客户端

#### Python 示例

```python
import socketio

sio = socketio.Client()

@sio.event
def connect():
    print("Connected!")
    # 启动攻击
    sio.emit('start_attack', {
        'phys_addr': '0x123456000',
        'length': 64
    })

@sio.on('hex_data')
def on_data(data):
    print(f"Leaked data: {data['data']}")

@sio.on('attack_complete')
def on_complete(data):
    print(f"Attack completed!")
    print(f"Leaked: {data['leaked_data']}")

sio.connect('http://localhost:3030')
sio.wait()
```

#### 使用测试客户端

```bash
# 安装依赖
pip install python-socketio

# 运行测试客户端
python3 api_server/test_ws.py --addr 0x123456000 --len 64
```

## 前端集成

### JavaScript/TypeScript 示例

```javascript
import io from 'socket.io-client';

const socket = io('http://localhost:3030');

socket.on('connect', () => {
  console.log('Connected to L1TF service');
  
  // 开始攻击
  socket.emit('start_attack', {
    phys_addr: '0x123456000',
    length: 64
  });
});

socket.on('hex_data', (data) => {
  console.log('Leaked data:', data.data);
  // 更新前端显示
  document.getElementById('leaked-data').textContent += data.data + '\n';
});

socket.on('attack_complete', (data) => {
  if (data.success) {
    console.log('Attack successful!');
    console.log('Total time:', data.total_time_seconds);
  }
});
```

### 前端 Vue/React 单页应用集成

```vue
<template>
  <div class="l1tf-panel">
    <div class="status">
      <h3>服务状态</h3>
      <p v-if="status">{{ status }}</p>
    </div>
    
    <div class="control">
      <input v-model="physAddr" placeholder="物理地址 (0x...)">
      <input v-model.number="readLength" type="number" placeholder="读取字节数">
      <button @click="startAttack" :disabled="isAttacking">开始攻击</button>
      <button @click="stopAttack" :disabled="!isAttacking">停止攻击</button>
    </div>
    
    <div class="output">
      <h3>泄露数据</h3>
      <pre>{{ leakedData }}</pre>
    </div>
  </div>
</template>

<script>
import io from 'socket.io-client';

export default {
  data() {
    return {
      socket: null,
      status: '',
      physAddr: '0x1000',
      readLength: 64,
      isAttacking: false,
      leakedData: ''
    };
  },
  
  mounted() {
    this.socket = io('http://localhost:3030');
    
    this.socket.on('hex_data', (data) => {
      this.leakedData += data.data + '\n';
    });
    
    this.socket.on('attack_complete', (data) => {
      this.isAttacking = false;
      this.status = data.success ? '攻击成功' : '攻击失败';
    });
  },
  
  methods: {
    startAttack() {
      this.isAttacking = true;
      this.leakedData = '';
      this.socket.emit('start_attack', {
        phys_addr: this.physAddr,
        length: this.readLength
      });
    },
    
    stopAttack() {
      this.socket.emit('stop_attack');
    }
  }
};
</script>
```

## 部署步骤

### 1. 系统要求

- Linux 系统（Ubuntu 20.04+ 推荐）
- Intel CPU 支持 VT-x 和 EPT
- Docker 和 docker-compose
- 4GB+ RAM
- root/sudo 访问权限

### 2. 环境检查

```bash
# 检查 CPU 支持
cat /proc/cpuinfo | grep -i "vmx\|ept"

# 检查内核版本
uname -r

# 检查 Docker
docker --version
docker-compose --version
```

### 3. 部署

```bash
cd l1tf-poc-master
./container.sh up
```

### 4. 验证

```bash
# 检查服务
curl http://localhost:3030/status

# 查看日志
./container.sh logs -f

# 测试 WebSocket
python3 api_server/test_ws.py --no-attack
```

## 配置选项

### 环境变量

在 `docker-compose.yml` 中修改：

```yaml
environment:
  - PYTHONUNBUFFERED=1
  - API_HOST=0.0.0.0
  - API_PORT=3030
```

### 启动参数

```bash
# 调试模式
sudo python3 api_server/main.py --host 0.0.0.0 --port 3030 --debug

# 指定端口
sudo python3 api_server/main.py --port 8080
```

## 故障排除

### 问题1：无法访问 /dev/mem

```bash
# 解决方案
sudo insmod devmem_allow_ko/devmem_allow.ko
```

### 问题2：WebSocket 连接失败

```bash
# 检查防火墙
sudo ufw allow 3030

# 检查服务运行
curl http://localhost:3030/status
```

### 问题3：PoC 二进制不存在

```bash
# 重新构建
./build.sh
```

### 问题4：权限拒绝

```bash
# 确保使用 sudo 运行
sudo python3 api_server/main.py
```

## 文件结构

```
l1tf-poc-master/
├── build.sh                      # 构建脚本（已更新）
├── container.sh                  # Docker 管理脚本
├── docker-compose.yml            # Docker 编排配置
├── doit.c/doit.S                # PoC 核心代码
├── phys.c                        # 宿主机工具
├── devmem_allow_ko/             # 内核模块
│   ├── devmem_allow.c
│   └── Makefile
└── api_server/                   # 后端服务（新增）
    ├── main.py                  # 主服务程序
    ├── test_ws.py               # WebSocket 测试客户端
    ├── Dockerfile               # Docker 镜像配置
    ├── requirements.txt         # Python 依赖
    ├── API.md                   # 完整 API 文档
    └── README.md                # 后端说明
```

## API 文档

完整的 API 文档请参考 `api_server/API.md`

主要接口：
- `GET /status` - 服务状态
- `GET /metadata` - 系统信息
- `POST /attack/stop` - 停止攻击
- `POST /attack/reset` - 重置状态
- `WS /socket.io` - WebSocket 连接

## 性能优化

1. **多核利用**: PoC 会自动使用多个 CPU 核心加速搜索
2. **并行处理**: 使用更多字节提高准确度
3. **缓存优化**: 充分利用 L1/L3 缓存特性

## 安全建议

⚠️ 只在以下场景使用：
- 学术研究
- 安全培训
- 隔离测试环境

禁止：
- 在生产系统上运行
- 用于未授权访问
- 恶意用途

## 许可证

见项目根目录 LICENSE 文件

## 参考文献

- CVE-2018-3646
- "L1TF - Breaking SGX with Transient Out-of-Order Execution"
- Intel Security Advisory

## 贡献

欢迎提交 Issue 和 Pull Request！
