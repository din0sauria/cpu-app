# L1TF 模块接入说明

该模块用于接入 Poc_Exp_Backend-main 的 unified_platform，接口规范遵循 MODULE_INTEGRATION.md。

## 目录放置位置

将整个 l1tf-poc-master 目录拷贝到:

- unified_platform/program/l1tf

说明:

- 模块根目录需包含 module_spec.json、API.md、scripts/one_click_start.sh。
- 后端服务入口在 api_server/main.py。

## 控制与事件协议

- 控制接口（HTTP）:
  - POST /attack/start
  - POST /attack/stop
  - POST /attack/reset
  - GET /attack/status
- 事件流（WebSocket）:
  - WS /attack

详细字段定义见:

- api_server/API.md

## 一键启动脚本

- scripts/one_click_start.sh

该脚本会启动 uvicorn 服务并默认监听 3030 端口。
