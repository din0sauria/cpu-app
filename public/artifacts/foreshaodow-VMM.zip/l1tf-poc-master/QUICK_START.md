﻿# Foreshadow-VMM 后端启动方式文档

本文档说明当前项目可用的启动方式，并附带本次演示输出的解释。

## 1. 推荐启动方式

### 1.1 Docker Compose 启动（接口联调推荐）

在项目根目录执行：

```bash
docker-compose down
docker-compose up --build
```

启动成功标志：
- 日志出现 Running on http://0.0.0.0:3030
- 浏览器可访问 http://localhost:3030
- GET http://localhost:3030/status 返回 200

说明：
- Docker 方式优先用于后端接口和前端联调。
- 不保证在 Windows Docker 环境里完成真实 L1TF 泄露。

### 1.2 本地 Linux 启动（真实 PoC 验证推荐）

```bash
# 1) 编译 PoC
./build.sh

# 2) 安装内核模块（按需）
cd devmem_allow_ko
make
sudo insmod devmem_allow.ko
cd ..

# 3) 安装 Python 依赖
pip install -r api_server/requirements.txt

# 4) 启动服务
cd api_server
sudo python3 main.py --host 0.0.0.0 --port 3030
```

说明：
- 真实漏洞演示通常需要在 Linux Guest VM 内运行。
- 需要满足 /dev/mem 可访问、内核版本与 PoC 兼容等条件。

## 2. Windows + Clash 启动要点

若镜像拉取失败，请在 Docker Desktop 中配置代理：
- Settings -> Resources -> Proxies
- HTTP Proxy 和 HTTPS Proxy 指向 Clash 的本地端口（例如 http://127.0.0.1:7890）
- Apply & Restart 后再执行 docker-compose up --build

## 3. 启动后验证步骤

### 3.1 HTTP 验证

```bash
curl http://localhost:3030/status
curl http://localhost:3030/metadata
```

### 3.2 WebSocket 验证

```bash
python demo.py --skip-demo
```

### 3.3 攻击流程验证

```bash
python demo.py --addr 0x123456000 --len 64
```

## 4. 本次截图输出解释（写入演示结论）

截图内容：
1. 攻击已启动 - 地址: 0x123456000
2. 阶段 [1] Looking for the PTE for VA ... in RAM...
3. 错误: failed to find or map our PTE
4. 攻击结束，耗时约 0.03s

解释：
- 这次运行属于“启动成功但攻击前置条件不满足”。
- 后端服务是正常工作的：能启动进程、能推送阶段、能推送错误、能结束流程。
- PoC 核心失败点是 PTE 映射未找到，属于环境条件问题，不是接口链路问题。

建议在汇报时这样表述：
- 后端接口联调通过。
- 在当前容器环境下 PoC 于 PTE 搜索阶段失败。
- 若需真实泄露数据，迁移到真实 Linux Guest VM 环境执行。

## 5. 常见问题

### Q1: 页面显示“攻击完成”但前面有 error，算成功吗？
不算。请以 attack_complete.success 为准。

### Q2: 为什么很快失败（几十毫秒）？
通常是环境不满足 PoC 的 /dev/mem 和页表扫描条件，进程很快返回。

### Q3: 我现在能做什么演示？
可演示完整后端链路：
- 页面启动
- WebSocket 实时消息
- 错误可视化
- 完成态回收

### Q4: 下一步如何拿到真实泄露数据？
迁移到真实 Linux Guest VM，确保内核模块与 /dev/mem 条件满足后再测。
