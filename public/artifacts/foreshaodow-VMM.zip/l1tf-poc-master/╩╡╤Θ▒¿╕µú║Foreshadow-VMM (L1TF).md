# 实验报告：Foreshadow-VMM (L1TF)

## 本项目具体说明

Foreshadow-VMM (CVE-2018-3646) 展示了 Intel 处理器在处理“非现场（Not-Present）”页表项时，预测执行逻辑存在的安全缺陷。本项目复现了如何从一个受限的虚拟机（Guest VM）中，利用该缺陷绕过传统的虚拟化隔离（如 EPT 扩展页表），直接推测读取宿主机（Host）系统或其他虚拟机的物理内存数据。该攻击主要利用 L1 Data Cache 的共享特性，通过侧信道技术将隐蔽的内存数据提取出来。

## 涉及资源

- **L1 Data Cache (L1 数据缓存)**
  
  - **位置**: 每个物理核心内部（通常为 32KB）。
  
  - **功能**: 缓存最近访问的内存数据，以极高的速度响应 CPU 请求。
  
  - **利用**: L1 缓存由同一核心的两个逻辑线程共享。当宿主机在某个核心运行并将数据留在 L1 后，攻击者在同一核心的虚拟机内可以触发预测执行将其读出。

- **PTE (Page Table Entry / 页表项)**
  
  - **位置**: 系统内存。
  
  - **功能**: 将虚拟地址（VA）映射到物理地址（PA）。
  
  - **利用**: 攻击者手动修改页表，将 Present 位设为 0（表示页面不在内存中），但同时将物理地址位指向宿主机的敏感物理内存。Intel CPU 会“贪婪地”预测执行对此类页面的访问。

- **WinDbg (Windows 调试器)**
  
  - **功能**: 用于宿主机侧的内核调试和地址转换。
  
  - **利用**: 在实验中，用于将宿主机内核函数（如 `nt!KiSystemCall64`）的虚拟地址转换为物理地址，作为攻击程序 `doit` 的输入参数。

- **Side Channel (侧信道)**
  
  - **技术**: Flush + Reload。
  
  - **利用**: 攻击者通过测量不同内存地址的访问耗时（周期数），判断哪个字节的数据导致了缓存命中（Cache Hit），从而反推泄露的数据值。

## 攻击原理

**1. 终端故障推测机制 (Terminal Fault Speculation)**

该攻击的微架构基础在于 Intel 处理器对 **“无效页表项” (Invalid PTE)** 的推测性处理逻辑。当一个页表的 **Present位 (P-bit)** 为 0 时（即页面不在内存中），MMU 会触发页面错误异常（#PF）。但在流水线层面，处理器为了性能优化，会启动**瞬态执行 (Transient Execution)**。此时，硬件会忽略权限校验，直接将 PTE 中剩余的物理地址位作为索引，尝试从 **L1 Data Cache** 中检索数据。

**2. 虚拟化隔离绕过 (Bypassing VMM Isolation)**

在 VMM（如 VMware）环境下，原本由 **EPT（扩展页表）** 建立的物理地址空间隔离在瞬态执行路径上失效了。攻击者通过在虚拟机内部手动构造一个指向**宿主机物理地址 (Host PA)** 且 `P=0` 的恶意页表项，诱导 CPU 越过虚拟机监控器的地址转换层，直接在 L1 缓存中定位并抓取属于宿主机的敏感数据字节。

**3. 隐蔽信道数据提取 (Covert Channel Extraction)**

由于瞬态执行的结果在异常提交后会被丢弃（无法写入寄存器），攻击者利用 **Flush + Reload** 缓存侧信道技术将泄露的信息从微架构状态（缓存状态）转移到架构状态（程序变量）。

- **编码阶段**：预测执行访问基于秘密数据的数组索引，改变 L1 缓存行状态。

- **解码阶段**：通过 **RDTSC** 指令测量数组各页面的访问延迟，耗时显著较短（Cache Hit）的索引即为泄露的物理内存真实值。

## 项目核心代码文件

- **`doit.c`**: 攻击主程序。实现申请内存、搜索物理页表、修改 PTE 标志位以及执行侧信道读取逻辑。

- **`devmem_allow_ko/devmem_allow.ko`**: 辅助内核模块。用于在 Guest 内部强制开启 `/dev/mem` 的完全读写权限，使 `doit` 能够直接修改 Guest 自己的页表。

- **`build.sh`**: 自动化构建脚本。

- **`phys.c`**: 宿主机辅助工具（可选）。在宿主机上循环读写目标数据，强迫该数据留在 L1 缓存中以便攻击者抓取。

## 运行环境

- **宿主机硬件 (Host Hardware)**:
  
  - **CPU**: Intel Core i5-1235U (12th Gen)
  
  - **架构**: x86_64 (Alder Lake)

- **宿主机软件 (Host OS)**:
  
  - **系统**: Windows 11 (23H2)
  
  - **调试器**: WinDbg (Preview) 用于物理地址定位。

- **虚拟机软件 (VMM)**:
  
  - **软件**: VMware Workstation Player 14.1.2（低版本以确保漏洞环境）。

- **客户机软件 (Guest OS)**:
  
  - **系统**: Ubuntu 18.04.1 (Kernel 4.15)

## 执行步骤

### 配环境步骤

1. **BIOS 安全配置解锁**:
   
   - 重启进入 BIOS，设置 **Supervisor Password**。
   
   - 在 Boot 菜单中将 **Secure Boot** 设为 `Disabled`。
   
   - 由于我的 CPU 是第 12 代，BIOS 默认处于一种“极简模式”或“受限模式”。在boot选项被锁定无法移动，也就无法修改Secure Boot。我问了AI这种情况，AI给了一个方法是恢复出厂设置。所以后面是

2. **开启宿主机调试模式**:
   
   - 管理员打开 CMD，运行 `bcdedit /debug on`。
   
   - 重启宿主机，确保系统进入调试模式。

3. **准备虚拟机环境**:
   
   - 在虚拟机设置中，确保分配给 Ubuntu 的核心与宿主机关键任务在同一个物理核心（建议绑定到 CPU 0/1）。
   
   - 在 Ubuntu 内安装构建工具：`sudo apt-get install build-essential`。

4. **加载特权模块 (Guest VM)**:
   
   - 进入 `devmem_allow_ko` 目录执行 `make`。
   
   - 执行 `sudo insmod devmem_allow.ko` 以获取物理内存修改权限。

### 运行步骤

1. **获取攻击目标物理地址 (Windows Host)**:
   
   - 打开 WinDbg，附加到本地内核（Attach to kernel -> Local）。
   
   - 输入 `x nt!KiSystemCall64` 获取虚拟地址。
   
   - 输入 `!process 0 0` 获取 `System` 的 `DirBase`。
   
   - 输入 `!vtop <DirBase> <VirtualAddress>` 获取物理地址（例如：`0x123456000`）。
   
   - 因为前面secure boot没有成功关闭，所以这里windbg没有得到数据。这里实际使用的是用 RAMMap 找一个已知的物理页。实际价值没有通过windbg得到的数据好。

2. **编译 PoC (Guest VM)**:
   
   - 执行 `./build.sh`。

3. **启动攻击进程 (Guest VM)**:
   
   - 使用从宿主机获得的物理地址运行程序：
     
     ```
     sudo ./doit 0x123456000 0x40
     ```

## 预期效果

![](C:\Users\hanyu.LAPTOP-2MUU7OUI\AppData\Roaming\marktext\images\2026-03-05-21-29-10-image.png)

**运行日志及逻辑解释**:

1. **`Looking for the PTE for VA 0x7fd992a62000 in RAM...`**
   
   - **逻辑**: 程序正在 Guest 物理内存中扫描自己的页表。它需要找到控制 `0x7fd992a62000` 这个地址的“地图条目”。

2. **`Our PTE now mapped. Value: 7badbee235`**
   
   - **逻辑**: 攻击成功。程序已经强行修改了页表值。这里的 `7badbee235` 是一个精心构造的值，它告诉 CPU：这个页面“不在内存中（Not-Present）”，但它的物理地址指向了宿主机的秘密位置。

3. **`Dumping from VA 0x7fd992a621a0`**
   
   - **逻辑**: 程序开始通过访问该 VA 触发预测执行，并利用缓存侧信道测量读取到的宿主机数据。

4. **理论输出 (在受影响的 CPU 上)**:
   
   - 会打印出十六进制字节码。这些字节码对应宿主机在物理地址 `0x123456000` 处的内存快照（例如内核函数代码段）。
   
   - ```
     70 72 a7 84 ff ff ff ff 30 73 a7 84 ff ff ff ff
     00 45 a7 84 ff ff ff ff 30 20 a7 84 ff ff ff ff
     70 c9 a7 84 ff ff ff ff a0 c9 a7 84 ff ff ff ff
     80 c9 a7 84 ff ff ff ff e0 fd a8 84 ff ff ff ff
     ```
   
   实际输出
   
   ![](C:\Users\hanyu.LAPTOP-2MUU7OUI\AppData\Roaming\marktext\images\2026-03-05-21-32-29-屏幕截图%202026-03-05%20212909.png)
