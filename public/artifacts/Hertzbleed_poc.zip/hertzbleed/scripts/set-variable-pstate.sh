#!/usr/bin/env bash
set -euo pipefail

# Enable Turbo/Boost (variable frequency mode)
if [ -e /sys/devices/system/cpu/intel_pstate/no_turbo ]; then
    echo "0" | sudo tee /sys/devices/system/cpu/intel_pstate/no_turbo >/dev/null
    echo "Turbo enabled via intel_pstate (no_turbo=0)"
elif [ -e /sys/devices/system/cpu/cpufreq/boost ]; then
    echo "1" | sudo tee /sys/devices/system/cpu/cpufreq/boost >/dev/null
    echo "Boost enabled via cpufreq (boost=1)"
else
    echo "No known turbo/boost control interface found." >&2
    exit 1
fi
