#!/usr/bin/env bash
set -euo pipefail

# Disable Turbo/Boost (fixed/base frequency mode)
if [ -e /sys/devices/system/cpu/intel_pstate/no_turbo ]; then
    echo "1" | sudo tee /sys/devices/system/cpu/intel_pstate/no_turbo >/dev/null
    echo "Turbo disabled via intel_pstate (no_turbo=1)"
elif [ -e /sys/devices/system/cpu/cpufreq/boost ]; then
    echo "0" | sudo tee /sys/devices/system/cpu/cpufreq/boost >/dev/null
    echo "Boost disabled via cpufreq (boost=0)"
else
    echo "No known turbo/boost control interface found." >&2
    exit 1
fi
